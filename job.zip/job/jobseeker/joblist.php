<?php
$title = "Available Jobs";
include("../includes/_JobSeekerLayout.php");
require_once '../includes/firebase_helper.php';

$success = $_SESSION['success'] ?? null;
$error   = $_SESSION['error'] ?? null;
$warning = $_SESSION['warning'] ?? null;
unset($_SESSION['success'], $_SESSION['error'], $_SESSION['warning']);

$search = $_GET['search'] ?? '';
$groupBy = $_GET['groupBy'] ?? 'none';
$sortBy = $_GET['sortBy'] ?? 'date';
$currentPage = (int)($_GET['page'] ?? 1);

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// Fetch jobs
try {
    $allJobs = $fb->get("tbl_job_posting") ?? [];
    $allCompanies = $fb->get("tbl_company") ?? [];

    $jobs = [];
    foreach ($allJobs as $job) {
        $companyName = "Confidential Company";
        foreach ($allCompanies as $comp) {
            if ($comp['company_ref_no'] === $job['company_ref_no']) {
                $companyName = $comp['company_name'] ?? "Confidential Company";
                break;
            }
        }
        $salaryRange = "";
        if (!empty($job['MinSalary']) && !empty($job['MaxSalary'])) {
            $salaryRange = number_format($job['MinSalary'], 2) . " - " . number_format($job['MaxSalary'], 2);
        }

        $jobs[] = [
            'job_ref_no' => $job['job_ref_no'] ?? '',
            'job_title' => $job['JobTitle'] ?? '',
            'Company' => ['name' => $companyName],
            'department' => $job['Department'] ?? '',
            'job_type' => $job['JobType'] ?? '',
            'location' => $job['JobLocation'] ?? '',
            'salary_range' => $salaryRange,
            'status' => $job['status'] ?? 1,
            'createdAt' => $job['createdAt'] ?? '',
        ];

        echo $jobs;
    }

    // Total jobs
    $totalJobs = count($jobs);

} catch (Exception $ex) {
    $error = "System Error: " . $ex->getMessage();
    $jobs = [];
    $totalJobs = count($jobs);
}

// Pagination placeholder
$totalPages = max(1, ceil($totalJobs / 10));
?>
<link rel="stylesheet" href="../css/Jobseeker.css">
<div class="my-5">
    <h2>Available Jobs</h2>
    <p class="text-muted">Discover opportunities that match your skills and interests.</p>
</div>

<?php if ($success) : ?>
    <div class="alert alert-success alert-dismissible fade show">
        <strong>Success!</strong> <?= $success ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error) : ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong>Error!</strong> <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($warning) : ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <strong>Warning!</strong> <?= $warning ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>


<!-- Search, Sort and Group Controls -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="input-group">
            <input type="text" id="searchInput" class="form-control" placeholder="Search jobs or companies..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary" onclick="searchJobs()">
                <i class="fas fa-search"></i>
            </button>
        </div>
    </div>
    <div class="col-md-4">
        <select id="groupSelect" class="form-select" onchange="groupJobs()">
            <option value="none" <?= $groupBy == "none" ? "selected" : "" ?>>Group: None</option>
            <option value="company" <?= $groupBy == "company" ? "selected" : "" ?>>Group: Company</option>
            <option value="department" <?= $groupBy == "department" ? "selected" : "" ?>>Group: Department</option>
            <option value="location" <?= $groupBy == "location" ? "selected" : "" ?>>Group: Location</option>
            <option value="type" <?= $groupBy == "type" ? "selected" : "" ?>>Group: Job Type</option>
            <option value="salary" <?= $groupBy == "salary" ? "selected" : "" ?>>Group: Salary Range</option>
        </select>
    </div>
    <div class="col-md-4">
        <select id="sortSelect" class="form-select" onchange="sortJobs()">
            <option value="date" <?= $sortBy == "date" ? "selected" : "" ?>>Sort: Newest First</option>
            <option value="title" <?= $sortBy == "title" ? "selected" : "" ?>>Sort: Job Title</option>
            <option value="company" <?= $sortBy == "company" ? "selected" : "" ?>>Sort: Company Name</option>
            <option value="salary" <?= $sortBy == "salary" ? "selected" : "" ?>>Sort: Highest Salary</option>
        </select>
    </div>
</div>

<div class="mb-3">
    <!-- <p class="text-muted">Showing <strong><?//= $totalJobs ?></strong> jobs</p> -->
</div>

<div id="loadingSpinner" class="text-center py-5 d-none">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<div id="jobListContainer">
    <?php include "job_list_partial.php"; ?>
</div>


<?php if ($groupBy == "none" && $totalPages > 1) : ?>
    <nav aria-label="Job list pagination" class="mt-4">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                <li class="page-item <?= $i == $currentPage ? "active" : "" ?>">
                    <a class="page-link" href="#" onclick="loadPage(<?= $i ?>); return false;"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
<?php endif; ?>

<script>
    let currentPage = <?= $currentPage ?>;
    let currentSearch = '<?= $search ?>';
    let currentSort = '<?= $sortBy ?>';
    let currentGroup = '<?= $groupBy ?>';

    function searchJobs() {
        currentSearch = document.getElementById('searchInput').value;
        currentPage = 1;
        loadJobs();
    }

    function sortJobs() {
        currentSort = document.getElementById('sortSelect').value;
        currentPage = 1;
        loadJobs();
    }

    function groupJobs() {
        currentGroup = document.getElementById('groupSelect').value;
        currentPage = 1;
        loadJobs();
    }

    function loadPage(page) {
        currentPage = page;
        loadJobs();
    }

    function loadJobs() {
        document.getElementById('loadingSpinner').classList.remove('d-none');
        document.getElementById('jobListContainer').style.opacity = '0.5';

        const url = 'joblist_ajax.php' +
            '?search=' + encodeURIComponent(currentSearch) +
            '&page=' + currentPage +
            '&sortBy=' + currentSort +
            '&groupBy=' + currentGroup;

        fetch(url)
            .then(response => response.text())
            .then(html => {
                document.getElementById('jobListContainer').innerHTML = html;
                document.getElementById('jobListContainer').style.opacity = '1';
                document.getElementById('loadingSpinner').classList.add('d-none');
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('loadingSpinner').classList.add('d-none');
                document.getElementById('jobListContainer').style.opacity = '1';
                alert('An error occurred. Please try again.');
            });
    }

    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchJobs();
        }
    });
</script>

<style>
    #jobListContainer {
        transition: opacity 0.3s ease;
    }
</style>
