<?php
session_start();
$title = "Select Theme Color";
$themeColor = $_SESSION['themeColor'] ?? '#000000';

include("../includes/_JobSeekerLayout.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['themeColor'] = $_POST['themeColor'];
    $_SESSION['success'] = "Theme updated successfully!";
    header("Location: theme.php");
    exit;
}
?>

<?php ob_start(); ?>

<h2>Select Theme Color</h2>

<form action="theme.php" method="post">
    <label>Choose Theme Color:</label>
    <input type="color" name="themeColor" value="<?= $themeColor ?>" style="width:150px;" class="form-control" />
    <button class="btn btn-primary mt-3">Save Theme</button>
</form>
