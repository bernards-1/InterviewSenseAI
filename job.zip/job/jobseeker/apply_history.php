<?php
$title = "My Applications";
require_once "../includes/firebase_helper.php";
include("../includes/_JobSeekerLayout.php");

// Firebase URL
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// Get logged-in user ref_no
$jobseeker_ref_no = $_SESSION['ref_no'] ?? null;
if (!$jobseeker_ref_no) {
    $_SESSION['error'] = "Please login first.";
    header("Location: /login/login.php");
    exit;
}

// Flash messages
$success = $_SESSION['success'] ?? null;
$error   = $_SESSION['error'] ?? null;
$warning = $_SESSION['warning'] ?? null;
unset($_SESSION['success'], $_SESSION['error'], $_SESSION['warning']);

// Fetch all applications
$allApplications = $fb->get("tbl_job_applications") ?? [];
$applications = [];

// Filter applications for current user
foreach ($allApplications as $key => $app) {
    if (isset($app['jobseeker_ref_no']) && $app['jobseeker_ref_no'] == $jobseeker_ref_no) {
        $jobData = $fb->get("tbl_jobs/" . $app['job_ref_no']);
        $companyData = null;
        if ($jobData && !empty($jobData['company_ref_no'])) {
            $companies = $fb->get("tbl_company");
            if ($companies) {
                foreach ($companies as $c) {
                    if ($c['company_ref_no'] == $jobData['company_ref_no']) {
                        $companyData = $c;
                        break;
                    }
                }
            }
        }

        $applications[] = [
            'Job' => [
                'job_ref_no' => $jobData['job_ref_no'] ?? null,
                'job_title' => $jobData['job_title'] ?? "Job Removed",
                'Company' => [
                    'name' => $companyData['company_name'] ?? "-"
                ]
            ],
            'apply_date' => $app['createdAt'] ?? "",
            'status' => $app['status'] ?? "Pending",
            'resume' => basename($app['resume_path'] ?? "")
        ];
    }
}
?>

<div class="my-5">
    <h2>My Applications</h2>
</div>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <strong>Success!</strong> <?= htmlspecialchars($success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong>Error!</strong> <?= htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($warning): ?>
    <div class="alert alert-warning alert-dismissible fade show">
        <strong>Warning!</strong> <?= htmlspecialchars($warning) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (empty($applications)): ?>
    <div class="text-center py-5">
        <p class="text-muted fs-5">You haven't applied to any jobs yet.</p>
        <a href="./joblist.php" class="btn btn-primary">Browse Jobs</a>
    </div>
<?php else: ?>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Job Title</th>
                            <th>Company</th>
                            <th>Applied Date</th>
                            <th>Status</th>
                            <th>Resume</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($app['Job']['job_title'] ?? "Job Removed") ?></strong></td>
                                <td><?= htmlspecialchars($app['Job']['Company']['name'] ?? "-") ?></td>
                                <td><?= !empty($app['apply_date']) ? date("M d, Y", strtotime($app['apply_date'])) : "-" ?></td>
                                <td>
                                    <?php
                                    switch (strtolower($app['status'])) {
                                        case "pending":
                                        case 0:
                                            $text = "Pending"; $badge = "bg-warning"; break;
                                        case "reviewed":
                                        case 1:
                                            $text = "Reviewed"; $badge = "bg-info"; break;
                                        case "shortlist":
                                        case 2:
                                            $text = "Shortlist"; $badge = "bg-success"; break;
                                        case "rejected":
                                        case 3:
                                            $text = "Rejected"; $badge = "bg-danger"; break;
                                        default:
                                            $text = ucfirst($app['status']); $badge = "bg-secondary";
                                    }
                                    ?>
                                    <span class="badge <?= $badge ?>"><?= $text ?></span>
                                </td>
                                <td>
                                    <?php if (!empty($app['resume'])): ?>
                                        <a href="../uploads/resume/<?= htmlspecialchars($app['resume']) ?>" target="_blank"
                                           class="btn btn-sm btn-outline-secondary">View</a>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($app['Job']['job_ref_no'])): ?>
                                        <a href="./job_detail.php?id=<?= $app['Job']['job_ref_no'] ?>" class="btn btn-sm btn-primary">View Job</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
