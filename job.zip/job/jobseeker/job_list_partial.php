<?php

require_once '../includes/firebase_helper.php';

// =====================
// FIREBASE INIT
// =====================
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);


// =====================
// FETCH JOBS & COMPANIES
// =====================
try {
    $allJobs = $fb->get("tbl_jobs") ?? [];
    $allCompanies = $fb->get("tbl_company") ?? [];
    $jobs = [];

    foreach ($allJobs as $job) {
        // Attach company info
        $companyName = "Confidential Company";
        foreach ($allCompanies as $comp) {
            if (($comp['company_ref_no'] ?? '') === ($job['company_ref_no'] ?? '')) {
                $companyName = $comp['company_name'] ?? "Confidential Company";
                break;
            }
        }

        // Format salary
        $salaryRange = "";
        if (!empty($job['salary_min']) && !empty($job['salary_max'])) {
            $salaryRange = number_format($job['salary_min'], 2) . " - " . number_format($job['salary_max'], 2);
        }

        $jobs[] = [
            'job_ref_no'   => $job['job_ref_no'] ?? '',
            'job_title'    => $job['job_title'] ?? '',
            'Company'      => ['name' => $companyName],
            'department'   => $job['department'] ?? '',
            'job_type'     => $job['job_type'] ?? '',
            'location'     => $job['location'] ?? '',
            'salary_range' => $salaryRange,
            'status'       => $job['status'] ?? 1,
            'createdAt'    => $job['createdAt'] ?? '',
        ];
    }

    //echo $job['job_type'];

} catch (Exception $ex) {
    echo "<div class='alert alert-danger'>Firebase Error: " . $ex->getMessage() . "</div>";
}

// =====================
// CALCULATE TOTAL JOBS
// =====================
$totalJobs = count($jobs);
?>

<!-- ===================== -->
<!-- JOB LIST PARTIAL -->
<!-- ===================== -->

<?php if ($groupBy != "none" && $groupedJobs != null): ?>

    <!-- Grouped View -->
    <?php foreach ($groupedJobs as $group): ?>
        <div class="mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <h4 class="mb-0 text-primary">
                    <i class="fas fa-folder-open me-2"></i><?= htmlspecialchars($group['Key']) ?>
                </h4>
                <span class="badge bg-primary rounded-pill"><?= count($group['Jobs']) ?> jobs</span>
            </div>

            <div class="row g-4">
                <?php foreach ($group['Jobs'] as $job): ?>
                    <?php $isActive = $job['status'] == 1;   ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 job-card">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title mb-2" title="<?= htmlspecialchars($job['job_title']) ?>">
                                    <?= htmlspecialchars($job['job_title']) ?>
                                </h5>

                                <p class="text-primary fw-semibold mb-2">
                                    <i class="fas fa-building me-1"></i>
                                    <?= htmlspecialchars($job['Company']['name']) ?>
                                </p>

                                <?php if (!empty($job['department'])): ?>
                                    <div class="mb-2">
                                        <small class="text-muted">
                                            <i class="fas fa-briefcase me-1"></i><?= htmlspecialchars($job['department']) ?>
                                        </small>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($job['job_type'])): ?>
                                    <div class="mb-2">
                                        <span class="badge bg-info text-dark">
                                            <i class="fas fa-clock me-1"></i><?= htmlspecialchars($job['job_type']) ?>
                                        </span>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($job['location'])): ?>
                                    <div class="mb-2">
                                        <small class="text-muted">
                                            <i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($job['location']) ?>
                                        </small>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($job['salary_range'])): ?>
                                    <div class="mb-3">
                                        <span class="text-success fw-bold">
                                            <i class="fas fa-money-bill-wave me-1"></i>RM <?= htmlspecialchars($job['salary_range']) ?>
                                        </span>
                                    </div>
                                <?php endif; ?>

                                <div class="mt-auto pt-3 border-top">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span class="badge <?= $isActive ? "bg-success" : "bg-secondary" ?>">
                                            <?= $isActive ? "Open" : "Closed" ?>
                                        </span>
                                        <small class="text-muted">
                                            <i class="far fa-calendar-alt me-1"></i>
                                            <?= !empty($job['createdAt']) ? date("M d, Y", strtotime($job['createdAt'])) : "" ?>
                                        </small>
                                    </div>

                                    <div class="d-grid gap-2">
                                        <!-- View Details Button -->
                                        <a href="./job/job_detail.php?id=<?= urlencode($job['job_ref_no']) ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-eye me-1"></i>View Details weeee
                                        </a>

                                        <!-- Apply Now Button (only if job is active) -->
                                        <?php if ($isActive): ?>
                                            <a href="/apply.php?jobId=<?= urlencode($job['job_ref_no']) ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-paper-plane me-1"></i>Apply Now
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

<?php else: ?>

<!-- Normal View -->
    <?php if (!empty($jobs)): ?>
        <div class="row g-4">
            <?php foreach ($jobs as $job): ?>
                <?php $isActive = $job['status'] == 1; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 job-card">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-2" title="<?= htmlspecialchars($job['job_title']) ?>">
                                <?= htmlspecialchars($job['job_title']) ?>
                            </h5>

                            <p class="text-primary fw-semibold mb-2">
                                <i class="fas fa-building me-1"></i>
                                <?= htmlspecialchars($job['Company']['name']) ?>
                            </p>

                            <?php if (!empty($job['department'])): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="fas fa-briefcase me-1"></i><?= htmlspecialchars($job['department']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($job['job_type'])): ?>
                                <div class="mb-2">
                                    <span class="badge bg-info text-dark">
                                        <i class="fas fa-clock me-1"></i><?= htmlspecialchars($job['job_type']) ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($job['location'])): ?>
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($job['location']) ?>
                                    </small>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($job['salary_range'])): ?>
                                <div class="mb-3">
                                    <span class="text-success fw-bold">
                                        <i class="fas fa-money-bill-wave me-1"></i>RM <?= htmlspecialchars($job['salary_range']) ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <div class="mt-auto pt-3 border-top">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="badge <?= $isActive ? "bg-success" : "bg-secondary" ?>">
                                        <?= $isActive ? "Open" : "Closed" ?>
                                    </span>
                                    <small class="text-muted">
                                        <i class="far fa-calendar-alt me-1"></i>
                                        <?= !empty($job['createdAt']) ? date("M d, Y", strtotime($job['createdAt'])) : "" ?>
                                    </small>
                                </div>

                                <div class="d-grid gap-2">
                                    <a href="./job_detail.php?id=<?= urlencode($job['job_ref_no']) ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i>View Details
                                    </a>
                                    <?php if ($isActive): ?>
                                        <a href="./apply.php?jobId=<?= urlencode($job['job_ref_no']) ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-paper-plane me-1"></i>Apply Now
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-briefcase text-muted" style="font-size: 4rem;"></i>
            <h4 class="text-muted mt-3">No Job Openings Available</h4>
            <p class="text-muted">Please check back later for new opportunities.</p>
        </div>
    <?php endif; ?>

<?php endif; ?>
