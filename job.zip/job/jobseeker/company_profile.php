<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once "../includes/firebase_helper.php";

// Firebase URL
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// ✅ Get company_ref_no from URL (not session)
$company_ref_no = $_GET['id'] ?? null;

if (!$company_ref_no) {
    die("<h2 style='color:red;'>Company ID not provided.</h2>");
}

$company = null;

// ✅ Get all companies from Firebase
$companies = $fb->get("tbl_company");

if ($companies) {
    foreach ($companies as $key => $row) {
        if (isset($row['company_ref_no']) && $row['company_ref_no'] === $company_ref_no) {
            $company = $row;
            $company['firebase_key'] = $key; // optional
            break;
        }
    }
}

// ❌ If company not found
if (!$company) {
    echo "<h2 style='color:red;'>Company profile not found.</h2>";
    exit;
}

// ✅ Logo path
$companyLogo = !empty($company['logo_path'])
    ? "../" . $company['logo_path']
    : "../images/Company/default.jpeg";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Company Profile</title>
    <link rel="stylesheet" href="../css/company_profile.css">
</head>
<body>

<div class="profile-box">
    <img src="<?= $companyLogo ?>" class="logo">

    <h2><?= htmlspecialchars($company['company_name']) ?></h2>

    <div class="info"><span class="label">Email:</span> <?= htmlspecialchars($company['email']) ?></div>
    <div class="info"><span class="label">Address:</span> <?= htmlspecialchars($company['address']) ?></div>
    <div class="info"><span class="label">City:</span> <?= htmlspecialchars($company['city']) ?></div>
    <div class="info"><span class="label">State:</span> <?= htmlspecialchars($company['state']) ?></div>
    <div class="info"><span class="label">Company Ref No:</span> <?= htmlspecialchars($company['company_ref_no']) ?></div>
</div>

</body>
</html>
