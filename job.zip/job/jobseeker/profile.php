<?php
$title = "JobSeeker Profile";
include("../includes/_JobSeekerLayout.php"); // layout

$ref_no = $_SESSION['ref_no'] ?? null;
$role   = $_SESSION['role'] ?? null;

if (!$ref_no || $role !== "3") {
    header("Location: ../login/login.php");
    exit();
}

require_once '../includes/firebase_helper.php';
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =====================
// FETCH JOBSEEKER DATA
// =====================
$jobseeker = null;

try {
    $allSeekers = $fb->get("tbl_jobseeker") ?? [];
    foreach ($allSeekers as $seeker) {
        if (($seeker['ref_no'] ?? '') === $ref_no) {
            $jobseeker = $seeker;
            break;
        }
    }

    if (!$jobseeker) {
        die("Jobseeker profile not found.");
    }

} catch (Exception $ex) {
    die("Firebase error: " . $ex->getMessage());
}

// =====================
// FLASH MESSAGES
// =====================
$success = $_SESSION['success'] ?? null;
$error   = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);

// =====================
// PROFILE IMAGE
// =====================
$imgPath = $jobseeker['img_path'] ?? 'default.jpeg';
if (!file_exists("../uploads/jobseeker/$imgPath")) {
    $imgPath = 'default.jpeg';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Jobseeker Profile</title>
    <link href="../css/JobseekerProfile.css" rel="stylesheet">
</head>

<body>
<?php if ($success): ?>
<div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="profile-container">
    <div class="profile-header">
        <div class="profile-photo">
            <img src="../uploads/jobseeker/<?= htmlspecialchars($imgPath) ?>" alt="Profile Photo">
        </div>
        <div class="profile-info">
            <h2><?= htmlspecialchars($jobseeker['name'] ?? '') ?></h2>
            <p><strong>Email:</strong> <?= htmlspecialchars($jobseeker['email'] ?? '') ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($jobseeker['phone'] ?? '') ?></p>
            <p><strong>Ref No:</strong> <?= $ref_no ?></p>
            <div class="profile-actions">
                <a href="edit_profile.php" class="btn btn-primary">Edit Profile</a>
                <a href="apply_history.php" class="btn btn-secondary">Application History</a>
            </div>
        </div>
    </div>

    <!-- About Section -->
    <?php if (!empty($jobseeker['about'])): ?>
    <div class="profile-about">
        <h3>About Me</h3>
        <p><?= nl2br(htmlspecialchars($jobseeker['about'])) ?></p>
    </div>
    <?php endif; ?>
</div>

</body>
</html>

