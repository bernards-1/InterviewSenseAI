<?php
$title = "Job Details";

include("../includes/_JobSeekerLayout.php");
require_once '../includes/firebase_helper.php';

// =====================
// FIREBASE INIT
// =====================
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =====================
// GET JOB ID
// =====================
$jobId = $_GET['id'] ?? null;

if (!$jobId) {
    die("Job ID not found.");
}

// =====================
// GET JOB DATA
// =====================
$jobData = $fb->get("tbl_jobs/$jobId");

if (!$jobData) {
    die("Job not found in Firebase.");
}

// =====================
// GET JOB DETAILS
// =====================
$jobDetailData = $fb->get("tbl_job_details/$jobId") ?? [];

// =====================
// GET COMPANY NAME (FIXED FOR FIREBASE AUTO ID)
// =====================
$companyName = "Not specified";
$companyRefNo = $jobData['company_ref_no'] ?? null;

if ($companyRefNo) {
    $companies = $fb->get("tbl_company") ?? [];

    foreach ($companies as $key => $comp) {
        if (isset($comp['company_ref_no']) && $comp['company_ref_no'] == $companyRefNo) {
            $companyName = $comp['company_name'] ?? "Not specified";
            break;
        }
    }
}


// =====================
// FORMAT SALARY
// =====================
$salaryRange = "Negotiable";
if (!empty($jobData['salary_min']) && !empty($jobData['salary_max'])) {
    $salaryRange = "RM " . number_format($jobData['salary_min']) . " - " . number_format($jobData['salary_max']);
}

// =====================
// BUILD JOB ARRAY (SAFE)
// =====================
$job = [
    'job_ref_no' => $jobId,
    'job_title'  => $jobData['job_title'] ?? "Not specified",
    'department' => $jobData['department'] ?? "Not specified",
    'job_type'   => $jobData['job_type'] ?? "Not specified",
    'location'   => $jobData['Location'] ?? "Not specified",
    'salary_range' => $salaryRange,
    'status'     => 1,
    'createdAt'  => $jobData['createdAt'] ?? null,
    'Company' => [
        'company_ref_no' => $companyRefNo,
        'name' => $companyName
    ],
    'JobDetails' => [
        [
            'description'    => $jobDetailData['description'] ?? '',
            'responsibility' => $jobDetailData['responsibility'] ?? '',
            'requirement'    => $jobDetailData['requirement'] ?? ''
        ]
    ]
];

$jobDetails = $job['JobDetails'];
?>

<div class="my-5">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <strong>Success!</strong> <?= htmlspecialchars($_SESSION['success']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof gtag === 'function') {
                gtag('event', 'apply_job', {
                    'job_id': '<?= htmlspecialchars($jobId) ?>',
                    'company_ref_no': '<?= htmlspecialchars($companyRefNo) ?>'
                });
            }
        });
        </script>
    <?php unset($_SESSION['success']); endif; ?>

    <h2>
        <?= htmlspecialchars($job['job_title']) ?>
        <?php if ($companyRefNo): ?>
            <a href="./company_profile.php?id=<?= urlencode($companyRefNo) ?>"
               class="btn btn-primary btn-lg px-5 right-button">
                View Company Profile
            </a>
        <?php endif; ?>
    </h2>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Company:</strong> <?= htmlspecialchars($job['Company']['name']) ?></p>
                <p><strong>Department:</strong> <?= htmlspecialchars($job['department']) ?></p>
                <p><strong>Salary Range:</strong> <?= htmlspecialchars($job['salary_range']) ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Type:</strong>
                    <span class="badge bg-info"><?= htmlspecialchars($job['job_type']) ?></span>
                </p>
                <p><strong>Status:</strong>
                    <span class="badge bg-success">Open</span>
                </p>
                <p><strong>Posted:</strong>
                    <?= $job['createdAt'] ? date("F d, Y", strtotime($job['createdAt'])) : "Not specified" ?>
                </p>
            </div>
        </div>
    </div>
</div>

<?php foreach ($jobDetails as $detail): ?>
<div class="card mb-4">
    <div class="card-header">Job Description</div>
    <div class="card-body">

        <?php if (!empty($detail['description'])): ?>
            <h5>Overview</h5>
            <p style="white-space: pre-line;"><?= htmlspecialchars($detail['description']) ?></p>
        <?php endif; ?>

        <?php if (!empty($detail['responsibility'])): ?>
            <h5>Responsibilities</h5>
            <ul>
                <?php foreach (preg_split("/\r\n|\n/", $detail['responsibility']) as $line): ?>
                    <?php if (trim($line)): ?>
                        <li><?= htmlspecialchars(trim($line)) ?></li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <?php if (!empty($detail['requirement'])): ?>
            <h5>Requirements</h5>
            <ul>
                <?php foreach (preg_split("/\r\n|\n/", $detail['requirement']) as $line): ?>
                    <?php if (trim($line)): ?>
                        <li><?= htmlspecialchars(trim($line)) ?></li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

    </div>
</div>
<?php endforeach; ?>

<div class="text-center mt-5">
    <a href="./apply.php?jobId=<?= urlencode($jobId) ?>" class="btn btn-primary btn-lg px-5">
        Apply Now
    </a>
</div>

<style>
.right-button {
    float: right;
}
</style>
