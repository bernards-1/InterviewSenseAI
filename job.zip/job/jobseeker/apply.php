<?php
$title = "Apply Job";

require_once "../includes/firebase_helper.php";
include("../includes/_JobSeekerLayout.php");

// Firebase URL
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// Get logged-in user ref_no
$jobseeker_ref_no = $_SESSION['ref_no'] ?? null;
if (!$jobseeker_ref_no) {
    $_SESSION['error'] = "Please login first.";
    header("Location: /login/login.php");
    exit;
}

// Get job id from URL
$jobId = $_GET['jobId'] ?? null;
if (!$jobId) {
    die("<h3 style='color:red;'>Job ID not provided.</h3>");
}

// Get job data
$job = $fb->get("tbl_jobs/$jobId");
if (!$job) {
    die("<h3 style='color:red;'>Job not found.</h3>");
}

// Get company data
$company = null;
if (!empty($job['company_ref_no'])) {
    $companies = $fb->get("tbl_company");
    if ($companies) {
        foreach ($companies as $c) {
            if ($c['company_ref_no'] == $job['company_ref_no']) {
                $company = $c;
                break;
            }
        }
    }
}

// Attach company to job
$job['Company'] = [
    'name' => $company['company_name'] ?? "Not specified"
];

// Salary range
$job['salary_range'] = ($job['salary_min'] ?? '') . " - " . ($job['salary_max'] ?? '');

// Flash messages
$error = $_SESSION['error'] ?? null;
$warning = $_SESSION['warning'] ?? null;
$success = $_SESSION['success'] ?? null;
unset($_SESSION['error'], $_SESSION['warning'], $_SESSION['success']);
?>

<div class="container my-5">

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <strong>Error!</strong> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($warning): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <strong>Warning!</strong> <?= htmlspecialchars($warning) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <strong>Success!</strong> <?= htmlspecialchars($success) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="mb-4">
        <h2 class="mb-2"><i class="fas fa-file-upload me-2 text-primary"></i>Apply for Position</h2>
        <p class="text-muted">Please fill in the application form below</p>
    </div>

    <div class="row">
        <!-- Job Info -->
        <div class="col-lg-5 mb-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-blue">
                    <i class="fas fa-briefcase me-2"></i>Job Information
                </div>
                <div class="card-body">
                    <h5 class="card-title text-primary mb-3"><?= htmlspecialchars($job['job_title']) ?></h5>

                    <p class="mb-2"><i class="fas fa-building text-muted me-2"></i>
                        <strong class="text-primary">Company:</strong> <?= htmlspecialchars($job['Company']['name']) ?>
                    </p>

                    <?php if (!empty($job['department'])): ?>
                        <p class="mb-2"><i class="fas fa-sitemap text-muted me-2"></i>
                            <strong class="text-primary">Department:</strong> <?= htmlspecialchars($job['department']) ?>
                        </p>
                    <?php endif; ?>

                    <p class="mb-2"><i class="fas fa-money-bill-wave text-muted me-2"></i>
                        <strong class="text-primary">Salary:</strong>
                        <span class="text-success fw-bold">RM <?= htmlspecialchars($job['salary_range']) ?></span>
                    </p>

                    <p class="mb-2"><i class="fas fa-clock text-muted me-2"></i>
                        <strong class="text-primary">Type:</strong>
                        <span class="badge bg-info text-dark"><?= htmlspecialchars($job['job_type']) ?></span>
                    </p>
                </div>
            </div>
        </div>
        <style>

        </style>
        <!-- Application Form -->
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-file-upload me-2"></i>Application Form
                </div>
                <div class="card-body p-4">
                    <form method="post" enctype="multipart/form-data" action="../function/jobseeker.php">
                        <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($job['job_ref_no']) ?>">

                        <div class="mb-4">
                            <label class="form-label fw-bold"><i class="fas fa-file-pdf me-2 text-danger"></i>Upload Resume *</label>
                            <input type="file" name="resumeFile" id="resumeFile" class="form-control form-control-lg" accept=".pdf" required>
                            <div class="form-text">Accepted formats: PDF | Maximum size: 5MB</div>
                            <div id="fileInfo" class="mt-2 text-muted small"></div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold"><i class="fas fa-graduation-cap me-2 text-primary"></i>Qualifications</label>
                            <textarea name="qualifications" class="form-control" rows="4" placeholder="E.g., Bachelor's Degree..."></textarea>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold"><i class="fas fa-briefcase me-2 text-success"></i>Work Experience</label>
                            <textarea name="experience" class="form-control" rows="4" placeholder="E.g., 3 years as Software Developer..."></textarea>
                        </div>

                        <div class="form-check mb-4 p-3 bg-light rounded">
                            <input class="form-check-input" type="checkbox" id="confirmCheck" required>
                            <label class="form-check-label" for="confirmCheck">I confirm that all information provided is accurate.</label>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end pt-3 border-top">
                            <a href="./joblist.php?id=<?= htmlspecialchars($job['job_ref_no']) ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Back
                            </a>
                            <button type="submit" class="btn btn-primary px-5" name="apply_job">
                                <i class="fas fa-paper-plane me-2"></i>Submit Application
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('resumeFile').addEventListener('change', function(e){
    const file = e.target.files[0];
    const info = document.getElementById('fileInfo');
    if(file){
        const sizeMB = (file.size/(1024*1024)).toFixed(2);
        if(sizeMB > 5){
            info.innerHTML = '<div class="alert alert-danger">File size exceeds 5MB</div>';
            e.target.value = '';
        } else {
            info.innerHTML = `<div class="alert alert-success">${file.name} (${sizeMB} MB)</div>`;
        }
    }
});
</script>
