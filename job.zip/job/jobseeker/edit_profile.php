<?php
$title = "Edit Profile";
include("../includes/_JobSeekerLayout.php");
require_once "../includes/firebase_helper.php";

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// Page title
$title = "Edit Profile";

// Get logged-in jobseeker ref_no
$ref_no = $_SESSION['ref_no'] ?? null;
$jobseeker = null;

// Fetch jobseeker from Firebase
if ($ref_no) {
    $jobseekers = $fb->get("tbl_jobseeker");
    if ($jobseekers) {
        foreach ($jobseekers as $key => $js) {
            if (isset($js['ref_no']) && $js['ref_no'] === $ref_no) {
                $jobseeker = $js;
                $jobseeker['id'] = $key; // Firebase key
                break;
            }
        }
    }
}

if (!$jobseeker) {
    echo "<h2 class='text-danger'>Jobseeker profile not found.</h2>";
    exit;
}

// Flash messages
$success = $_SESSION['Success'] ?? null;
$error   = $_SESSION['Error'] ?? null;
$warning = $_SESSION['Warning'] ?? null;

unset($_SESSION['Success'], $_SESSION['Error'], $_SESSION['Warning']);
?>

<div class="my-5">
    <h2>Edit Profile</h2>
</div>

<?php if ($success) : ?>
<div class="alert alert-success alert-dismissible fade show">
    <strong>Success!</strong> <?= htmlspecialchars($success) ?>
</div>
<?php endif; ?>

<?php if ($error) : ?>
<div class="alert alert-danger alert-dismissible fade show">
    <strong>Error!</strong> <?= htmlspecialchars($error) ?>
</div>
<?php endif; ?>

<?php if ($warning) : ?>
<div class="alert alert-warning alert-dismissible fade show">
    <strong>Warning!</strong> <?= htmlspecialchars($warning) ?>
</div>
<?php endif; ?>

<div class="card mx-auto" style="max-width: 600px;">
    <div class="card-body">
        <form action="../function/jobseeker.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="firebase_id" value="<?= $jobseeker['id'] ?>">

            <div class="mb-4">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($jobseeker['name'] ?? '') ?>" required />
            </div>

            <div class="mb-4">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($jobseeker['phone'] ?? '') ?>" required />
            </div>

            <div class="mb-4">
            <label class="form-label">Profile Image</label>

            <div class="mb-3">
                <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('profileImage').click()">
                    <i class="fas fa-upload me-2"></i>Upload Photo
                </button>
            </div>

            <input type="file" name="profileImage" id="profileImage" class="form-control d-none" accept="image/*" onchange="previewUploadedFile(this)">

            <div class="mt-3" id="previewContainer">
                <p class="text-muted mb-2">Current Image:</p>
                <img id="imagePreview" 
                    src="<?= !empty($jobseeker['img_path']) ? "/images/jobseeker/".htmlspecialchars($jobseeker['img_path']) : "/images/jobseeker/default.jpeg" ?>" 
                    alt="Profile" 
                    class="img-thumbnail" 
                    style="max-height: 120px; border-radius: 8px;">
            </div>
        </div>

            <div class="pt-3">
                <button type="submit" id="save" class="btn btn-primary" name="edit_profile">Save Changes</button>
                <a href="profile.php" class="btn btn-outline-secondary ms-3">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function previewUploadedFile(input) {
    const preview = document.getElementById('imagePreview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
