<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firebase Test</title>
</head>
<body>
    <h1>Firebase Realtime Database Test</h1>
    <button id="add-data-btn" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">Add Test Data</button>

    <script type="module">
      import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
      import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-analytics.js";
      // Import Realtime Database SDK
      import { getDatabase, ref, push, set } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

      const firebaseConfig = {
        apiKey: "AIzaSyDJXkcQJmjF9R8VBm-IOsCB-4dtt2R6TGM",
        authDomain: "testinterview-9eb8b.firebaseapp.com",
        databaseURL: "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "testinterview-9eb8b",
        storageBucket: "testinterview-9eb8b.firebasestorage.app",
        messagingSenderId: "884412906629",
        appId: "1:884412906629:web:194e8746350d97cf53bdec",
        measurementId: "G-65VQT8JBP5"
      };

      // Initialize Firebase
      const app = initializeApp(firebaseConfig);
      const analytics = getAnalytics(app);
      
      // Initialize Realtime Database and get a reference to the service
      const db = getDatabase(app);

      // Function to add data
      function addData() {
        try {
          // Create a reference to the 'users' list
          const userListRef = ref(db, 'users');
          // Create a new reference with a unique key
          const newRef = push(userListRef);
          
          set(newRef, {
            first: "weeeedlfja;lfjalf",
            last: "dafdasf",
            born: 1815,
            timestamp: Date.now()
          })
          .then(() => {
            console.log("Data saved successfully!");
            alert("Success! Data saved to Realtime Database.");
          })
          .catch((error) => {
             console.error("Data could not be saved." + error);
             alert("Error adding data: " + error.message);
          });

        } catch (e) {
          console.error("Error adding document: ", e);
          alert("Error adding document: " + e.message);
        }
      }

      // Attach event listener
      document.getElementById('add-data-btn').addEventListener('click', addData);
    </script>
</body>
</html>