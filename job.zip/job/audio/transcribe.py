import whisper
import speech_recognition as sr
import os
import tempfile
import torch

def main():
    # Check if CUDA (GPU support) is available
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    # Load the Whisper model
    # "base" is a good balance of speed and accuracy. 
    # Options: tiny, base, small, medium, large
    print("Loading Whisper model (base)...")
    try:
        model = whisper.load_model("base", device=device)
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    # Initialize recognizer
    recognizer = sr.Recognizer()

    # Capture audio from the microphone
    try:
        with sr.Microphone() as source:
            print("Adjusting for ambient noise... Please wait.")
            recognizer.adjust_for_ambient_noise(source, duration=1)
            print("Please speak now...")
            
            # Listen for audio
            # phrase_time_limit ensures it doesn't hang indefinitely if it can't detect a pause
            audio_data = recognizer.listen(source, phrase_time_limit=10)
            print("Recording complete. Processing...")
            
    except sr.RequestError as e:
        print(f"Could not request results; {e}")
        return
    except sr.UnknownValueError:
        print("Unknown error occurred")
        return
    except OSError as e:
        print(f"Microphone error: {e}")
        print("Please ensure you have a working microphone and PyAudio installed.")
        return

    # Save to a temporary WAV file because Whisper works directly with files or arrays
    # Using a file is often more robust for format compatibility
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_audio:
            temp_audio.write(audio_data.get_wav_data())
            temp_audio_path = temp_audio.name

        print("Transcribing...")
        # Transcribe
        result = model.transcribe(temp_audio_path)
        print("-" * 40)
        print("Transcription Result:")
        print(result['text'].strip())
        print("-" * 40)

    except Exception as e:
        print(f"Error executing transcription: {e}")
    finally:
        # Clean up
        if 'temp_audio_path' in locals() and os.path.exists(temp_audio_path):
            os.remove(temp_audio_path)

if __name__ == "__main__":
    main()
