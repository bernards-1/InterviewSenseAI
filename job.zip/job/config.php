<?php
// config.php - Configuration for AI Interview System
// Extended from Company/config.php

// Firebase Configuration
define('FIREBASE_CONFIG', [
    'apiKey' => 'AIzaSyDJXkcQJmjF9R8VBm-IOsCB-4dtt2R6TGM',
    'authDomain' => 'testinterview-9eb8b.firebaseapp.com',
    'databaseURL' => 'https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app',
    'projectId' => 'testinterview-9eb8b',
    'storageBucket' => 'testinterview-9eb8b.firebasestorage.app',
    'messagingSenderId' => '884412906629',
    'appId' => '1:884412906629:web:194e8746350d97cf53bdec',
    'measurementId' => 'G-65VQT8JBP5'
]);

// AI Service Configuration (Currently using local simulation)
// AI Service Configuration (Currently using local simulation)
define('AI_SERVICE', 'gemini'); // Options: 'openai', 'gemini', 'local'
define('GEMINI_API_KEYS', [
    'AIzaSyCRwiuEsJxXAvRxX5ezWEXHmvuqQaox9iM',
    'AIzaSyDUZL2O5HlJIAc6owoVSRey4NyIamd8vGY',
    'AIzaSyCHAEIvSMbTxnAADCDNAfzhsIJ8YYLxc78',
    'AIzaSyCiahouoAsRKNkXAbqngu3d_FIaFH9El2c',
    'AIzaSyDm7D2vipnYIT3MaZ9c4fWN7Fzjolo_vPs', 
    'AIzaSyDG9ZosGUJ9nku223YiIzm04iMLyKMSwJU',
    'AIzaSyBG5R3PoC3chCKK4fQRYDn_2AMrm-05GFQ',
    'AIzaSyASbF263CKKjMFKhSrslHYTKekK2MfrEPA',
    'AIzaSyDS8lri6MPdEMN_buqFGA06mjurQK4on0Q',
    'AIzaSyDwGiJ407GSsUDMu5-L3odFalGd06BwF90',
    'AIzaSyD8XL4UCmbVu-A9QUXiFOfFr49ou1mEpHU',
    'AIzaSyDMGe9xMzHlM-s5DvX_ruKPQXzdvzTMJKA',
    'AIzaSyCd_cQwlJeh-e_q_3ZtT9qorZ-WLR58p6o',
    'AIzaSyAfmYyz44-P9pXKY0c7zS1M7XQSr0smxgk',
    'AIzaSyDa49dTqSfRxuWp4MMhug-qQclR5dD44OE',
    'AIzaSyCol6cipeysZvDx-Ecj0LjOLK_cHoigrBg',
    'AIzaSyCRwiuEsJxXAvRxX5ezWEXHmvuqQaox9iM',
    'AIzaSyCLRpkX6wGbBDRgF8Ey9d4C1s6ZGyH-6aY',
    'AIzaSyAfmYyz44-P9pXKY0c7zS1M7XQSr0smxgk',
    'AIzaSyDXLsaKgXUJVZ06UAKppoybyNSp5zRdNnE',
    'AIzaSyDA5UDz4amlbg2EvTb1O3FdvDKIx-JqdKg',
    'AIzaSyDerqVGpRiNilCKznAluQoYpHmNAGf4pB4',
    'AIzaSyCgZ7Sjsj2S2ln1MxOop5zDWu4pST8a4ug',
    'AIzaSyDryi6Ibmk_Q6fIItXudX5swOgKrIYCqwA',
    'AIzaSyDk6GEXXjE4H9vAaUxDRpTiQKybfP6BTTw',
    'AIzaSyCtjb2LpmqY6qPzkNLEwBuJrWjz1xX5yqA',
    // Add more keys here if needed
]);

// System Settings
define('INTERVIEW_SETTINGS', [
    'questionsPerInterview' => 8,
    'technicalQuestions' => 3,
    'behavioralQuestions' => 3,
    'problemSolvingQuestions' => 2,
    'passingScore' => 60,
    'excellentScore' => 85
]);

// Scoring Criteria
define('SCORING_WEIGHTS', [
    'relevance' => 0.30,
    'clarity' => 0.25,
    'confidence' => 0.20,
    'accuracy' => 0.25
]);

// Job Roles
define('JOB_ROLES', [
    'Software Developer',
    'Frontend Developer',
    'Backend Developer',
    'Data Analyst',
    'Marketing Specialist',
    'Accountant',
    'Project Manager',
    'UI/UX Designer'
]);

// Helper function to output Firebase config as JSON
function getFirebaseConfigJSON()
{
    return json_encode(FIREBASE_CONFIG);
}

// Helper function to output Firebase config as JavaScript object
function getFirebaseConfigJS()
{
    $config = FIREBASE_CONFIG;
    return "
    const firebaseConfig = {
        apiKey: '{$config['apiKey']}',
        authDomain: '{$config['authDomain']}',
        databaseURL: '{$config['databaseURL']}',
        projectId: '{$config['projectId']}',
        storageBucket: '{$config['storageBucket']}',
        messagingSenderId: '{$config['messagingSenderId']}',
        appId: '{$config['appId']}',
        measurementId: '{$config['measurementId']}'
    };
    ";
}

// Calculate overall score from individual dimension scores
function calculateOverallScore($scores)
{
    $weights = SCORING_WEIGHTS;
    $total = 0;

    foreach ($scores as $dimension => $score) {
        if (isset($weights[$dimension])) {
            $total += $score * $weights[$dimension];
        }
    }

    return round($total, 1);
}

// Get performance level based on score
function getPerformanceLevel($score)
{
    $settings = INTERVIEW_SETTINGS;

    if ($score >= $settings['excellentScore']) {
        return 'Excellent';
    } elseif ($score >= $settings['passingScore']) {
        return 'Good';
    } else {
        return 'Needs Improvement';
    }
}
?>