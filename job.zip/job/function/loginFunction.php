<?php

require_once '../includes/firebase_helper.php';

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

/**
 * =====================
 * JOBSEEKER REGISTRATION
 * =====================
 */
if (isset($_POST['jobseekerRegister'])) {

    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    $error = null;

    // Validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        try {
            

            // Check email
            /*
            $existingUsers = $fb->get("tbl_login", '?orderBy="email"&equalTo="' . urlencode($email) . '"');

            if (isset($existingUsers['error'])) {
                $error = "Firebase Error: " . $existingUsers['error'];
            } elseif (!empty($existingUsers)) {
                $error = "Email already registered.";
            } else {*/
            // Generate IDs

            $userRefNo = uniqid('USR');
            $seekerRefNo = uniqid('SKR');
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            $loginData = [
                "ref_no" => $userRefNo,
                "email" => $email,
                "passwordHash" => $passwordHash,
                "role" => "3", //?
                "LoginAttempts" => 0
            ];

            $jobSeekerData = [
                "seeker_ref_no" => $seekerRefNo,
                "ref_no" => $userRefNo,
                "name" => $full_name,
                "email" => $email,
                "phone" => $phone,
                "status" => 1, //?
                "img_path" => "default.jpeg" //?
            ];

            $fb->post("tbl_login", $loginData);
            $fb->post("tbl_jobseeker", $jobSeekerData);

            /*
            // Email
            $baseUri = dirname($_SERVER['PHP_SELF']);
            $baseUri = str_replace('/function', '', $baseUri);
            $baseUrl = "http://" . $_SERVER['HTTP_HOST'] . $baseUri;

            $activationLink = $baseUrl . "/login/activate_account.php?seekerRefNo=" . $seekerRefNo;

            $subject = "Activate Your Account";
            $body = "Hi $full_name, <br><br> Please click the link below to activate your account: <br> <a href='$activationLink'>$activationLink</a>";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: noreply@jobsystem.com' . "\r\n";

            @mail($email, $subject, $body, $headers);
*/
            $_SESSION['success'] = "jobseeker Registration successful!";
            header("Location: ../login/login.php");
            exit();
            //}

        } catch (Exception $ex) {
            $error = "System Error: " . $ex->getMessage();
        }
    }

    if ($error) {
        $_SESSION['error'] = $error;
        $_SESSION['old_inputs'] = $_POST;
        header("Location: ../login/register_jobseeker.php");
        exit();
    }
}




/**
 * =====================
 * COMPANY REGISTRATION
 * =====================
 */
if (isset($_POST['companyRegister'])) {

    $company_name = trim($_POST['company_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
   
    $address = trim($_POST['address'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $company_logo = $_FILES['company_logo'] ?? null;

    $error = null;

    // Validation
    if (empty($company_name) || empty($email) || empty($address) || empty($state) || empty($city) || empty($password)) {
        $error = "All fields except logo are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        try {
            // Generate IDs
            $userRefNo = uniqid('USR');
            $companyRefNo = uniqid('CMP');
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            // Handle company logo upload
            $logoPath = "default_company.png"; // default logo
            if ($company_logo && $company_logo['error'] === 0) {
                $ext = pathinfo($company_logo['name'], PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), ['jpg','jpeg','png'])) {
                    $logoFileName = $companyRefNo . "." . $ext;
                    $uploadDir = "../uploads/company_logo/";
                    if (!file_exists($uploadDir)) mkdir($uploadDir, 0755, true);
                    move_uploaded_file($company_logo['tmp_name'], $uploadDir . $logoFileName);
                    $logoPath = "uploads/company_logo/" . $logoFileName;
                } else {
                    $error = "Invalid logo file type. Only JPG/PNG allowed.";
                }
            }

            if (!$error) {
                $loginData = [
                    "ref_no" => $userRefNo,
                    "email" => $email,
                    "passwordHash" => $passwordHash,
                    "role" => "2", // Company role
                    "LoginAttempts" => 0
                ];

                $companyData = [
                    "company_ref_no" => $companyRefNo,
                    "ref_no" => $userRefNo,
                    "company_name" => $company_name,
                    "email" => $email,
                    "address" => $address,
                    "state" => $state,
                    "city" => $city,
                    "logo_path" => $logoPath,
                    "status" => 1
                ];

                $fb->post("tbl_login", $loginData);
                $fb->post("tbl_company", $companyData);

                $_SESSION['success'] = "Company registration successful!";
                header("Location: ../login/login.php");
                exit();
            }

        } catch (Exception $ex) {
            $error = "System Error: " . $ex->getMessage();
        }
    }

    if ($error) {
        $_SESSION['error'] = $error;
        $_SESSION['old_inputs'] = $_POST;
        header("Location: ../login/register_company.php");
        exit();
    }
}



/**
 * =====================
 * LOGIN LOGIC
 * =====================
 */
if (isset($_POST['Login'])) {
    session_start();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $error = null;

    if (empty($email) || empty($password)) {
        $error = "Email and Password are required.";
    } else {
        try {
            $users = $fb->get('tbl_login', [
                'query' => [
                    'orderBy' => '"email"',
                    'equalTo' => '"' . $email . '"'
                ]
            ]);

            if (empty($users) || isset($users['error'])) {
                $error = "Invalid email or password.";
            } else {
                // 找到用户
                $user = null;
                foreach ($users as $u) {
                    if (strtolower($u['email']) === $email) {
                        $user = $u;
                        break;
                    }
                }

                if (!$user || !password_verify($password, $user['passwordHash'])) {
                    $error = "Invalid email or password.";
                } else {
                    // 设置 session
                    $_SESSION['ref_no'] = $user['ref_no'];
                    $_SESSION['role'] = $user['role'];

                    if ($_SESSION['role'] === "2") {
                        $allCompanies = $fb->get("tbl_company") ?? [];
                        foreach ($allCompanies as $comp) {
                            if ($comp["ref_no"] === $user['ref_no']) {
                                $_SESSION["company_ref_no"] = $comp["company_ref_no"];
                                break;
                            }
                        }
                        header("Location: ../company/dashboard.php");
                    } elseif ($_SESSION['role'] === "3") {
                        $allSeekers = $fb->get("tbl_jobseeker") ?? [];
                        foreach ($allSeekers as $seeker) {
                            if ($seeker["ref_no"] === $user['ref_no']) {
                                $_SESSION["seeker_ref_no"] = $seeker["seeker_ref_no"];
                                break;
                            }
                        }
                        header("Location: ../jobseeker/joblist.php");
                    } elseif ($_SESSION['role'] === "1") {
                        header("Location: ../admin/dashboard.php");
                    }

                    exit();
                }
            }

        } catch (Exception $ex) {
            $error = "System Error: " . $ex->getMessage();
        }
    }

    if ($error) {
        $_SESSION['error'] = $error;
        header("Location: ../login/login.php");
        exit();
    }
}


?>