<?php

session_start();

require_once '../includes/firebase_helper.php';

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);


/**
 * =====================
 * company job post
 * =====================
 */
// ✅ 1) Check login
$company_ref_no = $_SESSION["ref_no"] ?? null;
if (!$company_ref_no) {
    header("Location: ../login/login.php");
    exit;
}

// ✅ 1.5) Handle AJAX Status Update
$jsonInput = file_get_contents('php://input');
$inputData = json_decode($jsonInput, true);

if (isset($inputData['application_ref_no']) && isset($inputData['status'])) {
    header('Content-Type: application/json');
    try {
        $appRefNo = $inputData['application_ref_no'];
        $newStatus = $inputData['status'];
        
        $statusStr = "Pending";
        if ($newStatus == 1) $statusStr = "Reviewed";
        elseif ($newStatus == 2) $statusStr = "Shortlisted";
        elseif ($newStatus == 3) $statusStr = "Rejected";
        elseif ($newStatus == 4) $statusStr = "Technical Test"; 
        elseif ($newStatus == 5) $statusStr = "Interview";
        elseif ($newStatus == 6) $statusStr = "Success"; 
        
        $fb->put("tbl_job_applications/" . $appRefNo, "status", $statusStr);
        
        echo json_encode(['success' => true]);
        exit; // Stop further execution for AJAX
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// Handle Interview Schedule
if (isset($inputData['application_ref_no']) && isset($inputData['interviewSchedule'])) {
    header('Content-Type: application/json');
    try {
        $jobRef = $inputData['job_ref_no'];
        $seekerRef = $inputData['jobseeker_ref_no'];
        $appRef = $inputData['application_ref_no'];
        $date = $inputData['date'];
        $time = $inputData['time'];
        // $hr_role = $inputData['hr_role'] ?? 'HR Representative';
        $hr_role = $inputData['hr_role'] ?? '';
        $hr_name = $inputData['hr_name'] ?? 'HR Team';
        $msg = $inputData['message'];

        // Generate Interview ID
        $interviewRef = nextInterviewId($fb);

        // --- Generate Agora Link (Job Seeker) ---
        include_once("../agora_lib/RtcTokenBuilder.php");
        
        $agoraAppID = "3d7dfea869394667a3b19f67b1556290";
        $agoraCert = "d9f7bad9c65f4ec7b91cf3648409abf1";
        $channelName = $interviewRef; // Use I001 as channel
        $role = RtcTokenBuilder::RolePublisher;
        $expireTime = 3600 * 24 * 7; // 7 Days expiry
        $privilegeExpiredTs = (new DateTime("now", new DateTimeZone('UTC')))->getTimestamp() + $expireTime;
        
        // 1. Job Seeker Token
        $uid_seeker = mt_rand(1000, 9999); 
        $token_seeker = RtcTokenBuilder::buildTokenWithUid($agoraAppID, $agoraCert, $channelName, $uid_seeker, $role, $privilegeExpiredTs);
        //need change IP
        $videoLink = "http://192.168.1.22/job/room.php?channel=" . $channelName . 
                     "&token=" . urlencode($token_seeker) . 
                     "&uid=" . $uid_seeker . 
                     "&appId=" . $agoraAppID . 
                     "&type=seeker" . // Mark as seeker
                     "&applicationRef=" . $appRef .
                     "&jobseekerRef=" . $seekerRef .
                     "&jobRefNo=" . $jobRef;

        // 2. Company Token (DIFFERENT UID)
        $uid_company = mt_rand(10000, 19999); // Distinct range to avoid collision
        $token_company = RtcTokenBuilder::buildTokenWithUid($agoraAppID, $agoraCert, $channelName, $uid_company, $role, $privilegeExpiredTs);

        $videoLink_company = "http://192.168.1.22/job/room.php?channel=" . $channelName . 
                             "&token=" . urlencode($token_company) . 
                             "&uid=" . $uid_company . 
                             "&appId=" . $agoraAppID . 
                             "&type=company" . // Mark as company
                             "&applicationRef=" . $appRef .
                             "&jobseekerRef=" . $seekerRef .
                             "&jobRefNo=" . $jobRef;
                     
        // ---------------------------

        // Save to tbl_interviews
        $interviewData = [
            "interview_ref_no" => $interviewRef, 
            "job_ref_no" => $jobRef,
            "jobseeker_ref_no" => $seekerRef,
            "application_ref_no" => $appRef,
            "interview_date" => $date,
            "interview_time" => $time,
            "hr_role" => $hr_role,
            "hr_name" => $hr_name,
            "interview_link_jobseeker" => $videoLink, // Saved for Seeker
            "interview_link_company" => $videoLink_company, // Saved for Company
            "status" => "Scheduled",
            "createdAt" => date("Y-m-d H:i:s")
        ];
        $fb->put("tbl_interviews", $interviewRef, $interviewData);

        // Update Application Status to Interview (5)
        $fb->put("tbl_job_applications/" . $appRef, "status", "Interview"); // 5 = Interview
        
        // ---------------------------------------------------------
        // ✅ RESPONSE FIRST: Send JSON "Success" to browser immediately
        // ---------------------------------------------------------
        ob_clean(); // Clear any previous output
        ignore_user_abort(true); // Continue running script even if user closes browser
        set_time_limit(0); // unlimited execution time

        $response = json_encode(['success' => true]);
        
        header('Connection: close');
        header('Content-Length: ' . strlen($response));
        header('Content-Type: application/json');
        
        echo $response;
        
        // Flush checks (ensure data is sent)
        if (ob_get_level() > 0) ob_end_flush();
        flush();
        
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        
        // ---------------------------------------------------------
        // ⏳ ASYNC WORK: Send Email in Background (User doesn't wait)
        // ---------------------------------------------------------
        
        // --- Send Email to Candidate ---
        // 1. Get Seeker details by ref_no
        // Note: query param value must be double-quoted for Firebase equalTo
        // Note: query param value must be double-quoted for Firebase equalTo
        $seekerData = $fb->get("tbl_jobseeker", ['orderBy' => '"ref_no"', 'equalTo' => '"' . $seekerRef . '"']);
        // Note: query param value must be double-quoted for Firebase equalTo
        // $seekerData is already an array/null from get(), no need to decode again
        
        $logFile = "../email_debug_full.txt";
        
        $logMsg = "--- Email Attempt (Background): " . date("Y-m-d H:i:s") . " ---\n";
        $logMsg .= "Looking for Seeker: " . $seekerRef . "\n";
        
        // Check if actually got array or error
        if (is_array($seekerData) && isset($seekerData['error'])) {
             $logMsg .= "Firebase Error: " . $seekerData['error'] . "\n";
             
             // Fallback: Index error likely. Fetch ALL and filter manually.
             $logMsg .= "Attempting manual filter (fallback)...\n";
             $allSeekers = $fb->get("tbl_jobseeker");
             
             $foundManually = null;
             if (is_array($allSeekers)) {
                 foreach ($allSeekers as $uid => $userData) {
                     // Check ref_no, seeker_ref_no, or uid
                     if ($uid === $seekerRef || 
                         (isset($userData['ref_no']) && $userData['ref_no'] === $seekerRef) ||
                         (isset($userData['seeker_ref_no']) && $userData['seeker_ref_no'] === $seekerRef)) {
                         // Found! Create a fake "single record" structure like Firebase query would
                         $foundManually = [$uid => $userData];
                         break;
                     }
                 }
             }
             
             if ($foundManually) {
                 $seekerData = $foundManually;
                 $logMsg .= "Manual Filter: Found user.\n";
             } else {
                 $seekerData = null; 
                 $logMsg .= "Manual Filter: User not found.\n";
             }
        }
        
        $logMsg .= "Found Data: " . ($seekerData ? "Yes" : "No") . "\n";

        if ($seekerData) {
            // Firebase returns map of key => object. Get the first match.
            $firstKey = array_key_first($seekerData);
            $user = $seekerData[$firstKey];
            
            // Debug: Check keys
            $logMsg .= "Keys Found: " . implode(", ", array_keys($user)) . "\n";
            $logMsg .= "Full Data: " . print_r($user, true) . "\n"; // Log the full data structure

            $toEmail = trim($user['email'] ?? $user['Email'] ?? '');
            
            // Name handling: try 'name', then 'firstname'+'lastname', then default
            $rawName = $user['name'] ?? null;
            if (!$rawName) {
                 $rawName = ($user['firstname'] ?? '') . ' ' . ($user['lastname'] ?? '');
            }
            $toName = trim($rawName) ?: 'Candidate';
            
            $logMsg .= "Email Extracted: " . ($toEmail ?: "None") . "\n";

            if ($toEmail) {
                $subject = "Interview Invitation: " . $jobRef;
                $signOff = trim($hr_name) . "\n" . trim($hr_role);
                $message = "Dear $toName,\n\nYou have been invited to a video interview.\n\nDate: $date\nTime: $time\n\nClick the link below to join:\n$videoLink\n\nBest regards,\n$signOff";
                $headers = "From: no-reply@recruiterpro.com";

                // Simple mail() function as requested (same as testmail.php)
                $mailResult = mail($toEmail, $subject, $message, $headers);
                $logMsg .= "Mail Result: " . ($mailResult ? "Sent" : "Failed") . "\n";
            } else {
                $logMsg .= "Reason: No email in user record.\n";
            }
        } else {
            $logMsg .= "Reason: User not found in Firebase.\n";
        }
        
        if (file_exists($logFile)) {
             file_put_contents($logFile, $logMsg . "\n", FILE_APPEND);
        } else {
             file_put_contents($logFile, $logMsg . "\n");
        }
        
        exit;
    } catch (Exception $e) {
        ob_clean();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// ✅ 1.6) Handle Edit Interview Schedule
if (isset($inputData['action']) && $inputData['action'] === 'editInterviewSchedule') {
    header('Content-Type: application/json');
    try {
        $interviewRef = $inputData['interview_ref_no'] ?? '';
        $newDate = $inputData['date'] ?? '';
        $newTime = $inputData['time'] ?? '';

        if (!$interviewRef || !$newDate || !$newTime) {
            throw new Exception("Missing required fields.");
        }

        // Update in Firebase
        $fb->put("tbl_interviews/" . $interviewRef, "interview_date", $newDate);
        $fb->put("tbl_interviews/" . $interviewRef, "interview_time", $newTime);

        echo json_encode(['success' => true]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}


// ✅ 2) Generate Job ID (J001, J002...)
function nextJobId($fb) {
    $jobs = $fb->get("tbl_jobs");

    if (!$jobs) return "J001";

    $max = "J000";
    foreach ($jobs as $job) {
        if (isset($job["job_ref_no"]) && $job["job_ref_no"] > $max) {
            $max = $job["job_ref_no"];
        }
    }

    $num = intval(substr($max, 1));
    return "J" . str_pad($num + 1, 3, "0", STR_PAD_LEFT);
}

// ✅ 2.5) Generate Interview ID (I001, I002...)
function nextInterviewId($fb) {
    $interviews = $fb->get("tbl_interviews");

    if (!$interviews) return "I001";

    $max = "I000";
    foreach ($interviews as $key => $val) {
        // Check keys (I001) or internal ref if exists. Let's rely on Key if it matches pattern.
        // Also check if internal exists to be safe.
        $currentId = isset($val['interview_ref_no']) ? $val['interview_ref_no'] : $key;
        
        if (preg_match('/^I\d{3}$/', $currentId) && $currentId > $max) {
             $max = $currentId;
        }
    }

    $num = intval(substr($max, 1));
    return "I" . str_pad($num + 1, 3, "0", STR_PAD_LEFT);
}

// ✅ 3) Handle form submit (isset style)
if (isset($_POST["JobTitle"])) {

    try {
        // Generate Job ID
        $job_ref_no = nextJobId($fb);

        // Collect form data
        $job = [
            "job_ref_no" => $job_ref_no,
            "job_title" => trim($_POST["JobTitle"] ?? ""),
            "department" => trim($_POST["Department"] ?? ""),
            "job_type" => trim($_POST["JobType"] ?? ""),
            "salary_range" => trim($_POST["MinSalary"] ?? "") . " - " . trim($_POST["MaxSalary"] ?? ""),
            "state" => trim($_POST["state"] ?? ""),
            "city" => trim($_POST["city"] ?? ""),
            "location" => trim($_POST["Location"] ?? ""),
            "status" => 1,
            "company_ref_no" => $company_ref_no,
            "createdAt" => date("Y-m-d H:i:s")
        ];

        // Save Job to Firebase
        $fb->put("tbl_jobs/$job_ref_no", $job);

        // Job Details
        $jobDetail = [
            "job_ref_no" => $job_ref_no,
            "description" => trim($_POST["Description"] ?? ""),
            "responsibility" => trim($_POST["Responsibility"] ?? ""),
            "requirement" => trim($_POST["Requirement"] ?? "")
        ];

        // Save Job Details
        $fb->put("tbl_job_details/$job_ref_no", $jobDetail);

        // Success
        $_SESSION["success"] = "Job created successfully! Waiting for admin approval.";
        header("Location: ../company/dashboard.php");
        exit;

    } catch (Exception $e) {

        // Error handling
        $_SESSION["error"] = "Error creating job: " . $e->getMessage();
        header("Location: ../company/posting_job.php");
        exit;
    }

} else {
    // If not submitted, redirect back
    header("Location: ../company/posting_job.php");
    exit;
}



?>