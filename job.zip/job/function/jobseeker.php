 <?php
    session_start();
    require_once "../includes/firebase_helper.php";

    // Firebase URL
    $dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
    $fb = new FirebaseHelper($dbUrl);

    
    function nextJobId($fb) {
        $jobs = $fb->get("tbl_job_applications");

        if (!$jobs) return "A001";

        $max = "A000";

        foreach ($jobs as $key => $job) {
            // ✅ use Firebase KEY as ID (A001, A002...)
            if ($key > $max) {
                $max = $key;
            }
        }

        $num = intval(substr($max, 1));
        return "A" . str_pad($num + 1, 3, "0", STR_PAD_LEFT);
    }

    // =====================
    // APPLY JOB
    // =====================

    if (isset($_POST['apply_job'])) {

        $jobseeker_ref_no = $_SESSION['ref_no'] ?? null;
        if(!$jobseeker_ref_no){
            $_SESSION['error'] = "Please login first.";
            header("Location: /login/login.php");
            exit;
        }

        $job_ref_no = $_POST['job_ref_no'] ?? null;
        $qualifications = $_POST['qualifications'] ?? '';
        $experience = $_POST['experience'] ?? '';

        if(!$job_ref_no){
            $_SESSION['error'] = "Invalid job.";
            header("Location: /job_list.php");
            exit;
        }

        // Upload resume check
        if(!isset($_FILES['resumeFile']) || $_FILES['resumeFile']['error'] != 0){
            $_SESSION['error'] = "Resume upload failed.";
            header("Location: /apply.php?jobId=$job_ref_no");
            exit;
        }


        // ✅ STEP 1: Generate Application ID (A001, A002...)
        $applicationId = nextJobId($fb);


        // ✅ STEP 2: Upload resume using Application ID as filename
        $uploadDir = "../uploads/resume/";
        if(!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $ext = pathinfo($_FILES['resumeFile']['name'], PATHINFO_EXTENSION);
        $newFileName = $applicationId . "." . $ext;
        $filePath = $uploadDir . $newFileName;

        move_uploaded_file($_FILES['resumeFile']['tmp_name'], $filePath);


        // ✅ STEP 3: Save to Firebase using CUSTOM KEY (A001)
        $data = [
            "job_ref_no" => $job_ref_no,
            "jobseeker_ref_no" => $jobseeker_ref_no,
            "qualifications" => $qualifications,
            "experience" => $experience,
            "resume_path" => "uploads/resume/" . $newFileName,
            "status" => "Pending",
            "createdAt" => date("c")
        ];

        // ⭐ IMPORTANT: use your helper format (path, key, data)
        $result = $fb->put("tbl_job_applications", $applicationId, $data);

        if($result){
            $_SESSION['success'] = "Application submitted successfully!";
            header("Location: ../jobseeker/job_detail.php?id=$job_ref_no");
        } else {
            $_SESSION['error'] = "Failed to submit application.";
            header("Location: /apply.php?jobId=$job_ref_no");
        }

        exit;
    }


    /**
     * =====================
     * edit profile
     * =====================
     */
    // Check if form is submitted
if (isset($_POST['edit_profile'])) {

    // Fetch POST data
    $firebase_id  = $_POST['firebase_id'] ?? null;
    $name         = trim($_POST['name'] ?? '');
    $phone        = trim($_POST['phone'] ?? '');
    $profileFile  = $_FILES['profileImage'] ?? null;

    if (!$firebase_id || !$name || !$phone) {
        $_SESSION['Error'] = "Missing required fields.";
        header("Location: ../jobseeker/edit_profile.php");
        exit;
    }

    // 1️⃣ Fetch existing jobseeker record from Firebase
    $jobseeker = $fb->get("tbl_jobseeker/$firebase_id");

    if (!$jobseeker) {
        $_SESSION['Error'] = "Jobseeker not found.";
        header("Location: ../jobseeker/edit_profile.php");
        exit;
    }

    // 2️⃣ Handle profile image upload
    $img_path = $jobseeker['img_path'] ?? 'default.jpeg'; // keep current if not changed

    if ($profileFile && $profileFile['error'] === 0) {
        $ext = pathinfo($profileFile['name'], PATHINFO_EXTENSION);
        $img_name = time() . "." . $ext;

        $uploadDir = "../uploads/jobseeker/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        if (move_uploaded_file($profileFile['tmp_name'], $uploadDir . $img_name)) {
            $img_path = $img_name; // update path if upload successful
        } else {
            $_SESSION['Error'] = "Failed to upload profile image.";
            header("Location: ../jobseeker/edit_profile.php");
            exit;
        }
    }

    // 3️⃣ Prepare updated data (keep other fields intact)
    $updateData = [
        "name"      => $name,
        "phone"     => $phone,
        "email"     => $jobseeker['email'] ?? '',
        "ref_no"    => $jobseeker['ref_no'] ?? '',
        "img_path"  => $img_path
    ];

    // 4️⃣ Update Firebase
    $fb->put("tbl_jobseeker", $firebase_id, $updateData);

    $_SESSION['Success'] = "Profile updated successfully.";
    header("Location: ../jobseeker/profile.php");
    exit;
}
?>