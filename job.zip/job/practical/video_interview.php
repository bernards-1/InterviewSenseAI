<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video AI Interview</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #202124;
            color: #fff;
            overflow: hidden;
            height: 100vh;
        }

        /* Google Meet Layout */
        .meet-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        /* Header */
        .meet-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background: #202124;
            border-bottom: 1px solid #3c4043;
        }

        .meet-logo {
            font-size: 20px;
            font-weight: 600;
            color: #fff;
        }

        .room-info {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #9aa0a6;
            font-size: 14px;
        }

        .live-badge {
            background: #ea4335;
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Main Video Area */
        .video-area {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            position: relative;
            background: #000;
        }

        /* AI Video (Main) */
        .ai-video-container {
            position: relative;
            width: 100%;
            max-width: 700px;
            margin-top: 220px;
            aspect-ratio: 16/9;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .ai-avatar {
            font-size: 120px;
            margin-bottom: 20px;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        .ai-name {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .ai-status {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .speaking-indicator {
            width: 8px;
            height: 8px;
            background: #34a853;
            border-radius: 50%;
            animation: blink 1s ease-in-out infinite;
        }

        @keyframes blink {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.3;
            }
        }

        /* User Video (PIP) */
        .user-video-pip {
            position: absolute;
            bottom: 20px;
            right: 20px;
            width: 200px;
            height: 150px;
            background: #3c4043;
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid #5f6368;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
        }

        .user-video-pip video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-video-pip .video-label {
            position: absolute;
            bottom: 8px;
            left: 8px;
            background: rgba(0, 0, 0, 0.7);
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        /* Transcription Panel */
        .transcription-panel {
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            background: rgba(32, 33, 36, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 20px;
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #3c4043;
        }

        .transcript-item {
            margin-bottom: 8px;
            padding: 5px 0;
        }

        .transcript-speaker {
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 4px;
        }

        .transcript-speaker.ai {
            color: #8ab4f8;
        }

        .transcript-speaker.user {
            color: #81c995;
        }

        .transcript-text {
            font-size: 14px;
            line-height: 1.5;
            color: #e8eaed;
        }

        /* Controls Bar */
        .controls-bar {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 16px;
            padding: 20px;
            background: #202124;
            border-top: 1px solid #3c4043;
        }

        .control-btn {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: all 0.2s;
            background: #3c4043;
            color: #fff;
        }

        .control-btn:hover {
            background: #5f6368;
            transform: scale(1.1);
        }

        .control-btn.active {
            background: #1a73e8;
        }

        .control-btn.danger {
            background: #ea4335;
        }

        .control-btn.danger:hover {
            background: #d33b2c;
        }

        .control-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Silence Timer Bar */
        .silence-bar-container {
            width: 100%;
            height: 4px;
            background: rgba(255,255,255,0.1);
            border-radius: 2px;
            margin-top: 8px;
            overflow: hidden;
            display: none; /* Hidden by default */
        }
        .silence-bar-fill {
            height: 100%;
            background: #34a853;
            width: 0%;
            transition: width 0s linear;
        }

        /* Progress Indicator */
        .progress-indicator {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(32, 33, 36, 0.95);
            padding: 12px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            border: 1px solid #3c4043;
        }

        /* Loading State */
        .loading-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .loading-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid #3c4043;
            border-top-color: #1a73e8;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .user-video-pip {
                width: 120px;
                height: 90px;
                bottom: 80px;
                right: 10px;
            }

            .transcription-panel {
                left: 10px;
                right: 10px;
                max-height: 150px;
                padding: 15px;
            }

            .ai-avatar {
                font-size: 80px;
            }

            .ai-name {
                font-size: 18px;
            }

            .controls-bar {
                gap: 12px;
                padding: 15px;
            }

            .control-btn {
                width: 48px;
                height: 48px;
                font-size: 20px;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js"></script>
    <style>
        /* New Analysis Panel Styles */
        .analysis-panel {
            position: absolute;
            top: 240px; /* Below Transcription Panel */
            left: 20px;
            width: 350px;
            margin-top: 50px;
            min-height: 200px;
            background: rgba(32, 33, 36, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #3c4043;
            z-index: 10;
        }
        .analysis-card {
            margin-bottom: 15px;
            text-align: center;
        }
        .analysis-label {
            font-size: 12px;
            color: #9aa0a6;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }
        .analysis-value {
            font-size: 24px;
            font-weight: 700;
            color: #fff;
        }
        .analysis-sub {
            font-size: 12px;
            color: #bdc1c6;
        }
    </style>
</head>

<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
        <p style="font-size: 16px; color: #9aa0a6;">Initializing AI Interview...</p>
    </div>

    <!-- Main Container -->
    <div class="meet-container" style="display: none;" id="meetContainer">
        <!-- Header -->
        <div class="meet-header">
            <div class="meet-logo">🤖 AI Interview</div>
            <div class="room-info">
                <span class="live-badge">LIVE</span>
                <span id="roomName">Interview Session</span>
            </div>
        </div>

        <!-- Video Area -->
        <div class="video-area">
            <!-- Progress Indicator -->
            <div class="progress-indicator">
                Question <span id="currentQuestion">1</span> of <span id="totalQuestions">8</span>
            </div>

            <!-- Transcription Panel -->
            <div class="transcription-panel" id="transcriptionPanel">
                <div class="transcript-item">
                    <div class="transcript-speaker ai">AI Interviewer:</div>
                    <div class="transcript-text">Welcome! I'll be conducting your interview today. Let's begin...</div>
                </div>
            </div>

            <!-- NEW: Analysis Panel (Emotion & Blink) -->
            <div class="analysis-panel" id="analysisPanel">
                <!-- Emotion Analysis -->
                <div class="analysis-card">
                    <div class="analysis-label">Emotion (AI)</div>
                    <div class="analysis-value" id="emotion-label">WAITING</div>
                    <div class="analysis-sub" id="emotion-conf">(0%)</div>
                    
                     <!-- Session Distribution Table (New) -->
                    <div style="margin-top: 15px; border-top: 1px solid #3c4043; padding-top: 10px; font-size: 12px; text-align: left; color: #bdc1c6;">
                        <strong style="display:block; margin-bottom: 5px; text-align: center;">Session Distribution (%)</strong>
                        <div id="avg-scores-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;">
                            <!-- Scores injected here -->
                        </div>
                    </div>
                </div>
                <hr style="border: 0; border-top: 1px solid #3c4043; margin: 10px 0;">
                <!-- Blink Analysis -->
                <div class="analysis-card">
                    <div class="analysis-label">Blink Analysis</div>
                    <div class="analysis-value">
                        <span id="blink-bpm">0</span> <span style="font-size:14px;">BPM</span>
                    </div>
                    <div class="analysis-sub" id="blink-status">Calculating...</div>
                    <div class="analysis-sub" style="margin-top: 5px; font-size: 10px; color: #787a7d;">Total Blinks: <span id="blink-total-count">0</span></div>
                    <div id="session-time" style="display:none; font-size:10px; color:#5f6368; margin-top:5px;">00:00</div>

                </div>
            </div>

            <!-- AI Video Container -->
            <div class="ai-video-container">
                <div class="ai-avatar" id="aiAvatar">🤖</div>
                <div class="ai-name">AI Interviewer</div>
                <div class="ai-status" style="flex-direction: column; align-items: stretch; width: 80%; max-width: 300px;">
                    <div style="display:flex; align-items:center; justify-content: center; gap:8px;">
                        <span class="speaking-indicator" id="speakingIndicator" style="display: none;"></span>
                        <span id="aiStatusText">Listening...</span>
                    </div>
                    <div class="silence-bar-container" id="silenceBarContainer">
                        <div class="silence-bar-fill" id="silenceBarFill"></div>
                    </div>
                </div>
            </div>

            <!-- User Video (Picture-in-Picture) -->
            <div class="user-video-pip">
                <video id="userVideo" autoplay muted playsinline></video>
                <div class="video-label">You</div>
            </div>
        </div>

        <!-- Controls Bar -->
        <div class="controls-bar">
            <button class="control-btn active" id="micBtn" title="Microphone"><i class="fa-solid fa-microphone"></i></button>
            <button class="control-btn active" id="cameraBtn" title="Camera"><i class="fa-solid fa-video"></i></button>
            <!-- Removed Manual Done Button -->
            <button class="control-btn danger" id="endBtn" title="End Interview"><i class="fa-solid fa-phone-slash"></i></button>
            <button class="control-btn" id="transcriptBtn" title="Toggle Transcript"><i class="fa-regular fa-comment-dots"></i></button>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, get, update } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        <?php require_once '../config.php';
        echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        // Get candidate ID
        const urlParams = new URLSearchParams(window.location.search);
        const candidateId = urlParams.get('id');

        if (!candidateId) {
            alert('No candidate ID provided');
            window.location.href = 'upload_resume.php';
        }

        // State
        let candidateData = null;
        let questions = [];
        let currentQuestionIndex = 0;
        let answers = [];
        let recognition = null;
        let synthesis = window.speechSynthesis;
        let isMicOn = true;
        let isCameraOn = true;
        let isAISpeaking = false;
        let userStream = null;
        let isRecognizing = false; // Add state tracking
        let isProcessingAnswer = false; // Add processing tracking
        let analysisPromises = []; // NEW: Track pending audio analysis uploads
        let silenceTimer = null; // Fix: Move to global state so it doesn't get orphaned
        let hadNetworkError = false; // Track network errors globally

        // Initialize
        function resetSilenceBar() {
            const container = document.getElementById('silenceBarContainer');
            const fill = document.getElementById('silenceBarFill');
            if(!container || !fill) return;

            container.style.display = 'none';
            fill.style.transition = 'none';
            fill.style.width = '0%';
        }
        
        async function init() {
            try {
                // Load candidate data
                const candidateRef = ref(db, `candidates/${candidateId}`);
                const snapshot = await get(candidateRef);

                if (!snapshot.exists()) {
                    throw new Error('Candidate not found');
                }

                candidateData = snapshot.val();

                // Generate questions
                const response = await fetch('../api/ai_service.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=generate_questions&resume=${encodeURIComponent(JSON.stringify(candidateData.resume.structured))}&jobRole=${encodeURIComponent(candidateData.targetRole)}`
                });

                const result = await response.json();
                questions = result.questions;
                document.getElementById('totalQuestions').textContent = questions.length;

                // Setup camera
                await setupCamera();

                // Setup Analysis (Blink & Emotion)
                setupAnalysis();

                // Setup speech recognition
                setupSpeechRecognition();

                // Hide loading, show meet
                document.getElementById('loadingOverlay').style.display = 'none';
                document.getElementById('meetContainer').style.display = 'flex';

                // Start interview
                setTimeout(() => askQuestion(0), 2000);

            } catch (error) {
                console.error('Initialization error:', error);
                alert('Error: ' + error.message);
                window.location.href = 'upload_resume.php';
            }
        }

        // Setup Camera
        async function setupCamera() {
            try {
                userStream = await navigator.mediaDevices.getUserMedia({
                    video: true,
                    audio: true
                });
                document.getElementById('userVideo').srcObject = userStream;
            } catch (error) {
                console.error('Camera error:', error);
                alert('Please allow camera and microphone access');
            }
        }

        // --- NEW: Analysis Logic (Blink + Emotion) ---
        let faceMesh;
        let cameraUtils; 
        
        // Blink State
        const EAR_THRESHOLD = 0.20;
        const HYSTERESIS = 0.02;
        let isBlinking = false;
        let totalBlinks = 0;
        let sessionStartTime = 0;
        let sessionActive = false;
        
        // --- Audio Recording State ---
        let mediaRecorder;
        let audioChunks = [];
        let multimodalSessionData = []; // NEW: Store analysis results

        // --- Emotion Stats State ---
        let emotionTotals = {};
        
        // Landmarks
        const LEFT_EYE = [33, 160, 158, 133, 153, 144];
        const RIGHT_EYE = [362, 385, 387, 263, 373, 380];

        function euclideanDist(p1, p2) {
            return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
        }

        function getEAR(landmarks, indices) {
            const p = indices.map(i => landmarks[i]);
            const v1 = euclideanDist(p[1], p[5]);
            const v2 = euclideanDist(p[2], p[4]);
            const h = euclideanDist(p[0], p[3]);
            if (h === 0) return 0;
            return (v1 + v2) / (2.0 * h);
        }

        async function setupAnalysis() {
            const videoElement = document.getElementById('userVideo');
            const blinkBpmEl = document.getElementById('blink-bpm');
            const blinkStatusEl = document.getElementById('blink-status');
            const blinkTotalEl = document.getElementById('blink-total-count');
            const emotionLabel = document.getElementById('emotion-label');
            const emotionConf = document.getElementById('emotion-conf');
            const sessionTimeEl = document.getElementById('session-time');

            // 1. Initialize FaceMesh
            faceMesh = new FaceMesh({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
            });
            faceMesh.setOptions({
                maxNumFaces: 1,
                refineLandmarks: true,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });

            faceMesh.onResults((results) => {
                // Blink Logic
                if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
                    const landmarks = results.multiFaceLandmarks[0];
                    const earLeft = getEAR(landmarks, LEFT_EYE);
                    const earRight = getEAR(landmarks, RIGHT_EYE);
                    const avgEar = (earLeft + earRight) / 2.0;

                    if (avgEar < EAR_THRESHOLD) {
                        if (!isBlinking) {
                            isBlinking = true;
                            totalBlinks++;
                        }
                    } else {
                        if (isBlinking && avgEar > (EAR_THRESHOLD + HYSTERESIS)) {
                            isBlinking = false;
                        }
                    }
                }

                // Update UI (throttled to animation frame)
                if (sessionActive) {
                    const now = Date.now();
                    const elapsedSec = (now - sessionStartTime) / 1000;
                    const elapsedMin = elapsedSec / 60.0;
                    
                    // Time
                    const m = Math.floor(elapsedSec / 60);
                    const s = Math.floor(elapsedSec % 60);
                    sessionTimeEl.textContent = `${m}:${s.toString().padStart(2, '0')}`;

                    // BPM
                    let bpm = 0;
                    if (elapsedMin > 0.05) { // Wait 3s
                        bpm = totalBlinks / elapsedMin;
                    } else if (elapsedMin > 0) {
                        bpm = totalBlinks * (60 / elapsedSec);
                    }
                    blinkBpmEl.textContent = bpm.toFixed(1);
                    blinkTotalEl.textContent = totalBlinks;

                    // Status
                    if (elapsedMin > 0.1) {
                        if (bpm >= 25) {
                            blinkStatusEl.textContent = "Nervous (High Blink)";
                            blinkStatusEl.style.color = "rgb(255, 131, 131)"; // User requested Light Red
                        } else if (bpm < 10) {
                            blinkStatusEl.textContent = "Low Blink";
                            blinkStatusEl.style.color = "#fbbc04"; 
                        } else {
                            blinkStatusEl.textContent = "Normal";
                            blinkStatusEl.style.color = "#34a853";
                        }
                    }
                }
            });

            // 2. Start Camera Utils (Video Processing Loop)
            // Note: We use existing userStream, but Camera Utils is easier for Mediapipe
            if (typeof Camera === 'undefined') {
                 console.error("Mediapipe Camera utils not loaded.");
                 return;
            }

            const camera = new Camera(videoElement, {
                onFrame: async () => {
                    await faceMesh.send({ image: videoElement });
                },
                width: 480,
                height: 360
            });
            await camera.start();

            // Start Session
            sessionStartTime = Date.now();
            sessionActive = true;

            // 3. Start Emotion Detection Loop (Independent Loop)
            setInterval(predictEmotion, 1000); 
        }

        async function predictEmotion() {
            const videoElement = document.getElementById('userVideo');
            if (videoElement.paused || videoElement.ended) return;

            const canvas = document.createElement('canvas');
            canvas.width = videoElement.videoWidth || 640;
            canvas.height = videoElement.videoHeight || 480;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
            const dataURL = canvas.toDataURL('image/jpeg', 0.7);

            try {
                // Local Python API
                const response = await fetch('http://127.0.0.1:5000/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image: dataURL })
                });
                const data = await response.json();

                if (data.success && data.result) {
                    const label = data.result.label;
                    const conf = (data.result.confidence * 100).toFixed(0);
                    
                    const el = document.getElementById('emotion-label');
                    const ec = document.getElementById('emotion-conf');
                    
                    el.textContent = label.toUpperCase();
                    //ec.textContent = `(${conf}%)`;
                    ec.textContent = ""; 

                    // Update Averages (New)
                    if (data.result.details) {
                        updateAverageScores(data.result.details);
                    }

                    // Color coding
                    const lowerLabel = label.toLowerCase();
                    if (['happy', 'natural', 'neutral'].includes(lowerLabel)) {
                        el.style.color = '#34a853'; // Green
                    } else if (lowerLabel === 'angry') {
                        el.style.color = '#ff0000ff'; // Deep Red
                    } else if (['nervous'].includes(lowerLabel)) {
                        el.style.color = 'rgba(255, 104, 104, 1)'; // Light Red
                    } else {
                        el.style.color = '#fbbc04'; // Orange
                    }
                }
            } catch (err) {
                // Silent fail or log
                // console.log("Emotion API error (servers down?)", err);
            }
        }

        function updateAverageScores(currentScores) {
            const container = document.getElementById('avg-scores-container');
            if (!container) return;

            let html = '';
            // Sort keys to keep display consistent/ordered
            const keys = Object.keys(currentScores).sort();

            // 1. Find the Winner (Dominant Emotion)
            let winner = null;
            let maxScore = -1;

            keys.forEach(key => {
                if (currentScores[key] > maxScore) {
                    maxScore = currentScores[key];
                    winner = key;
                }
                // Initialize totals if needed
                if (!emotionTotals[key]) {
                    emotionTotals[key] = 0;
                }
            });

            // 2. Winner Takes All
            if (winner) {
                emotionTotals[winner] += 1; // Add 1 "tick" approx 1 sec
            }

            // 3. Calculate Grand Total
            let grandTotal = 0;
            for (let k in emotionTotals) {
                grandTotal += emotionTotals[k];
            }

            // 4. Render Percentages
            keys.forEach(key => {
                const totalTicks = emotionTotals[key];
                let percent = 0;
                if (grandTotal > 0) {
                    percent = (totalTicks / grandTotal) * 100;
                }
                
                // Color highlight for dominant emotions (>20%)
                let color = "#bdc1c6"; // Default gray
                if (percent > 20) color = "#8ab4f8"; // Blueish highlight

                html += `<div><span style="color:#787a7d;">${key}:</span> <b style="color:${color}">${percent.toFixed(1)}%</b></div>`;
            });

            container.innerHTML = html;
        }

        // Setup Speech Recognition
        function setupSpeechRecognition() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

            if (!SpeechRecognition) {
                alert('Speech recognition not supported. Please use Chrome browser.');
                return;
            }

            recognition = new SpeechRecognition();
            recognition.continuous = true; // Key fix: Keep mic open!
            recognition.interimResults = true; 
            recognition.lang = 'en-US';

            // Note: In continuous mode, we don't need manual accumulator if we read all results.
            // But sometimes clearing results is tricky. 
            // We'll rely on event.results and ONLY clear when we submit.

            recognition.onresult = (event) => {
                if (isProcessingAnswer) return; // FIX: Ignore trailing results if already submitting

                let currentFinal = '';
                let currentInterim = '';

                // In continuous mode, event.results accumulates history until we stop()
                for (let i = 0; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        currentFinal += event.results[i][0].transcript;
                    } else {
                        currentInterim += event.results[i][0].transcript;
                    }
                }
                
                // Combine for display and logic
                const totalText = currentFinal + currentInterim;
                
                // Update UI - Unified "Hearing" state
                if (totalText.trim().length > 0) {
                     document.getElementById('aiStatusText').textContent = `Hearing: "${totalText}"...`;
                }

                // Reset logic
                clearTimeout(silenceTimer);
                resetSilenceBar();
                
                // Timer Logic
                if (totalText.trim().length > 1) {
                     startSilenceBar();
                     silenceTimer = setTimeout(() => {
                        console.log("Silence timer fired (Continuous)!");
                        handleUserAnswer(totalText); // Submit total text
                    }, 4000); 
                }
            };
            
            function startSilenceBar() {
                const container = document.getElementById('silenceBarContainer');
                const fill = document.getElementById('silenceBarFill');
                if(!container || !fill) return;

                container.style.display = 'block';
                // Force reflow
                fill.getBoundingClientRect(); 
                fill.style.transition = 'width 4s linear';
                fill.style.width = '100%';
            }

            recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                if (event.error === 'no-speech') {
                    // It can legitimately happen if user is silent. Provide a subtle hint.
                    const aiStatus = document.getElementById('aiStatusText');
                    if (aiStatus && aiStatus.textContent === 'Listening...') {
                        aiStatus.textContent = 'Listening... (Speak clearly/louder)';
                    }
                } else if (event.error === 'network') {
                    // Chrome specific issue, usually due to offline or adblockers blocking the Google Speech API
                    hadNetworkError = true;
                    const aiStatus = document.getElementById('aiStatusText');
                    if (aiStatus) {
                        aiStatus.innerHTML = 'Listening... <span style="color: #f59e0b; font-size:12px;">(Network slow, using backup audio)</span>';
                    }
                    // Prevent infinite restart loops on hard network failures
                    // We let it continue so the MediaRecorder (which doesn't need this API) can still capture audio.
                    isRecognizing = false; // Force state so it knows it failed
                }
            };

            recognition.onend = () => {
                isRecognizing = false;
                console.log("Recognition ended. Auto-restarting...");

                // Only auto-restart if:
                // 1. Mic is supposedly "on" (user didn't mute)
                // 2. AI is NOT speaking (TTS is inactive)
                // 3. We are NOT currently processing an answer (prevent loops during evaluation)
                // 4. We didn't just have a hard network error (which causes infinite loops)
                if (isMicOn && !isAISpeaking && !isProcessingAnswer && currentQuestionIndex < questions.length && !hadNetworkError) {
                    // Force restart with a small delay
                    setTimeout(() => startListening(), 500);
                } else {
                    resetSilenceBar(); // Ensure bar is hidden only when recognition TRULY stops (not on auto-restarts)
                }
            };
        }

        // Helper: Start Listening safely
        function startListening() {
            if (isRecognizing) return;
            if (isProcessingAnswer) return; // Don't start if processing

            try {
                hadNetworkError = false; // Reset error flag on fresh start
                recognition.start();
                isRecognizing = true;
                // document.getElementById('aiStatusText').textContent = 'Listening...';
            } catch (e) {
                // If error says "already started", we are good. Otherwise log it.
                if (e.message && e.message.includes('already started')) {
                    isRecognizing = true;
                } else {
                    console.warn("Recognition start error:", e.message);
                    // Don't infinite loop retry on network errors or DOM exceptions
                    if (!e.message.includes('network') && !e.message.includes('Network')) {
                         setTimeout(() => startListening(), 1000); // Retry
                    }
                }
            }
        }

        // Helper: Stop Listening safely
        function stopListening() {
            try {
                recognition.stop();
                isRecognizing = false;
                clearTimeout(silenceTimer); // Fix: Clear timer when stopping
                resetSilenceBar(); // Fix: Hide bar clearly
            } catch (e) {
                console.warn("Error stopping recognition:", e);
            }
        }

        // Ask Question
        function askQuestion(index) {
            if (index >= questions.length) {
                finishInterview();
                return;
            }

            currentQuestionIndex = index;
            const question = questions[index];

            document.getElementById('currentQuestion').textContent = index + 1;

            // Add to transcript
            addTranscript('AI Interviewer', question.question);

            // Stop listening while AI speaks
            stopListening();

            // Speak question
            speakText(question.question, () => {
                // After AI finishes speaking, start listening
                document.getElementById('aiStatusText').textContent = 'Listening...';
                
                // NEW: Start Audio Recording for Analysis
                startAudioRecording();

                if (isMicOn) {
                    // Delay speech recognition slightly to prevent Chrome mic locking conflicts with MediaRecorder
                    setTimeout(() => startListening(), 400);
                }
            });
        }

        // Speak Text (TTS)
        function speakText(text, callback) {
            // Ensure listening is off when speaking starts
            stopListening();
            
            isAISpeaking = true;
            document.getElementById('aiStatusText').textContent = 'Speaking...';
            document.getElementById('speakingIndicator').style.display = 'block';
            document.getElementById('aiAvatar').style.animation = 'pulse 0.5s ease-in-out infinite';

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'en-US';
            utterance.rate = 0.9;
            utterance.pitch = 1.0;

            utterance.onend = () => {
                isAISpeaking = false;
                document.getElementById('speakingIndicator').style.display = 'none';
                document.getElementById('aiAvatar').style.animation = 'pulse 2s ease-in-out infinite';
                if (callback) callback();
            };

            synthesis.speak(utterance);
        }

        // Handle User Answer
        async function handleUserAnswer(transcript) {
            if (isProcessingAnswer) return; // FIX: Prevent double submission
            if (!transcript || transcript.trim().length < 2) {
                return;
            }

            // Flag to prevent auto-restart in onend
            isProcessingAnswer = true;
            stopListening();

            // NEW: Stop Audio Recording and Analyze
            stopAndAnalyzeAudio(currentQuestionIndex);

            // Add to transcript
            addTranscript('You', transcript);

            // Evaluate answer
            try {
                const response = await fetch('../api/ai_service.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=evaluate_answer&question=${encodeURIComponent(questions[currentQuestionIndex].question)}&answer=${encodeURIComponent(transcript)}&jobRole=${encodeURIComponent(candidateData.targetRole)}`
                });

                const result = await response.json();
                const evalData = result.evaluation;

                // Scenario 1: Interaction (User requested repeat/clarification)
                if (evalData.type === 'interaction') {
                    addTranscript('AI Interviewer', evalData.message);
                    
                    speakText(evalData.message, () => {
                        // Re-enable listening for the same question
                        isProcessingAnswer = false;
                        document.getElementById('aiStatusText').textContent = 'Listening...';
                        if (isMicOn) startListening();
                    });
                    return;
                }

                // Scenario 2: Standard Evaluation
                answers.push({
                    questionId: questions[currentQuestionIndex].id,
                    question: questions[currentQuestionIndex].question,
                    type: questions[currentQuestionIndex].type,
                    answer: transcript,
                    evaluation: evalData
                });

                // AI acknowledgment
                const feedback = evalData.feedback || "Thank you.";
                const shortFeedback = "Thank you. " + feedback.split('.')[0] + ".";

                speakText(shortFeedback, () => {
                    // Move to next question
                    isProcessingAnswer = false;
                    setTimeout(() => askQuestion(currentQuestionIndex + 1), 1000);
                });

            } catch (error) {
                console.error('Evaluation error:', error);
                isProcessingAnswer = false;
                // If error, just retry scanning 
                document.getElementById('aiStatusText').textContent = 'Error. Listening...';
                if (isMicOn) startListening();
            }
        }

        // Add Transcript
        function addTranscript(speaker, text) {
            const panel = document.getElementById('transcriptionPanel');
            const item = document.createElement('div');
            item.className = 'transcript-item';

            const speakerClass = speaker === 'AI Interviewer' ? 'ai' : 'user';
            item.innerHTML = `
                <div class="transcript-speaker ${speakerClass}">${speaker}:</div>
                <div class="transcript-text">${text}</div>
            `;

            panel.appendChild(item);
            panel.scrollTop = panel.scrollHeight;
        }

        // NEW: Start Audio Recording
        function startAudioRecording() {
            if (!userStream) {
                console.warn("User stream not ready for recording.");
                return;
            }
            try {
                mediaRecorder = new MediaRecorder(userStream);
                audioChunks = [];

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.start();
                console.log("Audio analysis recording started...");
            } catch (e) {
                console.error("Failed to start audio analysis recording:", e);
            }
        }
        
        // NEW: Stop Audio and Trigger Analysis
        function stopAndAnalyzeAudio(index) {
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.onstop = () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    // Capture Promise
                    const p = sendAudioAnalysis(audioBlob, index);
                    analysisPromises.push(p);
                };
                mediaRecorder.stop();
                console.log("Audio analysis recording stopped for Q" + (index + 1) + "...");
            }
        }

        async function sendAudioAnalysis(audioBlob, index) {
             const formData = new FormData();
             formData.append('action', 'analyze_uploaded_audio');
             formData.append('audio_data', audioBlob, 'answer.webm');
             
             // Add Context Data (Blink & Emotion)
             const blinkTotalEl = document.getElementById('blink-total-count');
             const blinkBpmEl = document.getElementById('blink-bpm');
             const blinkStatusEl = document.getElementById('blink-status');

             formData.append('blink_data', JSON.stringify({
                 total: blinkTotalEl ? blinkTotalEl.textContent : "0",
                 bpm: blinkBpmEl ? blinkBpmEl.textContent : "0",
                 status: blinkStatusEl ? blinkStatusEl.textContent : "Unknown"
             }));
             
             formData.append('emotion_data', JSON.stringify(emotionTotals));
             
             // NEW: Pass question context so the AI can generate a relevant Model Answer
             if (questions[index]) {
                  formData.append('question', questions[index].question);
             }
             if (candidateData && candidateData.targetRole) {
                  formData.append('jobRole', candidateData.targetRole);
             }

             console.log("Sending audio analysis with context:", emotionTotals);
             
             // Capture snapshot of emotion totals for this specific Answer
             // const currentEmotionSnapshot = { ...emotionTotals }; 
             // Ideally we'd reset emotionTotals per question, but cumulative is requested. 
             // We'll save the cumulative state here.
             
             try {
                 const response = await fetch('../api/ai_service.php', {
                     method: 'POST',
                     body: formData
                 });
                 const result = await response.json();
                 console.log("Gemini Analysis Result:", result);
                 if (result.debug_key_index) {
                     console.log("%c[Gemini API] Used Key Index: " + result.debug_key_index, "color: #10b981; font-weight: bold;");
                 }
                 
                 if (result.success) {
                     // NEW: Save to Session Data
                     // Check if data for this question already exists to prevent duplicates
                     const existingIndex = multimodalSessionData.findIndex(item => item.questionIndex === index);
                     
                     if (existingIndex === -1) {
                         multimodalSessionData.push({
                             questionIndex: index,
                             question: questions[index].question,
                             blinkData: {
                                 total: blinkTotalEl ? blinkTotalEl.textContent : "0",
                                 bpm: blinkBpmEl ? blinkBpmEl.textContent : "0",
                                 status: blinkStatusEl ? blinkStatusEl.textContent : "Unknown"
                             },
                             emotionData: { ...emotionTotals }, // Clone
                             audioAnalysis: result.data.analysis || {},
                             transcription: result.data.transcription || ""
                         });
                    } else {
                         console.log("Updated existing multimodal data for Q" + (index + 1));
                         // Optionally update the existing entry if this is a better/failover attempt
                         multimodalSessionData[existingIndex].audioAnalysis = result.data.analysis || multimodalSessionData[existingIndex].audioAnalysis;
                         multimodalSessionData[existingIndex].transcription = result.data.transcription || multimodalSessionData[existingIndex].transcription;
                    }

                     // NEW: Update the main 'answers' array with Verbatim Transcript
                     // This ensures Firebase saves the detailed "um/ah" version
                     if (answers[index]) {
                         answers[index].answer = result.data.transcription || answers[index].answer;
                         
                         // NEW: Override Confidence Score with Weighted Audio Analysis Score
                         if (result.data.analysis && result.data.analysis.confidence_score !== undefined) {
                             if (!answers[index].evaluation) answers[index].evaluation = {};
                             
                             // The prompt returns 0-10 based on our formula.
                             // Ensure we parse it as a float/int.
                             const weightedScore = parseFloat(result.data.analysis.confidence_score);
                             if (!isNaN(weightedScore)) {
                                 answers[index].evaluation.confidence = weightedScore;
                                 
                                 // NEW: Capture Weighted Nervousness Score
                                 if (result.data.analysis.nervousness_score !== undefined) {
                                     const weightedNervous = parseFloat(result.data.analysis.nervousness_score);
                                     if (!isNaN(weightedNervous)) {
                                         answers[index].evaluation.nervousness = weightedNervous;
                                         // Clear legacy fields if any
                                         if (answers[index].evaluation.clarity) delete answers[index].evaluation.clarity; 
                                     }
                                 }

                                 // Capture Breakdown for debugging/console
                                 if (result.data.analysis.weighted_breakdown) {
                                     answers[index].evaluation.breakdown = result.data.analysis.weighted_breakdown;
                                 }
                                 
                                 console.log(`Updated Q${index+1} Scores -> Conf: ${weightedScore}, Nerv: ${answers[index].evaluation.nervousness}`);
                                 console.log(`Breakdown: ${result.data.analysis.weighted_breakdown}`);
                             }
                         }
                         
                         console.log("Updated Answer " + (index + 1) + " with verbatim transcript & weighted score.");
                         
                         // NEW: Force update Firebase immediately to prevent race condition
                         // If the user clicks "Finish" before this analysis completes, the 'answers' array
                         // sent by finishInterview might be stale.
                         // We update this specific answer node in Firebase to be sure.
                         if (candidateId) {
                            const answerRef = ref(db, `candidates/${candidateId}/interview/answers/${index}`);
                            update(answerRef, answers[index]).then(() => {
                                console.log(`Firebase updated for Q${index+1} (Async Audio Analysis)`);
                            }).catch(err => console.error("Firebase Async Update Failed:", err));
                         }
                     }

                     console.log("Saved multimodal data for Q" + (currentQuestionIndex + 1));
                 }

             } catch (e) {
                 console.error("Audio Analysis Upload Failed:", e);
             }
        }

        // Finish Interview
        async function finishInterview() {
            recognition.stop();

            speakText("Thank you for completing the interview. Your results are being processed.", async () => {
                
                // NEW: Wait for any pending audio analysis (fixes race condition for last question)
                if (analysisPromises.length > 0) {
                     document.getElementById('aiStatusText').textContent = 'Finalizing analysis...';
                     try {
                        await Promise.all(analysisPromises);
                        console.log("All audio analyses completed.");
                     } catch(e) {
                        console.error("Some analysis failed, proceeding anyway...", e);
                     }
                }

                // Calculate overall score
                let totalScore = 0;
                let count = 0;

                answers.forEach(ans => {
                    if (ans.evaluation) {
                        let qScore = 0;
                        let metrics = 0;
                        
                        if (ans.evaluation.confidence >= 0) {
                            qScore += ans.evaluation.confidence;
                            metrics++;
                        }
                        if (ans.evaluation.nervousness >= 0) {
                            // Nervousness: Lower is better, so flip it for scoring (10 - nervous)
                            qScore += (10 - ans.evaluation.nervousness);
                            metrics++;
                        } else if (ans.evaluation.clarity >= 0) {
                             // Fallback for old data
                            qScore += ans.evaluation.clarity;
                            metrics++;
                        }
                        
                        // If we have relevance/accuracy in old data, we can ignore or include. 
                        // User wants to remove them, so let's stick to Confidence + Nervousness (Calmness)
                        
                        const avgScore = metrics > 0 ? (qScore / metrics) : 0;
                        totalScore += avgScore;
                        count++;
                    }
                });

                const overallScore = count > 0 ? Math.round((totalScore / count) * 10) : 0;

                // NEW: Generate AI Overall Summary
                let aiSummary = "Summary not available.";
                try {
                     document.getElementById('aiStatusText').textContent = 'Generating Final Report...';
                     
                     const formData = new FormData();
                     formData.append('action', 'generate_multimodal_summary');
                     formData.append('session_data', JSON.stringify(multimodalSessionData));
                     formData.append('jobRole', candidateData.targetRole || 'Candidate');
                     
                     const summaryRes = await fetch('../api/ai_service.php', {
                         method: 'POST',
                         body: formData
                     });
                     const summaryData = await summaryRes.json();
                     if (summaryData.debug_key_index) {
                         console.log("%c[Gemini Summary] Used Key Index: " + summaryData.debug_key_index, "color: #10b981; font-weight: bold;");
                     }
                     
                     if (summaryData.success) {
                         aiSummary = summaryData.summary;
                     }
                } catch (e) {
                    console.error("Summary generation failed", e);
                }

                // Save to Firebase
                const candidateRef = ref(db, `candidates/${candidateId}`);
                await update(candidateRef, {
                    interview: {
                        questions: questions,
                        answers: answers,
                        overallScore: overallScore,
                        completedAt: Date.now(),
                        interviewType: 'video',
                        multimodal: multimodalSessionData,
                        aiSummary: aiSummary
                    },
                    status: 'interview_completed'
                });

                // Redirect to report
                setTimeout(() => {
                    window.location.href = `report.php?id=${candidateId}`;
                }, 2000);
            });
        }

        // Control Buttons
        document.getElementById('micBtn').onclick = () => {
            isMicOn = !isMicOn;
            const btn = document.getElementById('micBtn');
            const icon = btn.querySelector('i');

            if (isMicOn) {
                btn.classList.add('active');
                icon.classList.remove('fa-microphone-slash');
                icon.classList.add('fa-microphone');
                // Use safe helper instead of direct call
                if (!isAISpeaking) startListening();
            } else {
                btn.classList.remove('active');
                icon.classList.remove('fa-microphone');
                icon.classList.add('fa-microphone-slash');
                recognition.stop();
            }
/*
            if (isMicOn) {
            btn.classList.add('active');
            icon.classList.remove('fa-microphone-slash');
            icon.classList.add('fa-microphone');

        if (!isAISpeaking) startListening();
        } else {
            btn.classList.remove('active');
            icon.classList.remove('fa-microphone');
            icon.classList.add('fa-microphone-slash');

            recognition.stop();
        }*/
        };

        document.getElementById('cameraBtn').onclick = () => {
            isCameraOn = !isCameraOn;
            const btn = document.getElementById('cameraBtn');
            const video = document.getElementById('userVideo');
            const icon = btn.querySelector('i');

            if (userStream) {
                userStream.getVideoTracks()[0].enabled = isCameraOn;
            }

if (isCameraOn) {
        btn.classList.add('active');
        icon.classList.remove('fa-video-slash');
        icon.classList.add('fa-video');
    } else {
        btn.classList.remove('active');
        icon.classList.remove('fa-video');
        icon.classList.add('fa-video-slash');
    }
        };

        document.getElementById('endBtn').onclick = () => {
            if (confirm('Are you sure you want to end the interview?')) {
                recognition.stop();
                synthesis.cancel();
                if (userStream) {
                    userStream.getTracks().forEach(track => track.stop());
                }
                window.location.href = 'index.php';
            }
        };

        document.getElementById('transcriptBtn').onclick = () => {
            const panel = document.getElementById('transcriptionPanel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        };

        // Start
        init();
    </script>
</body>

</html>