<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gemini PHP Test</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f0f2f5; color: #333; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { margin-top: 0; color: #2563eb; }
        textarea { width: 100%; height: 100px; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; font-family: inherit; }
        button { padding: 10px 20px; background: #2563eb; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background: #1d4ed8; }
        .response { background: #f8fafc; padding: 15px; border-radius: 5px; margin-top: 20px; border-left: 4px solid #2563eb; white-space: pre-wrap; }
        .error { background: #fef2f2; color: #dc2626; padding: 15px; border-radius: 5px; margin-top: 20px; border-left: 4px solid #dc2626; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gemini Simple Q&A (PHP)</h1>
        
        <form method="POST">
            <label for="question"><strong>Enter a simple question:</strong></label>
            <textarea name="question" id="question" required><?php echo isset($_POST['question']) ? htmlspecialchars($_POST['question']) : 'Do you know where the capital of Malaysia is?'; ?></textarea>
            <br>
            <button type="submit">Send</button>
        </form>

        <?php
        // API Key (from your snippet)
        $apiKey = "AIzaSyDm7D2vipnYIT3MaZ9c4fWN7Fzjolo_vPs";

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['question'])) {
            $question = $_POST['question'];
            
            // Model: Using gemini-1.5-flash as it is standard. 
            // The python script had 'gemini-2.5-flash-native-audio-dialog' which might be invalid.
            // If you specifically need that one, change the string below.
            $model = "gemini-2.5-flash-lite"; 
            
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";

            $data = [
                "contents" => [
                    [
                        "parts" => [
                            ["text" => $question]
                        ]
                    ]
                ]
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
            
            // Disable SSL verification for local testing if needed (not recommended for prod)
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

            $response = curl_exec($ch);
            
            if (curl_errno($ch)) {
                echo '<div class="error">Curl Error: ' . curl_error($ch) . '</div>';
            } else {
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $decoded = json_decode($response, true);

                if ($httpCode === 200 && isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
                    $answer = $decoded['candidates'][0]['content']['parts'][0]['text'];
                    echo '<div class="response"><strong>Answer:</strong><br>' . htmlspecialchars($answer) . '</div>';
                } else {
                    echo '<div class="error"><strong>API Error:</strong><br>';
                    echo 'HTTP Code: ' . $httpCode . '<br>';
                    echo 'Response: ' . htmlspecialchars($response);
                    echo '</div>';
                }
            }
            
            curl_close($ch);
        }
        ?>
    </div>
</body>
</html>
