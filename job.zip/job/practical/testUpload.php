<?php
// Handle File Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['pdfFile'])) {
    header('Content-Type: application/json');
    
    $targetDir = __DIR__ . '/pdf/';
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = basename($_FILES['pdfFile']['name']);
    $targetFilePath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    // Validate
    if($fileType != "pdf") {
        echo json_encode(['success' => false, 'message' => 'Only PDF files are allowed.']);
        exit;
    }

    if (move_uploaded_file($_FILES['pdfFile']['tmp_name'], $targetFilePath)) {
        // Return relative path for client usage
        echo json_encode([
            'success' => true, 
            'filepath' => 'pdf/' . $fileName,
            'message' => 'File uploaded to server'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Sorry, there was an error uploading your file.']);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Upload PDF Resume</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #1a1a2e; color: white; }
        .container { max-width: 600px; margin: 0 auto; }
        .form-group { margin-bottom: 20px; padding: 20px; background: rgba(255,255,255,0.05); border-radius: 8px; }
        input[type="file"] { margin-bottom: 10px; width: 100%; }
        button { padding: 10px 20px; background: #2563eb; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background: #1d4ed8; }
        button:disabled { background: #64748b; cursor: not-allowed; }
        #status { margin-top: 20px; padding: 15px; border-radius: 5px; white-space: pre-wrap; display: none; }
        .success { background: rgba(34, 197, 94, 0.2); border: 1px solid #22c55e; color: #4ade80; }
        .error { background: rgba(239, 68, 68, 0.2); border: 1px solid #ef4444; color: #f87171; }
        .info { background: rgba(59, 130, 246, 0.2); border: 1px solid #3b82f6; color: #60a5fa; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Test Upload PDF Resume</h1>
        <p>Select a PDF file. It will be saved to the <code>practical/pdf/</code> folder, and the path will be saved to Firebase.</p>
        
        <div class="form-group">
            <input type="file" id="pdfInput" accept=".pdf">
            <button id="uploadBtn">Upload PDF</button>
        </div>
        
        <div id="status"></div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        // Load config from PHP
        <?php require_once '../config.php'; echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        const statusDiv = document.getElementById('status');
        const uploadBtn = document.getElementById('uploadBtn');

        function log(message, type = 'info') {
            statusDiv.style.display = 'block';
            statusDiv.className = type;
            statusDiv.textContent = message;
        }

        uploadBtn.addEventListener('click', async () => {
            const fileInput = document.getElementById('pdfInput');
            const file = fileInput.files[0];

            if (!file) {
                log('Please select a PDF file first.', 'error');
                return;
            }

            if (file.type !== 'application/pdf') {
                log('Selected file is not a PDF.', 'error');
                return;
            }

            uploadBtn.disabled = true;
            log('Uploading to server...', 'info');

            try {
                // 1. Upload to Server (PHP)
                const formData = new FormData();
                formData.append('pdfFile', file);

                const serverResponse = await fetch('testUpload.php', {
                    method: 'POST',
                    body: formData
                });

                const serverResult = await serverResponse.json();

                if (!serverResult.success) {
                    throw new Error(serverResult.message);
                }

                const filePath = serverResult.filepath;
                log(`File saved to server at: ${filePath}\nSaving to Firebase...`, 'info');

                // 2. Save Path to Firebase
                const candidateId = 'TEST_' + Date.now();
                const newRef = ref(db, `candidates/${candidateId}`);
                
                await set(newRef, {
                    resume: {
                        filePath: filePath, // e.g., "pdf/filename.pdf"
                        originalName: file.name,
                        uploadedAt: Date.now()
                    },
                    status: 'pdf_uploaded',
                    source: 'testUpload.php',
                    targetRole: 'Test Role'
                });

                log(`Success! \n\n1. File: ${filePath}\n2. Firebase ID: ${candidateId}`, 'success');
                
            } catch (error) {
                console.error(error);
                log('Error: ' + error.message, 'error');
            } finally {
                uploadBtn.disabled = false;
            }
        });
    </script>
</body>
</html>
