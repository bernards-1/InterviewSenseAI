<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Resume - AI Interview Coach</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles.css">
    <style>
        .container { max-width: 1000px; margin: 0 auto; padding: 40px 20px; }
        .header { text-align: center; margin-bottom: 40px; }
        
        .resume-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .resume-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        .resume-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.08);
            border-color: #2563eb;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }

        .role-badge {
            background: rgba(37, 99, 235, 0.2);
            color: #60a5fa;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .date-text {
            color: #94a3b8;
            font-size: 12px;
        }

        .resume-preview {
            color: #cbd5e1;
            font-size: 14px;
            margin-bottom: 20px;
            max-height: 60px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .btn-sm {
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 6px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: background 0.2s;
        }

        .btn-text {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: none;
        }
        .btn-text:hover { background: rgba(255, 255, 255, 0.2); }

        .btn-video {
            background: rgba(37, 99, 235, 0.2);
            color: #60a5fa;
            border: 1px solid rgba(37, 99, 235, 0.5);
        }
        .btn-video:hover { background: rgba(37, 99, 235, 0.3); }

        .upload-new-card {
            border: 2px dashed rgba(255, 255, 255, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            min-height: 200px;
        }
        .upload-new-card:hover {
            border-color: #2563eb;
            background: rgba(37, 99, 235, 0.05);
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #94a3b8;
        }
    </style>
</head>
<body>
    <div class="bg-gradient"></div>
    <div class="orb orb-1"></div>
    
    <div class="container">
        <a href="index.php" class="nav-back">← Back</a>
        
        <div class="header">
            <h1>Select a Resume</h1>
            <p>Choose an existing resume or upload a new one to start practicing</p>
        </div>

        <div id="loading" class="loading">Loading candidates...</div>
        
        <div class="resume-grid" id="resumeGrid" style="display: none;">
            <!-- New Upload Card -->
            <a href="testUpload.php" class="resume-card upload-new-card" style="text-decoration: none;">
                <div style="font-size: 40px; margin-bottom: 10px;">+</div>
                <div style="color: white; font-weight: 600;">Upload New Resume</div>
            </a>
            
            <!-- Resumes will be injected here -->
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, get, query, orderByChild } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        // Load config from PHP
        <?php require_once '../config.php'; echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        async function loadCandidates() {
            const grid = document.getElementById('resumeGrid');
            const loading = document.getElementById('loading');
            
            try {
                const candidatesRef = ref(db, 'candidates');
                const snapshot = await get(candidatesRef); // Fetching all for now
                
                if (snapshot.exists()) {
                    const data = snapshot.val();
                    // Convert to array and sort by date (newest first)
                    const candidates = Object.entries(data)
                        .map(([key, value]) => ({ id: key, ...value }))
                        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

                    candidates.forEach(cand => {
                        // Skip test uploads if they don't have enough info, or render them differently
                        const role = cand.targetRole || 'General Interview';
                        const date = cand.createdAt ? new Date(cand.createdAt).toLocaleDateString() : 'Unknown Date';
                        
                        let previewText = 'No preview available';
                        if (cand.resume) {
                            if (cand.resume.rawText) previewText = cand.resume.rawText.substring(0, 150) + '...';
                            else if (cand.resume.filePath) previewText = `PDF: ${cand.resume.originalName || cand.resume.filePath}`;
                        }

                        const card = document.createElement('div');
                        card.className = 'resume-card';
                        card.innerHTML = `
                            <div class="card-header">
                                <span class="role-badge">${role}</span>
                                <span class="date-text">${date}</span>
                            </div>
                            <div class="resume-preview">${previewText}</div>
                            <div class="action-buttons" style="grid-template-columns: 1fr;">
                                <a href="video_interview.php?id=${cand.id}" class="btn-sm btn-video">🎥 Video Interview</a>
                            </div>
                        `;
                        grid.appendChild(card);
                    });
                }
                
                loading.style.display = 'none';
                grid.style.display = 'grid';

            } catch (error) {
                console.error(error);
                loading.textContent = 'Error loading candidates. Please check console.';
            }
        }

        loadCandidates();
    </script>
</body>
</html>
