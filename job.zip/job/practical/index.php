<?php
$title = "AI Interview Practice";
include("../includes/_JobSeekerLayout.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Portal - AI Interview Coach</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles.css">
    
    <!-- PDF.js & Tesseract.js -->
    <script src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
    <script>
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    </script>

    <style>
        .steps-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 40px 0;
        }

        .step-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 16px;
            text-align: center;
        }

        .step-number {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            margin: 0 auto 20px;
        }

        .step-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #fff;
        }

        .step-desc {
            color: #94a3b8;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div class="bg-gradient"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="container">
        

        <div class="header">
            <h1>AI Interview Coach</h1>
            <p>Practice interviews, get instant feedback, and improve your skills</p>
        </div>

        <div style="max-width: 500px; margin: 60px auto; background: linear-gradient(135deg, #4f46e5 0%, #818cf8 50%, #a855f7 100%); padding: 40px; border-radius: 20px; text-align: center;">

            <h2 style="margin-bottom: 20px;">Quick Start Interview</h2>
            
            <div style="margin-bottom: 20px; text-align: left;">
                <label style="display: block; margin-bottom: 8px; color: #cbd5e1;">Target Role (e.g., IT, Accounting)</label>
                <input type="text" id="roleInput" placeholder="Enter job role..." style="width: 100%; padding: 12px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px; font-size: 16px;">
            </div>

            <div style="margin-bottom: 20px; text-align: left;">
                <label style="display: block; margin-bottom: 8px; color: #cbd5e1;">Upload Resume (PDF only)</label>
                <input type="file" id="resumeInput" accept=".pdf" style="width: 100%; padding: 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: white; border-radius: 8px;">
            </div>

            <div id="ocrStatus" style="margin-bottom: 15px; color: #000000ff; font-size: 14px; display: none;"></div>
            
            <button id="startBtn" class="btn btn-primary" style="width: 100%; font-size: 18px; padding: 15px;">
                Start Interview →
            </button>
            <p style="margin-top: 15px; font-size: 14px; color: #000000ff;">Common questions will be generated based on this role & resume.</p>
        </div>

        <script type="module">
            import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
            import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

            <?php require_once '../config.php'; echo getFirebaseConfigJS(); ?>

            const app = initializeApp(firebaseConfig);
            const db = getDatabase(app);

            // Get logged-in user's Ref No from PHP
            const userRefNo = "<?php echo $ref_no ?? ''; ?>";

            document.getElementById('startBtn').addEventListener('click', async () => {
                const role = document.getElementById('roleInput').value.trim();
                const fileInput = document.getElementById('resumeInput');
                const startBtn = document.getElementById('startBtn');
                const statusDiv = document.getElementById('ocrStatus');
                
                if (!role) {
                    alert('Please enter a target role first.');
                    return;
                }

                const file = fileInput.files[0];
                let resumeText = "Guest User - Quick Interview Mode";

                startBtn.disabled = true;

                try {
                    // Extract text if file is present
                    if (file) {
                        if (file.type !== 'application/pdf') {
                            alert('Please upload a PDF file.');
                            startBtn.disabled = false;
                            return;
                        }

                        statusDiv.style.display = 'block';
                        statusDiv.textContent = 'Initializing OCR engine...';
                        startBtn.textContent = 'Scanning Resume...';

                        resumeText = await extractTextFromPDF(file, (status) => {
                            statusDiv.textContent = status;
                        });
                    }

                    statusDiv.textContent = 'Creating interview session...';
                    startBtn.textContent = 'Initializing...';

                    // Create Candidate ID: Use Ref No if available, else Generate
                    const candidateId = userRefNo ? userRefNo : ('CAND_' + Date.now());
                    const candidateData = {
                        candidateId: candidateId,
                        targetRole: role,
                        resume: { 
                            structured: { 
                                name: "Candidate", 
                                summary: "Extracted via OCR",
                                rawText: resumeText 
                            } 
                        },
                        createdAt: Date.now(),
                        status: 'interview_ready'
                    };

                    await set(ref(db, `candidates/${candidateId}`), candidateData);
                    
                    // Redirect to video interview
                    window.location.href = `video_interview.php?id=${candidateId}`;
                    
                } catch (error) {
                    console.error(error);
                    alert('Error: ' + error.message);
                    startBtn.disabled = false;
                    startBtn.textContent = 'Start Interview →';
                    statusDiv.style.display = 'none';
                }
            });

            // OCR Helper Function
            async function extractTextFromPDF(file, updateStatus) {
                updateStatus('Loading PDF...');
                const arrayBuffer = await file.arrayBuffer();
                const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
                
                let fullText = "";
                const numPages = pdf.numPages;

                // Initialize Tesseract Worker
                const worker = await Tesseract.createWorker('eng');

                for (let i = 1; i <= numPages; i++) {
                    updateStatus(`Scanning Page ${i} of ${numPages}...`);
                    
                    const page = await pdf.getPage(i);
                    const viewport = page.getViewport({ scale: 2.5 }); // High res for better OCR
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    await page.render({
                        canvasContext: context,
                        viewport: viewport
                    }).promise;

                    // Recognize
                    const { data } = await worker.recognize(canvas);
                    
                    // Use blocks for better column handling
                    if (data.blocks && data.blocks.length > 0) {
                         fullText += data.blocks.map(block => block.text.trim()).join('\n\n') + "\n\n";
                    } else {
                         fullText += data.text + "\n\n";
                    }
                }

                await worker.terminate();
                updateStatus('OCR Complete!');
                return fullText;
            }
        </script>


    </div>
</body>

</html>