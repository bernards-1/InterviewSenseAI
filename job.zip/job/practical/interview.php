<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Interview - Practice Session</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles.css">
    <style>
        .interview-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .progress-bar {
            background: rgba(255, 255, 255, 0.05);
            height: 8px;
            border-radius: 4px;
            margin-bottom: 30px;
            overflow: hidden;
        }

        .progress-fill {
            background: linear-gradient(90deg, #2563eb 0%, #9333ea 100%);
            height: 100%;
            transition: width 0.3s ease;
        }

        .question-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            margin-bottom: 30px;
        }

        .question-type {
            display: inline-block;
            background: rgba(37, 99, 235, 0.2);
            color: #60a5fa;
            padding: 6px 14px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .question-text {
            font-size: 24px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 30px;
            line-height: 1.4;
        }

        .answer-area {
            margin-bottom: 20px;
        }

        .answer-area textarea {
            width: 100%;
            min-height: 150px;
            padding: 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: white;
            font-size: 16px;
            font-family: inherit;
            resize: vertical;
        }

        .button-group {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
        }

        .loading-state {
            text-align: center;
            padding: 60px 20px;
        }
    </style>
</head>

<body>
    <div class="bg-gradient"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="container interview-container">
        <a href="upload_resume.php" class="nav-back">← Back</a>

        <div class="header">
            <h1>AI Interview Practice</h1>
            <p id="roleDisplay">Loading...</p>
        </div>

        <div class="progress-bar">
            <div class="progress-fill" id="progressBar" style="width: 0%"></div>
        </div>

        <div id="loadingState" class="loading-state">
            <div class="spinner"></div>
            <p>Generating personalized interview questions...</p>
        </div>

        <div id="interviewContent" style="display: none;">
            <div class="question-card">
                <span class="question-type" id="questionType">Technical</span>
                <div class="question-text" id="questionText"></div>

                <div class="answer-area">
                    <label style="display: block; margin-bottom: 10px; color: #cbd5e1; font-weight: 600;">Your
                        Answer:</label>
                    <textarea id="answerInput" placeholder="Type your answer here..."></textarea>
                </div>

                <div class="button-group">
                    <button class="btn btn-secondary" id="skipBtn" onclick="skipQuestion()">Skip</button>
                    <button class="btn btn-primary" id="submitBtn" onclick="submitAnswer()">Submit Answer →</button>
                </div>
            </div>

            <div style="text-align: center; color: #94a3b8;">
                <p>Question <span id="currentQ">1</span> of <span id="totalQ">8</span></p>
            </div>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, get, update } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        <?php require_once '../config.php';
        echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        const urlParams = new URLSearchParams(window.location.search);
        const candidateId = urlParams.get('id');

        if (!candidateId) {
            alert('No candidate ID provided');
            window.location.href = 'upload_resume.php';
        }

        let candidateData = null;
        let questions = [];
        let currentQuestionIndex = 0;
        let answers = [];

        // Load candidate data and generate questions
        const candidateRef = ref(db, `candidates/${candidateId}`);
        get(candidateRef).then(async (snapshot) => {
            if (!snapshot.exists()) {
                alert('Candidate not found');
                window.location.href = 'upload_resume.php';
                return;
            }

            candidateData = snapshot.val();
            document.getElementById('roleDisplay').textContent = `Position: ${candidateData.targetRole}`;

            // Generate questions
            const response = await fetch('../api/ai_service.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=generate_questions&resume=${encodeURIComponent(JSON.stringify(candidateData.resume.structured))}&jobRole=${encodeURIComponent(candidateData.targetRole)}`
            });

            const result = await response.json();
            questions = result.questions;

            document.getElementById('totalQ').textContent = questions.length;
            document.getElementById('loadingState').style.display = 'none';
            document.getElementById('interviewContent').style.display = 'block';

            showQuestion(0);
        });

        function showQuestion(index) {
            if (index >= questions.length) {
                finishInterview();
                return;
            }

            const question = questions[index];
            currentQuestionIndex = index;

            document.getElementById('questionType').textContent = question.type.replace('_', ' ').toUpperCase();
            document.getElementById('questionText').textContent = question.question;
            document.getElementById('answerInput').value = '';
            document.getElementById('currentQ').textContent = index + 1;

            const progress = ((index + 1) / questions.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
        }

        window.submitAnswer = async function () {
            const answer = document.getElementById('answerInput').value.trim();

            if (!answer) {
                alert('Please provide an answer');
                return;
            }

            const submitBtn = document.getElementById('submitBtn');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Evaluating...';

            try {
                // Evaluate answer
                const response = await fetch('../api/ai_service.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=evaluate_answer&question=${encodeURIComponent(questions[currentQuestionIndex].question)}&answer=${encodeURIComponent(answer)}&jobRole=${encodeURIComponent(candidateData.targetRole)}`
                });

                const result = await response.json();

                answers.push({
                    questionId: questions[currentQuestionIndex].id,
                    question: questions[currentQuestionIndex].question,
                    type: questions[currentQuestionIndex].type,
                    answer: answer,
                    evaluation: result.evaluation
                });

                // Move to next question
                showQuestion(currentQuestionIndex + 1);

            } catch (error) {
                console.error('Error:', error);
                alert('Error evaluating answer');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Answer →';
            }
        };

        window.skipQuestion = function () {
            if (confirm('Are you sure you want to skip this question?')) {
                answers.push({
                    questionId: questions[currentQuestionIndex].id,
                    question: questions[currentQuestionIndex].question,
                    type: questions[currentQuestionIndex].type,
                    answer: '',
                    evaluation: null
                });
                showQuestion(currentQuestionIndex + 1);
            }
        };

        async function finishInterview() {
            // Calculate overall score
            let totalScore = 0;
            let count = 0;

            answers.forEach(ans => {
                if (ans.evaluation) {
                    const avgScore = (ans.evaluation.relevance + ans.evaluation.clarity + ans.evaluation.confidence + ans.evaluation.accuracy) / 4;
                    totalScore += avgScore;
                    count++;
                }
            });

            const overallScore = count > 0 ? Math.round((totalScore / count) * 10) : 0;

            // Save to Firebase
            await update(candidateRef, {
                interview: {
                    questions: questions,
                    answers: answers,
                    overallScore: overallScore,
                    completedAt: Date.now()
                },
                status: 'interview_completed'
            });

            // Redirect to report
            window.location.href = `report.php?id=${candidateId}`;
        }
    </script>
</body>

</html>