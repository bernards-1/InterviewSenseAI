<?php
$title = "AI Practice Report";
include '../includes/_JobSeekerLayout.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interview Report - AI Interview Coach</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./styles.css">
    <style>
        .report-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .score-card {
            background: linear-gradient(135deg, #2563eb 0%, #9333ea 100%);
            padding: 50px;
            border-radius: 20px;
            text-align: center;
            margin-bottom: 30px;
        }

        .score-number {
            font-size: 72px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .score-label {
            font-size: 20px;
            opacity: 0.9;
        }

        .section {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 16px;
            margin-bottom: 20px;
        }

        .section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #fff;
        }

        .feedback-item {
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .feedback-item:last-child {
            border-bottom: none;
        }

        .score-bar {
            background: rgba(255, 255, 255, 0.1);
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 8px;
        }

        .score-bar-fill {
            background: linear-gradient(90deg, #00ffab 0%, #3b82f6 100%);
            height: 100%;
            transition: width 0.5s ease;
        }

        .suggestion {
            background: rgba(37, 99, 235, 0.1);
            border-left: 3px solid #2563eb;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }
    </style>
</head>

<body>
    <div class="bg-gradient"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="container report-container">
    

        <div class="header">
            <h1>Your Interview Report</h1>
            <p id="roleDisplay">Loading...</p>
        </div>

        <div id="loadingState" class="loading">
            <div class="spinner"></div>
            <p>Generating your report...</p>
        </div>

        <div id="reportContent" style="display: none;">
            <!-- Score card removed by user request -->



            <div class="section">
                <h2>📊 Performance Breakdown</h2>
                <div id="dimensionScores"></div>
            </div>

            <!-- NEW: Multimodal Analysis Section -->
            <div class="section" id="multimodalSection" style="display: none;">
                <h2>🎭 Communication Analysis (Multimodal)</h2>
                <div id="multimodalContent"></div>
            </div>



<!--         <div class="section">
                <h2>📚 Personalized Recommendations</h2>
                <div id="recommendations"></div>
            </div>
-->
            <!--<div style="text-align: center; margin-top: 40px;">
                <button class="btn btn-primary" onclick="window.location.href='upload_resume.php'"
                    style="font-size: 18px; padding: 18px 40px;">
                    Practice Again →
                </button>
            </div>-->
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        <?php require_once '../config.php';
        echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        const urlParams = new URLSearchParams(window.location.search);
        const candidateId = urlParams.get('id');

        if (!candidateId) {
            alert('No candidate ID provided');
            window.location.href = 'upload_resume.php';
        }

        const candidateRef = ref(db, `candidates/${candidateId}`);
        get(candidateRef).then((snapshot) => {
            if (!snapshot.exists()) {
                alert('Candidate not found');
                window.location.href = 'upload_resume.php';
                return;
            }

            const data = snapshot.val();
            generateReport(data);

            document.getElementById('loadingState').style.display = 'none';
            document.getElementById('reportContent').style.display = 'block';
        });

        function generateReport(data) {
            document.getElementById('roleDisplay').textContent = `Position: ${data.targetRole}`;
            


            // Calculate dimension averages
            const dimensions = { confidence: [], nervousness: [] };
            data.interview.answers.forEach((ans, index) => {
                if (ans.evaluation) {
                    // Core Active Metrics
                    if (ans.evaluation.confidence !== undefined) dimensions.confidence.push(ans.evaluation.confidence);
                    
                    // Handle nervousness (formerly clarity)
                    let nervScore = ans.evaluation.nervousness;
                    if (nervScore === undefined && ans.evaluation.clarity !== undefined) {
                        nervScore = ans.evaluation.clarity; 
                    }
                    if (nervScore !== undefined) dimensions.nervousness.push(nervScore);
                    
                    // DEBUG: Log breakdown for user visibility in Console
                    console.group(`📝 Question ${index + 1} Analysis Breakdown`);
                    console.log(`Question: "${ans.question}"`);
                    console.log(`User Answer: "${ans.answer}"`);
                    console.log(`--- SCORES ---`);
                    console.log(`🔹 Confidence Score (Weighted): ${ans.evaluation.confidence}/10`);
                    if (ans.evaluation.breakdown) {
                        console.log(`   └─ Calculation: ${ans.evaluation.breakdown}`);
                    } else {
                        console.log(`   └─ Calculation: Standard AI Evaluation (No detailed breakdown available for old data)`);
                    }
                    console.log(`🔸 Nervousness Score: ${nervScore}/10`);
                    console.log(`   └─ Note: Lower is better. 0=Calm, 10=Very Nervous.`);
                    console.groupEnd();
                }
            });

            const avgDimensions = {
                nervousness: avg(dimensions.nervousness),
                confidence: avg(dimensions.confidence)
            };

            // Display dimension scores (Confidence & Nervousness)
            let dimensionHTML = '';

            // NEW: Calculate Cumulative Stats (Blinks & Emotions)
            // We assume the last entry in multimodal array has the cumulative totals 
            // because video_interview.php sends cumulative 'emotionTotals' and 'blinkTotal'.
            
            let totalBlinks = 0;
            let emotionStatsHTML = '';
            let avgBpm = 0;
            let blinkStatus = "Normal";
            let durationStr = "0:00";
            
            if (data.interview.multimodal && data.interview.multimodal.length > 0) {
                // Find the entry with the latest data
                const sortedMM = [...data.interview.multimodal].sort((a, b) => b.questionIndex - a.questionIndex);
                const latestData = sortedMM[0];

                // 1. Total Blinks & Time
                if (latestData.blinkData) {
                    totalBlinks = parseInt(latestData.blinkData.total) || 0;
                    avgBpm = parseFloat(latestData.blinkData.bpm) || 0;
                    blinkStatus = latestData.blinkData.status || "Normal";

                    if (avgBpm > 0) {
                        const estimatedSeconds = (totalBlinks / avgBpm) * 60;
                        const mins = Math.floor(estimatedSeconds / 60);
                        const secs = Math.floor(estimatedSeconds % 60);
                        durationStr = `${mins}:${secs.toString().padStart(2, '0')}`;
                    }
                }

                // 2. Emotion Breakdown
                if (latestData.emotionData) {
                    let totalFrames = 0;
                    for (let count of Object.values(latestData.emotionData)) {
                        totalFrames += parseInt(count);
                    }

                    if (totalFrames > 0) {
                        const emoColors = {
                             'neutral': '#00a331ff', // Changed to green
                             'happy': '#34d399',
                             'surprise': '#fcd34d',
                             'fear': '#f87171',
                             'nervous': '#f87171',
                             'angry': '#8B0000',
                             'sad': '#60a5fa',
                             'disgust': '#a78bfa',
                             'thinking': '#fbbc04' // added thinking just in case
                        };

                        // We want to guarantee all 5 emotions are displayed
                        const allEmotions = ['angry', 'happy', 'nervous', 'neutral', 'thinking'];
                        let barsHTML = '';
                        
                        for (const emo of allEmotions) {
                            const count = latestData.emotionData[emo] || 0;
                            const pct = ((count / totalFrames) * 100).toFixed(1);
                            
                            const color = emoColors[emo.toLowerCase()] || '#cbd5e1';
                            barsHTML += `
                                <div style="display: flex; align-items: center; justify-content: space-between; font-size: 13px; margin-bottom: 4px;">
                                    <span style="color: ${color}; text-transform: capitalize; width: 80px;">${emo}</span>
                                    <div style="flex-grow: 1; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; margin: 0 10px;">
                                        <div style="width: ${pct}%; height: 100%; background: ${color}; border-radius: 3px;"></div>
                                    </div>
                                    <span style="color: #cbd5e1; min-width: 40px; text-align: right;">${pct}%</span>
                                </div>
                            `;
                        }
                        
                        emotionStatsHTML = `
                            <div style="background: rgba(255,255,255,0.03); border-radius: 8px; padding: 15px; margin-bottom: 20px;">
                                <h4 style="color: #e2e8f0; margin: 0 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">😐 Emotion Analysis</h4>
                                ${barsHTML}
                            </div>
                        `;
                    }
                }
            }
            
            // 1. Confidence & Nervousness Scores (Moved to Top)
            // Map keys to display labels and colors
            const metricsConfig = {
                'confidence': { label: 'Confidence (Audio+Face+Eyeblink)', color: '#00ffab' },
                'nervousness': { label: 'Nervousness (Audio+Face+Eyeblink)', color: '#f59e0b' }
            };

            for (const [dim, config] of Object.entries(metricsConfig)) {
                let score = avgDimensions[dim] !== undefined ? avgDimensions[dim] : 0;
                
                // Dynamic Color Logic
                let barColor = config.color; // Default fallback
                
                if (dim === 'confidence') {
                    // Confidence: High is Good (Green), Low is Bad (Red)
                    if (score >= 8) barColor = '#00ffab'; // Green
                    else if (score >= 5) barColor = '#f59e0b'; // Orange
                    else barColor = '#ef4444'; // Red
                } else if (dim === 'nervousness') {
                    // Nervousness: High is Bad (Red), Low is Good (Green)
                    if (score >= 7) barColor = '#ef4444'; // Red (Very Nervous)
                    else if (score >= 4) barColor = '#f59e0b'; // Orange
                    else barColor = '#00ffab'; // Green (Calm)
                }

                dimensionHTML += `
                    <div class="feedback-item">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="color: #cbd5e1; text-transform: capitalize;">${config.label}</span>
                            <span style="color: ${barColor}; font-weight: 600;">${score.toFixed(1)}/10</span>
                        </div>
                        <div class="score-bar">
                            <div class="score-bar-fill" style="width: ${score * 10}%; background-color: ${barColor}"></div>
                        </div>
                    </div>
                `;
            }

            // 2. Add Emotion Breakdown
            dimensionHTML += emotionStatsHTML;

            // 3. Blink Analysis (Moved to Bottom)
            // Color coding for status
            let statusColor = '#94a3b8'; // Default gray
            if (blinkStatus.toLowerCase().includes('nervous') || blinkStatus.toLowerCase().includes('low')) statusColor = '#fcd34d'; // Yellow/Warn
            if (blinkStatus.toLowerCase().includes('high') || blinkStatus.toLowerCase().includes('stare')) statusColor = '#ff0000ff'; // Red/Bad

            dimensionHTML += `
                <div style="background: rgba(255, 255, 255, 0.11); border-radius: 8px; padding: 20px; margin-bottom: 20px;">
                    <h4 style="color: #e2e8f0; margin: 0 0 15px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">👀 Blink Analysis</h4>
                    
                    <div style="display: flex; justify-content: space-around; text-align: center;">
                        <!-- BPM -->
                        <div>
                            <div style="font-size: 28px; font-weight: 700; color: #fff;">${avgBpm.toFixed(1)} <span style="font-size: 14px; color: #ffffffff; font-weight: 400;">BPM</span></div>
                            <div style="color: ${statusColor}; font-size: 14px; margin-top: 4px;">${blinkStatus}</div>
                        </div>
                        
                        <!-- Divider -->
                        <div style="width: 1px; background: rgba(255, 255, 255, 1);"></div>

                        <!-- Total & Time -->
                        <div>
                            <div style="font-size: 14px; color: #ffffffff;">Total Blinks: <span style="color: #fff; font-weight: 600;">${totalBlinks}</span></div>
                            <div style="font-size: 14px; color: #ffffffff; margin-top: 4px;">Est. Time: <span style="color: #fff; font-weight: 600;">${durationStr}</span></div>
                        </div>
                    </div>
                </div>
            `;

            document.getElementById('dimensionScores').innerHTML = dimensionHTML;





            // NEW: Multimodal Analysis Display -> "Summary for Each Question"
            if (data.interview.multimodal) {
                document.getElementById('multimodalSection').style.display = 'block';
                // Update Header Text: "Communication Analysis (Multimodal)" -> "Detailed Summary & Guidance"
                document.querySelector('#multimodalSection h2').textContent = "📝 Detailed Summary & Guidance";
                
                let mmHtml = '';

                data.interview.multimodal.forEach((item) => {
                    const qNum = (item.questionIndex + 1);
                    const prompt = item.question || `Question ${qNum}`;
                    const tone = item.audioAnalysis?.tone || 'N/A';
                    const feedback = (item.audioAnalysis?.multimodal_feedback || "No feedback available.").trim();
                    let rawGuidance = (item.audioAnalysis?.answer_guidance || "No specific guidance provided.").trim();
                    
                    // Parse basic Markdown bolding (**text**) into HTML strong tags
                    rawGuidance = rawGuidance.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                    
                    // Parse lists and apply justify alignment with hanging indents
                    const guidanceHtml = rawGuidance.split('\n').map(line => {
                        // Ordered list (e.g. "1. Text")
                        let numMatch = line.match(/^[ \t]*(\d+\.)[ \t]+(.*)$/);
                        if (numMatch) {
                            return `<div style="display: flex; margin-top: 10px;"><div style="min-width: 24px; font-weight: bold;">${numMatch[1]}</div><div style="flex: 1; text-align: justify;">${numMatch[2]}</div></div>`;
                        }
                        
                        // Unordered list (e.g. "* Text" or "- Text")
                        let bulletMatch = line.match(/^[ \t]*[\*\-][ \t]+(.*)$/);
                        if (bulletMatch) {
                            return `<div style="display: flex; margin-top: 6px; padding-left: 24px;"><div style="min-width: 16px;">•</div><div style="flex: 1; text-align: justify;">${bulletMatch[1]}</div></div>`;
                        }
                        
                        // Empty line
                        if (line.trim() === '') return `<div style="height: 8px;"></div>`;
                        
                        // Regular text
                        return `<div style="text-align: justify; margin-top: 4px;">${line}</div>`;
                    }).join('');

                    mmHtml += `
                        <div class="feedback-item">
                            <div style="margin-bottom: 15px; color: #fff; font-weight: 600; font-size: 1.1em;">
                                Q${qNum}: ${prompt}
                            </div>
                            
                            <!-- 1. AI Feedback on Delivery -->
                            <div style="margin-bottom: 12px;">
                                <div style="font-size: 12px; color: #3a3a3aff; text-transform: uppercase;"><strong>AI Feedback</strong></div>
                                <div style="color: #e2e8f0; font-style: italic; margin-top: 4px;">
                                    "${feedback}"
                                </div>
                            </div>
                            
                            <!-- 2. AI Guidance on Content -->
                            <div style="background: rgba(0, 0, 0, 0.09); border-left: 4px solid #34d399; padding: 16px; border-radius: 6px;">
                                <div style="font-size: 12px; color: #34d399; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">⚠️ Areas for Improvement</div>
                                <div style="color: #f8fafc; margin-top: 8px; font-size: 14.5px; line-height: 1.6;">${guidanceHtml}</div>
                            </div>
                            
                            <!-- 3. Suggested Answer (NEW) -->
                            ${item.audioAnalysis?.suggested_answer ? `
                            <div style="background: rgba(0, 0, 0, 0.09); border-left: 4px solid #60a5fa; padding: 16px; border-radius: 6px; margin-top: 12px;">
                                <div style="font-size: 12px; color: #60a5fa; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">✨ Model Answer</div>
                                <div style="color: #f8fafc; margin-top: 8px; font-size: 14.5px; font-style: italic; line-height: 1.6;">
                                    "${item.audioAnalysis.suggested_answer}"
                                </div>
                            </div>` : ''}
                        </div>
                    `;
                });
                document.getElementById('multimodalContent').innerHTML = mmHtml;
            }

            // Generate recommendations
            const recEl = document.getElementById('recommendations');
            if (recEl) {
                const recommendations = generateRecommendations(avgDimensions, data.targetRole);
                recEl.innerHTML = recommendations.map(rec =>
                    `<div class="suggestion">${rec}</div>`
                ).join('');
            }
        }

        function avg(arr) {
            return arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
        }

        function generateRecommendations(dimensions, role) {
            const recs = [];

            if (dimensions.relevance < 7) {
                recs.push("📖 Practice answering questions directly and staying on topic. Before answering, take a moment to understand what the question is really asking.");
            }

            if (dimensions.clarity < 7) {
                recs.push("🗣️ Work on structuring your answers with a clear beginning, middle, and end. Use the STAR method (Situation, Task, Action, Result) for behavioral questions.");
            }

            if (dimensions.confidence < 7) {
                recs.push("💪 Build confidence by practicing more interviews. Use assertive language and avoid hedging words like 'maybe' or 'I think'.");
            }

            if (dimensions.accuracy < 7) {
                recs.push("🎯 Include specific examples and experiences in your answers. Quantify your achievements when possible (e.g., 'improved performance by 30%').");
            }

            recs.push(`📚 Study common ${role} interview questions and prepare strong examples from your experience.`);
            recs.push("🎥 Consider recording yourself answering questions to identify areas for improvement in delivery and body language.");

            return recs;
        }
    </script>
</body>

</html>