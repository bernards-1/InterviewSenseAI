<?php
require_once 'c:/xampp/htdocs/job/includes/firebase_helper.php';
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);
$apps = $fb->get("tbl_job_applications");
echo "Applications:\n";
print_r($apps);

$jobs = $fb->get("tbl_jobs");
echo "\nJobs:\n";
print_r($jobs);
