<?php
session_start();
require_once 'c:/xampp/htdocs/job/includes/firebase_helper.php';
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

$company_ref_no = $_GET['comp'] ?? 'CMP698dfad5c3694';

$allJobs = $fb->get("tbl_jobs") ?? [];
$companyJobs = [];
foreach ($allJobs as $job) {
    if (($job['company_ref_no'] ?? '') === $company_ref_no) {
        $companyJobs[] = $job;
    }
}

$allApplications = $fb->get("tbl_job_applications") ?? [];
$dailyApps = [];
foreach ($allApplications as $app) {
    $jobRef = $app['job_ref_no'] ?? '';
    $isCompanyJob = false;
    foreach ($companyJobs as $cj) {
        if ($cj['job_ref_no'] == $jobRef) {
            $isCompanyJob = true; break;
        }
    }
    if ($isCompanyJob) {
        $date = substr($app['createdAt'] ?? '', 0, 10);
        if ($date) {
            if (!isset($dailyApps[$date])) $dailyApps[$date] = 0;
            $dailyApps[$date]++;
        }
    }
}

echo "Company Ref: $company_ref_no\n";
echo "Company Jobs:\n";
print_r($companyJobs);
echo "\nDaily Apps:\n";
print_r($dailyApps);

$chartDates = [];
$chartCounts = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartDates[] = date('M d', strtotime($d));
    $chartCounts[] = $dailyApps[$d] ?? 0;
}
echo "\nChart Counts:\n";
print_r($chartCounts);
print_r($chartDates);
