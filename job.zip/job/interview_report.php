<?php
$path_prefix = './';
$title = 'Interview Report - AI Interview Coach';
// Start buffering for Extra Head (Styles, etc.)
ob_start();
?>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="practical/styles.css">
    <style>
        .report-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .score-card {
            background: linear-gradient(135deg, #3d76f3 0%, #b168f5 100%);
            padding: 50px;
            border-radius: 20px;
            text-align: center;
            margin-bottom: 30px;
        }

        .score-number {
            font-size: 72px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .score-label {
            font-size: 20px;
            opacity: 0.9;
        }

        .section {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.50);
            padding: 30px;
            border-radius: 16px;
            margin-bottom: 20px;
        }

        .section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #fff;
        }

        .feedback-item {
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.19);
        }

        .feedback-item:last-child {
            border-bottom: none;
        }

        .score-bar {
            background: rgba(255, 255, 255, 0.19);
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 8px;
        }

        .score-bar-fill {
            background: linear-gradient(90deg, #f66a6a 0%, #3bf667 100%);
            height: 100%;
            transition: width 0.5s ease;
        }

        .suggestion {
            background: rgba(37, 99, 235, 0.1);
            border-left: 3px solid #2563eb;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }
    </style>
<?php $extra_head = ob_get_clean(); ob_start(); ?>
    <div class="bg-gradient"></div>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="container report-container">
        

        <div class="header">
            <h1>Interview Session Report</h1>
            <p id="roleDisplay">Loading...</p>
        </div>

        <div id="loadingState" class="loading">
            <div class="spinner"></div>
            <p>Retrieving session data...</p>
        </div>

        <div id="reportContent" style="display: none;">
            <!-- AI Summary Card -->
            <div class="score-card" style="text-align: left; padding: 25px;">
                <h3 style="margin: 0 0 10px 0; font-size: 16px; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">🤖 AI Interview Summary</h3>
                <div id="aiSummaryText" style="font-size: 15px; line-height: 1.6; color: #e2e8f0; font-weight: 400;">
                    Loading AI assessment...
                </div>
            </div>

            <div class="section">
                <h2>📊 Session Performance</h2>
                <div id="dimensionScores"></div>
            </div>

            <!-- NEW: AI Feedback Section -->
            <div class="section" id="aiFeedbackSection" style="display: none;">
                <h2>🤖 AI Interview Feedback</h2>
                <div class="suggestion" id="aiSummaryText" style="font-size: 16px; line-height: 1.6; color: #e2e8f0; background: rgba(37, 99, 235, 0.15); border-left: 4px solid #3b82f6;">
                    Loading AI analysis...
                </div>
            </div>

            <!-- NEW: Multimodal Analysis Section -->
            <div class="section" id="multimodalSection" style="display: none;">
                <h2>⏱️ Timeline Analysis (Every 30s)</h2>
                <div id="multimodalContent"></div>
            </div>

            <!-- <div style="text-align: center; margin-top: 40px;">
                <button class="btn btn-primary" onclick="window.location.href='video_call.php'"
                    style="font-size: 18px; padding: 18px 40px;">
                    Start New Call →
                </button>
            </div> -->
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, get, update, query, orderByChild, equalTo } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        <?php require_once 'config.php';
        echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        const urlParams = new URLSearchParams(window.location.search);
        // Support new restructuring: interview_candidates/JobRef/AppRef
        const jobId = urlParams.get('job_id');
        const appId = urlParams.get('application_id');
        
        // Legacy fallbacks
        const seekerId = urlParams.get('jobseeker_id');
        const legacyId = urlParams.get('id');

        if ((!jobId || !appId) && (!appId || !seekerId) && !legacyId) {
            alert('No session ID provided');
            window.location.href = 'video_call.php';
        }

        let dbPath = '';
        if (jobId && appId) {
             // Newest structure
            dbPath = `interview_candidates/${jobId}/${appId}`;
            document.getElementById('roleDisplay').textContent = `Job: ${jobId} | App: ${appId}`;
        } else if (appId && seekerId) {
            // Previous nested structure
            dbPath = `interview_candidates/${appId}/${seekerId}`;
            document.getElementById('roleDisplay').textContent = `App: ${appId} | Seeker: ${seekerId}`;
        } else {
            // Legacy
            dbPath = `interview_candidates/${legacyId}`;
            document.getElementById('roleDisplay').textContent = `Session ID: ${legacyId}`;
        }

        const candidateRef = ref(db, dbPath);
        get(candidateRef).then((snapshot) => {
            if (!snapshot.exists()) {
                alert('Session Report not found');
                window.location.href = 'video_call.php';
                return;
            }

            const data = snapshot.val();
            
            // --- NEW: Fetch Candidate Name using AppID ---
            // --- NEW: Fetch Candidate Name using AppID ---
            if (appId) {
                console.log("Fetching application data for:", appId);
                // 1. Get Job Seeker Ref from Application
                get(ref(db, `tbl_job_applications/${appId}`)).then((appSnap) => {
                    if (appSnap.exists()) {
                        const appData = appSnap.val();
                        console.log("Application Data:", appData);
                        const seekerRefNo = appData.jobseeker_ref_no; // e.g., USR...
                        
                        if (seekerRefNo) {
                            // 2. Query Job Seeker Table by ref_no 
                            // FALLBACK: Use manual filtering since 'ref_no' index is missing in Firebase Rules
                            // (Avoids "Index not defined" error for small datasets)
                            get(ref(db, 'tbl_jobseeker')).then((snap) => {
                                if (snap.exists()) {
                                    const allSeekers = snap.val();
                                    let foundSeeker = null;
                                    
                                    // Search manually
                                    for (const key in allSeekers) {
                                        if (allSeekers[key].ref_no === seekerRefNo) {
                                            foundSeeker = allSeekers[key];
                                            break;
                                        }
                                    }

                                    if (foundSeeker) {
                                        const fullName = foundSeeker.name || `${foundSeeker.firstname || ''} ${foundSeeker.lastname || ''}`.trim();
                                        if (fullName) {
                                            document.getElementById('roleDisplay').textContent = `Candidate: ${fullName}`; // Display Name with Prefix
                                        } 
                                    } 
                                } 
                            }).catch(err => console.error("Error fetching jobseeker list:", err));
                        } else {
                             console.warn("No jobseeker_ref_no found in application data");
                        }
                    } else {
                        console.warn("Application not found in Firebase at tbl_job_applications/" + appId);
                    }
                }).catch(err => console.error("Error fetching application:", err));
            }

            generateReport(data);

            document.getElementById('loadingState').style.display = 'none';
            document.getElementById('reportContent').style.display = 'block';
        });

        function generateReport(data) {
            const displayId = seekerId || legacyId;
            document.getElementById('roleDisplay').textContent = `Session ID: ${displayId}`;
            if (data.interview.aiSummary && data.interview.aiSummary !== "Summary not available.") {
                // Show AI Summary
                const summaryEl = document.getElementById('aiSummaryText');
                // Convert newlines to <br> for better readability if needed
                summaryEl.innerHTML = data.interview.aiSummary.replace(/\n/g, '<br>');
            } else {
                // Fallback / Retroactive (If no summary yet)
                document.getElementById('aiSummaryText').innerHTML = `
                    <p style="color: #94a3b8; font-style: italic;">AI assessment pending or not available. Please generate it below if possible.</p>
                `;
            }

            // --- Dimensions ---
            // In room.php we calculated one overall "answer" with keys confidence/nervousness
            // But verify structure: answers: [{ evaluation: { confidence, nervousness } }]
            let dimConf = 0;
            let dimNerv = 0;
            
            if (data.interview.answers && data.interview.answers.length > 0) {
                 const evalData = data.interview.answers[0].evaluation;
                 dimConf = evalData.confidence || 0;
                 dimNerv = evalData.nervousness || 0;
            }

            // Display dimension scores
            let dimensionHTML = '';
            
            const metricsConfig = {
                'confidence': { label: 'Avg. Confidence (Audio+Face+Eyeblink)', val: dimConf },
                'nervousness': { label: 'Avg. Nervousness (Audio+Face+Eyeblink)', val: dimNerv }
            };

            for (const [key, config] of Object.entries(metricsConfig)) {
                let s = config.val;
                let barColor = '#10b981';
                
                if (key === 'confidence') {
                    if (s >= 8) barColor = '#10b981'; 
                    else if (s >= 5) barColor = '#f59e0b'; 
                    else barColor = '#ef4444';
                } else {
                     // Low nerv is good
                    if (s >= 7) barColor = '#ef4444'; 
                    else if (s >= 4) barColor = '#f59e0b'; 
                    else barColor = '#10b981';
                }

                dimensionHTML += `
                    <div class="feedback-item">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="color: #cbd5e1;">${config.label}</span>
                            <span style="color: ${barColor}; font-weight: 600;">${s.toFixed(1)}/10</span>
                        </div>
                        <div class="score-bar">
                            <div class="score-bar-fill" style="width: ${s * 10}%; background-color: ${barColor}"></div>
                        </div>
                    </div>
                `;
            }

             // --- Cumulative Emotion & Blinks ---
            let emotionStatsHTML = '';
            let totalBlinks = 0;
            let avgBpm = 0;
            
            // Get latest snapshot
            if (data.interview.multimodal && data.interview.multimodal.length > 0) {
                 // Sort descending by index to get last one
                 const items = [...data.interview.multimodal].sort((a,b) => b.questionIndex - a.questionIndex);
                 const latest = items[0];
                 
                 // 1. Emotion (Cumulative in snapshot)
                 if (latest.emotionData) {
                    let totalFrames = 0;
                    for (let count of Object.values(latest.emotionData)) totalFrames += parseInt(count);

                     if (totalFrames > 0) {
                        const emoColors = {
                             'happy': '#00ffa2ff', 
                             'natural': '#00a331ff', // Alias for happy/natural
                             'neutral': '#00a331ff', // Changed to green
                             'nervous': '#f87171', 
                             'angry': '#bc0000ff', 
                             'thinking': '#fbbc04'
                        };
                        
                        // We want to guarantee all 5 emotions are displayed
                        const allEmotions = ['angry', 'happy', 'nervous', 'neutral', 'thinking'];
                        let barsHTML = '';
                        
                        for (const emo of allEmotions) {
                             const count = latest.emotionData[emo] || 0;
                             const pct = ((count / totalFrames) * 100).toFixed(1);
                             
                             const c = emoColors[emo.toLowerCase()] || '#cbd5e1';
                             barsHTML += `
                                <div style="display: flex; align-items: center; justify-content: space-between; font-size: 13px; margin-bottom: 4px;">
                                    <span style="color: ${c}; text-transform: capitalize; width: 80px;">${emo}</span>
                                    <div style="flex-grow: 1; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; margin: 0 10px;">
                                        <div style="width: ${pct}%; height: 100%; background: ${c}; border-radius: 3px;"></div>
                                    </div>
                                    <span style="color: #cbd5e1; min-width: 40px; text-align: right;">${pct}%</span>
                                </div>`;
                        }
                        emotionStatsHTML = `
                            <div style="background: rgba(255, 255, 255, 0.21); border-radius: 8px; padding: 15px; margin-bottom: 20px;">
                                <h4 style="color: #e2e8f0; margin: 0 0 12px 0; font-size: 14px;">😐 Overall Emotions</h4>
                                ${barsHTML}
                            </div>`;
                     }
                 }
            }

            dimensionHTML += emotionStatsHTML;

            // --- NEW: Blink Analysis (Avg) ---
            if (data.interview.multimodal && data.interview.multimodal.length > 0) {
                // Calculate Avg BPM
                let totalBpm = 0;
                let count = 0;
                // Check if we have saved cumulative data in the first item (since we only save one now)
                const savedData = data.interview.multimodal[0].blinkData || {};
                
                if (savedData.durationSecs) {
                    // Use Saved Facts
                    avgBpm = parseFloat(savedData.bpm) || 0;
                    totalBlinks = parseInt(savedData.total) || 0;
                    // precise duration
                    var durationShow = (savedData.durationSecs / 60).toFixed(1); 
                } else {
                    // Legacy Estimation
                    data.interview.multimodal.forEach(m => {
                        if (m.blinkData && m.blinkData.bpm) {
                            totalBpm += parseFloat(m.blinkData.bpm);
                            count++;
                        }
                    });
                    avgBpm = count > 0 ? (totalBpm / count) : 0;
                    // Estimate Stats
                    var durationShow = (count * 0.5).toFixed(1); // Each interval is 30s
                    totalBlinks = Math.round(avgBpm * durationShow);
                }
                
                // Determine Status
                let blinkStatus = "Normal";
                let statusColor = '#94a3b8'; // Gray
                
                if (avgBpm < 10) { blinkStatus = "Low (Staring?)"; statusColor = '#f59e0b'; } // Yellow
                else if (avgBpm > 30) { blinkStatus = "High (Nervous?)"; statusColor = '#ef4444'; } // Red
                else { blinkStatus = "Normal Range"; statusColor = '#089945'; } // Green

                dimensionHTML += `
                    <div style="background: rgba(255, 255, 255, 0.21); border-radius: 8px; padding: 20px; margin-bottom: 20px;">
                        <h4 style="color: #e2e8f0; margin: 0 0 15px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">👀 Blink Analysis (Avg)</h4>
                        
                        <div style="display: flex; justify-content: space-around; text-align: center;">
                            <!-- BPM -->
                            <div>
                                <div style="font-size: 28px; font-weight: 700; color: #fff;">${avgBpm.toFixed(1)} <span style="font-size: 14px; color: #d1d9e3; font-weight: 400;">BPM</span></div>
                                <div style="color: ${statusColor}; font-size: 14px; margin-top: 4px; font-weight:bold;">${blinkStatus}</div>
                            </div>
                            
                            <!-- Divider -->
                            <div style="width: 1px; background: rgba(255, 255, 255, 0.42);"></div>

                            <!-- Total & Time -->
                            <!-- Divider -->
                            <div style="width: 1px; background: rgba(255, 255, 255, 0.42);"></div>

                            <!-- Total & Time -->
                            <div>
                                <div style="font-size: 14px; color: #fff;">Est. Total Blinks: <span style="color: #fff; font-weight: 600; ">${totalBlinks}</span></div>
                                <div style="font-size: 14px; color: #fff; margin-top: 4px;">Session Duration: <span style="color: #fff; font-weight: 600;">${durationShow}m</span></div>
                            </div>
                        </div>
                    </div>
                `;
            }

            document.getElementById('dimensionScores').innerHTML = dimensionHTML;

            // --- Show AI Summary (REMOVED AS PER REQUEST) ---
            /*
            if (data.interview.aiSummary && data.interview.aiSummary !== "Summary not available.") {
                document.getElementById('aiFeedbackSection').style.display = 'block';
                document.getElementById('aiSummaryText').textContent = data.interview.aiSummary;
                
            } else if (data.interview.multimodal && data.interview.multimodal.length > 0) {
                // Retroactive Generation
                document.getElementById('aiFeedbackSection').style.display = 'block';
                document.getElementById('aiSummaryText').innerHTML = `
                    <p style="margin: 0 0 10px 0; color: #cbd5e1;">AI Summary not generated yet.</p>
                    <button id="btnGenAI" style="padding: 10px 20px; background: #3b82f6; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 14px; transition: background 0.2s;">
                        ✨ Generate AI Feedback
                    </button>
                    <p id="genStatus" style="margin-top: 10px; font-size: 14px; color: #94a3b8; display: none;"></p>
                `;
                
                document.getElementById('btnGenAI').onclick = async () => {
                     // ... (Hidden generation logic) ...
                };
            }
            */

            /* 
            // --- TimeLine Analysis (HIDDEN AS PER REQUEST) ---
            if (data.interview.multimodal) {
                document.getElementById('multimodalSection').style.display = 'block';
                // ... (Code hidden to simplify report) ...
            }
            */
        }
    </script>
<?php $content = ob_get_clean(); include "./includes/company_layout.php"; ?>
