<?php
// firebase.php

// Firebase Realtime Database URL
$databaseURL = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";

// Node/path where you want to push data
$path = "users"; 

// Data to push
$data = [
    "first" => "weeeedlfja;lfjalf",
    "last" => "dafdasf",
    "born" => 1815,
    "timestamp" => time() * 1000 // milliseconds
];

// Generate a new unique key (like push() in JS)
$key = uniqid(); 

// Full URL for this entry
$url = $databaseURL . $path . "/" . $key . ".json";

// Initialize cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT"); // "PUT" to create/replace, "POST" for auto key generation
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

// Execute request
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "Error adding data: " . curl_error($ch);
} else {
    echo "Data saved successfully! Response: " . $response;
}

curl_close($ch);
?>
