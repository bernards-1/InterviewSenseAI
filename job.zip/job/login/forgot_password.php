<?php
// UI only
session_start();
$successMessage = $_SESSION['success'] ?? null;
unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Job Recruitment System</title>

    <!-- SAME CSS -->
    <link rel="stylesheet" href="../css/login.css" />
</head>
<body>

<div class="auth-container">
    <div class="auth-card card-medium">
        <div class="auth-header header-orange">
            <h2>Forgot Password</h2>
            <p>We'll send you an OTP to reset your password</p>
        </div>

        <div class="auth-body">

            <?php if ($successMessage): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($successMessage) ?>
                </div>
            <?php endif; ?>

            <div class="info-box">
                <strong>How it works:</strong><br>
                1. Enter your email address<br>
                2. Check your email for OTP<br>
                3. Enter OTP and set new password
            </div>

            <!-- UI only -->
            <form method="post" action="#">

                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control"
                           placeholder="Enter your registered email">
                </div>

                <button type="submit" class="btn-block btn-orange">
                    Send OTP
                </button>
            </form>

            <div class="auth-links">
                <p>
                    Remember your password?
                    <a href="login.php">Back to Login</a>
                </p>
            </div>

        </div>
    </div>
</div>

<script src="../js/jquery.min.js"></script>

</body>
</html>
