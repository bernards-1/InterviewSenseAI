<?php
session_start();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email | Job Recruitment System</title>
    <style>
        .form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        textarea {
            width: 100%;
            height: 200px;
            resize: vertical;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .checkbox-group {
            margin: 15px 0;
        }
        
        .button-group {
            margin-top: 20px;
        }
        
        button {
            padding: 10px 20px;
            margin-right: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        button[type="submit"] {
            background: #007bff;
            color: white;
        }
        
        button[type="reset"] {
            background: #6c757d;
            color: white;
        }
        
        .validation-summary-errors {
            color: #dc3545;
            margin-bottom: 15px;
        }
        
        .field-validation-error {
            color: #dc3545;
            font-size: 14px;
        }

        .btn-secondary {
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Send Email</h2>

    <?php if (!empty($errors)): ?>
        <div class="validation-summary-errors">
            <?php foreach ($errors as $error): ?>
                <div><?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form class="form" method="post" action="send_email_process.php">
        <div class="form-group">
            <label>Recipient Email</label>
            <input name="email" type="email" autofocus value="<?= htmlspecialchars($old['email'] ?? '') ?>">
            <span class="field-validation-error">
                <?= htmlspecialchars($errors['email'] ?? '') ?>
            </span>
        </div>

        <div class="form-group">
            <label>Subject</label>
            <input name="subject" type="text" value="<?= htmlspecialchars($old['subject'] ?? '') ?>">
            <span class="field-validation-error">
                <?= htmlspecialchars($errors['subject'] ?? '') ?>
            </span>
        </div>

        <div class="form-group">
            <label>Message Body</label>
            <textarea name="body" placeholder="Enter your message here..."><?= htmlspecialchars($old['body'] ?? '') ?></textarea>
            <span class="field-validation-error">
                <?= htmlspecialchars($errors['body'] ?? '') ?>
            </span>
        </div>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="isBodyHtml" <?= !empty($old['isBodyHtml']) ? 'checked' : '' ?> />
                Format Body as HTML
            </label>
        </div>

        <div class="button-group">
            <button type="submit">Send Email</button>
            <button type="reset">Reset Form</button>
            <a href="login.php" class="btn btn-secondary">Back to Login</a>
        </div>
    </form>
</div>
</body>
</html>
