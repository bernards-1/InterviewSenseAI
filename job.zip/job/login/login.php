<?php
session_start();
$success = $_SESSION['success'] ?? null;
$info = $_SESSION['info'] ?? null;
unset($_SESSION['success'], $_SESSION['info']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Job Recruitment System</title>
    <link rel="stylesheet" href="../css/login.css" />
</head>

<body>
    <div class="auth-container">
        <div class="auth-card card-narrow">
            <div class="auth-header header-blue">
                <h2>Welcome Back</h2>
                <p>Sign in to your account</p>
            </div>

            <div class="auth-body">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <?= htmlspecialchars($success) ?>
                    </div>
                <?php endif; ?>

                <?php if ($info): ?>
                    <div class="alert alert-success">
                        <?= htmlspecialchars($info) ?>
                    </div>
                <?php endif; ?>

                <form action="../function/loginFunction.php" method="post">
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input name="email" class="form-control" placeholder="Enter your email" />
                    </div>

                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input name="password" type="password" class="form-control" placeholder="Enter your password" />
                    </div>

                    <button type="submit" name="Login" class="btn-block btn-blue">Sign In</button>

                    <div style="text-align: center; margin-top: 15px;">
                        <a href="forgot_password.php"
                            style="color: #3498db; text-decoration: none; font-size: 14px;">Forgot your password?</a>
                    </div>
                </form>

                <div class="divider">
                    <span>Don't have an account?</span>
                </div>

                <div class="register-options">
                    <a href="register_company.php" class="btn-outline btn-outline-red">
                        <span>🏢</span> Register as Company
                    </a>
                    <a href="register_jobseeker.php" class="btn-outline btn-outline-green">
                        <span>👤</span> Register as Job Seeker
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/jquery.min.js"></script>
    <script src="../js/jquery.validate.min.js"></script>
    <script src="../js/jquery.validate.unobtrusive.min.js"></script>
    <script>
        window.setTimeout(function () {
            $(".alert").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 3000);
    </script>
</body>

</html>