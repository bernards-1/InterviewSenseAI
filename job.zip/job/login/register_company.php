<?php
session_start();
$successMessage = $_SESSION['success'] ?? null;
unset($_SESSION['success']);
$error = $_SESSION['error'] ?? null;
unset($_SESSION['error']);

$company_name = '';
$email = '';

$address = '';
$state = '';
$city = '';

if (isset($_SESSION['old_inputs'])) {
    $company_name = $_SESSION['old_inputs']['company_name'] ?? '';
    $email = $_SESSION['old_inputs']['email'] ?? '';
   
    $address = $_SESSION['old_inputs']['address'] ?? '';
    $state = $_SESSION['old_inputs']['state'] ?? '';
    $city = $_SESSION['old_inputs']['city'] ?? '';
    unset($_SESSION['old_inputs']);
}

// PHP array for states (used for select options)
$states = ['Johor','Kedah','Kelantan','Kuala Lumpur','Labuan','Melaka','Negeri Sembilan',
           'Pahang','Penang','Perak','Perlis','Putrajaya','Sabah','Sarawak','Selangor','Terengganu'];

// PHP array for cities per state (used for old input preselection)
$cityData = [
    'Johor'=>['Johor Bahru','Batu Pahat','Muar','Segamat','Kluang','Kota Tinggi','Pontian','Mersing','Kulai','Tangkak'],
    'Kedah'=>['Alor Setar','Sungai Petani','Kulim','Langkawi','Jitra','Baling','Yan','Sik','Kuala Nerang','Pendang'],
    'Kelantan'=>['Kota Bharu','Pasir Mas','Tumpat','Bachok','Pasir Puteh','Tanah Merah','Kuala Krai','Machang','Gua Musang','Jeli'],
    'Kuala Lumpur'=>['Kuala Lumpur'],
    'Labuan'=>['Labuan'],
    'Melaka'=>['Melaka City','Alor Gajah','Jasin'],
    'Negeri Sembilan'=>['Seremban','Port Dickson','Nilai','Bahau','Kuala Pilah','Rembau','Jempol','Tampin'],
    'Pahang'=>['Kuantan','Temerloh','Bentong','Mentakab','Raub','Jerantut','Pekan','Rompin','Maran','Bera','Cameron Highlands'],
    'Penang'=>['George Town','Butterworth','Bukit Mertajam','Bayan Lepas','Nibong Tebal','Kepala Batas','Tasek Gelugor'],
    'Perak'=>['Ipoh','Taiping','Teluk Intan','Sitiawan','Kampar','Batu Gajah','Kuala Kangsar','Tapah','Gerik','Lumut','Parit Buntar'],
    'Perlis'=>['Kangar','Arau'],
    'Putrajaya'=>['Putrajaya'],
    'Sabah'=>['Kota Kinabalu','Sandakan','Tawau','Lahad Datu','Keningau','Semporna','Kudat','Ranau','Beaufort','Kota Belud'],
    'Sarawak'=>['Kuching','Miri','Sibu','Bintulu','Limbang','Sarikei','Sri Aman','Kapit','Mukah','Betong'],
    'Selangor'=>['Shah Alam','Petaling Jaya','Klang','Subang Jaya','Ampang','Selayang','Kajang','Semenyih','Rawang','Sepang','Kuala Selangor'],
    'Terengganu'=>['Kuala Terengganu','Kemaman','Dungun','Marang','Hulu Terengganu','Besut','Setiu']
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Company - Job Recruitment System</title>
    <link rel="stylesheet" href="../css/login.css" />
</head>

<body>
    <div class="auth-container">
        <div class="auth-card card-wide">
            <div class="auth-header header-red">
                <h2>Register as Company</h2>
                <p>Create your company account</p>
            </div>

            <div class="auth-body">

                <?php if ($successMessage): ?>
                    <div class="alert alert-success">
                        <?= htmlspecialchars($successMessage) ?>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger" style="color:red; margin-bottom:15px;">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <!-- UI only -->
                <form method="post" action="../function/loginFunction.php" id="companyRegisterForm" enctype="multipart/form-data">

                    <div class="form-group">
                        <label class="form-label">Company Name *</label>
                        <input type="text" name="company_name" class="form-control"
                            placeholder="Enter company name" value="<?= htmlspecialchars($company_name) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address *</label>
                        <input type="email" name="email" class="form-control"
                            placeholder="Enter company email" value="<?= htmlspecialchars($email) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Company Image / Logo</label>
                        <input type="file" name="company_logo" class="form-control"
                            accept="image/png, image/jpeg">
                        <small class="text-muted">Optional. PNG or JPG only.</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Company Address *</label>
                        <textarea name="address" class="form-control"
                                placeholder="Enter company address"
                                rows="3" style="resize:vertical;"><?= htmlspecialchars($address) ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">State *</label>
                            <select name="state" id="stateSelect" class="form-control">
                                <option value="">Select State</option>
                                <?php foreach($states as $s): ?>
                                    <option value="<?= $s ?>" <?= $state == $s ? 'selected' : '' ?>><?= $s ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">City *</label>
                            <select name="city" id="citySelect" class="form-control" <?= $state ? '' : 'disabled' ?>>
                                <option value="">Select City</option>
                                <?php
                                if ($state && isset($cityData[$state])) {
                                    foreach ($cityData[$state] as $c) {
                                        $selected = ($city == $c) ? 'selected' : '';
                                        echo "<option value=\"$c\" $selected>$c</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Password *</label>
                            <input type="password" name="password" class="form-control"
                                placeholder="Min 6 characters">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Confirm Password *</label>
                            <input type="password" name="confirm_password" class="form-control"
                                placeholder="Confirm password">
                        </div>
                    </div>

                    <button type="submit" name="companyRegister" class="btn-block btn-red">
                        Register Company
                    </button>
                </form>

                <div class="auth-links">
                    <p>Already have an account?
                        <a href="login.php">Sign in here</a>
                    </p>
                    <p>Want to register as job seeker?
                        <a href="register_jobseeker.php">Click here</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/jquery.min.js"></script>

    <script>
        const cityData = <?= json_encode($cityData) ?>;
        const oldCity = "<?= htmlspecialchars($city) ?>";

        document.addEventListener('DOMContentLoaded', () => {
            const state = document.getElementById('stateSelect');
            const city = document.getElementById('citySelect');

            function populateCities() {
                city.innerHTML = '<option value="">Select City</option>';
                city.disabled = !state.value;

                if(cityData[state.value]) {
                    cityData[state.value].forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c;
                        opt.textContent = c;
                        if(c === oldCity) opt.selected = true;
                        city.appendChild(opt);
                    });
                }
            }

            populateCities();
            state.addEventListener('change', populateCities);
        });
    </script>
</body>
</html>
