<?php
session_start();
$successMessage = $_SESSION['success'] ?? null;
unset($_SESSION['success']);
$error = $_SESSION['error'] ?? null;
unset($_SESSION['error']);

$full_name = '';
$email = '';
$phone = '';

if (isset($_SESSION['old_inputs'])) {
    $full_name = $_SESSION['old_inputs']['full_name'] ?? '';
    $email = $_SESSION['old_inputs']['email'] ?? '';
    $phone = $_SESSION['old_inputs']['phone'] ?? '';
    unset($_SESSION['old_inputs']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Job Seeker - Job Recruitment System</title>

    <!-- SAME CSS -->
    <link rel="stylesheet" href="../css/login.css" />
</head>

<body>

    <div class="auth-container">
        <div class="auth-card card-wide">
            <div class="auth-header header-green">
                <h2>Register as Job Seeker</h2>
                <p>Create your job seeker account</p>
            </div>

            <div class="auth-body">

                <?php if ($successMessage): ?>
                    <div class="alert alert-success">
                        <?= htmlspecialchars($successMessage) ?>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger" style="color: red; margin-bottom: 15px;">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <!-- UI only -->
                <form method="post" action="../function/loginFunction.php" id="jobseekerRegisterForm">

                    <div class="form-group">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" placeholder="Enter your full name"
                            value="<?= htmlspecialchars($full_name) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address *</label>
                        <input type="email" name="email" class="form-control" placeholder="Enter your email"
                            value="<?= htmlspecialchars($email) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Phone Number *</label>
                        <input type="text" name="phone" class="form-control" placeholder="Enter your phone number"
                            value="<?= htmlspecialchars($phone) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-control" placeholder="Min 6 characters">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-control"
                            placeholder="Confirm your password">
                    </div>

                    <button type="submit" name="jobseekerRegister" class="btn-block btn-green">
                        Register as Job Seeker
                    </button>
                </form>

                <div class="auth-links">
                    <p>
                        Already have an account?
                        <a href="login.php">Sign in here</a>
                    </p>
                    <p>
                        Want to register as company?
                        <a href="register_company.php">Click here</a>
                    </p>
                </div>

            </div>
        </div>
    </div>

    <script src="../js/jquery.min.js"></script>

</body>

</html>