<?php
// UI only
session_start();
$successMessage = $_SESSION['success'] ?? null;
unset($_SESSION['success']);

// Simulated data (replace later with real data)
$email = $_SESSION['reset_email'] ?? "example@email.com";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Job Recruitment System</title>

    <!-- SAME CSS -->
    <link rel="stylesheet" href="../css/login.css" />
</head>
<body>

<div class="auth-container">
    <div class="auth-card card-medium">
        <div class="auth-header header-green">
            <h2>Reset Password</h2>
            <p>Enter OTP and set new password</p>
        </div>

        <div class="auth-body">

            <?php if ($successMessage): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($successMessage) ?>
                </div>
            <?php endif; ?>

            <div class="info-box">
                <strong>Email:</strong> <?= htmlspecialchars($email) ?>
            </div>

            <!-- UI only -->
            <form method="post" action="#">

                <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">

                <div class="form-group">
                    <label class="form-label">OTP Code</label>
                    <input type="text" name="otp" class="form-control"
                           placeholder="Enter 6-digit OTP" maxlength="6" id="OTP">
                </div>

                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-control"
                           placeholder="Enter new password">
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control"
                           placeholder="Confirm new password">
                </div>

                <button type="submit" class="btn-block btn-green">
                    Reset Password
                </button>
            </form>

            <div class="auth-links">
                <p>
                    <a href="forgot_password.php">Resend OTP</a> |
                    <a href="login.php">Back to Login</a>
                </p>
            </div>

        </div>
    </div>
</div>

<script src="../js/jquery.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('OTP').focus();
    });
</script>

</body>
</html>
