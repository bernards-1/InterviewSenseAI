<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Room</title>
    <script src="https://download.agora.io/sdk/release/AgoraRTC_N-4.22.0.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #202124;
            color: white;
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        /* --- Header --- */
        header {
            position: absolute;
            top: 0; left: 0; right: 0;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(to bottom, rgba(0,0,0,0.7), transparent);
            z-index: 100;
        }
        .room-info {
            font-weight: 600;
            font-size: 18px;
            color: #fff;
            text-shadow: 0 1px 3px rgba(0,0,0,0.5);
        }
        .room-badge {
            background: #28a745;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 10px;
            vertical-align: middle;
        }

        /* --- Main Video Area (Remote) --- */
        #remote-container {
            flex: 1;
            position: relative;
            background: #202124;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* Remote players try to fill space */
        .remote-player {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        div[id^="player-"] {
            width: 100% !important;
            height: 100% !important;
            position: relative;
        }

        div[id^="player-"] video {
            object-fit: contain !important; /* Keep aspect ratio for remote, or cover if preferred */
        }

        /* Floating Name Tag */
        .player-name {
            position: absolute; bottom: 20px; left: 20px;
            background: rgba(0,0,0,0.6);
            color: white;
            padding: 5px 12px;
            border-radius: 4px;
            font-size: 14px;
            z-index: 10;
        }

        /* --- Local Video (PiP) --- */
        #local-container {
            position: absolute;
            bottom: 100px; /* Above controls */
            right: 20px;
            width: 240px;
            height: 135px; /* 16:9 */
            background: #333;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
            border: 2px solid rgba(255,255,255,0.2);
            z-index: 200;
            transition: all 0.3s ease;
        }

        #local-container:hover {
            transform: scale(1.05);
            border-color: #4facfe;
        }

        /* --- Controls Bar --- */
        .controls-bar {
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            background: linear-gradient(to top, rgba(0,0,0,0.9), transparent);
            z-index: 300;
        }

        .btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.1);
            color: white;
            backdrop-filter: blur(5px);
            transition: all 0.2s;
        }

        .btn:hover { background: rgba(255,255,255,0.2); transform: translateY(-2px); }
        .btn-active { background: #fff; color: #000; }
        .btn-danger { background: #ff4d4f; color: white; }
        .btn-danger:hover { background: #d9363e; }

        /* --- Modal --- */
        .modal { display: none; position: fixed; z-index: 9999; inset: 0; background: rgba(0,0,0,0.8); }
        .modal-content {
            position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
            background: #28292c; padding: 25px; border-radius: 12px; width: 90%; max-width: 400px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5); font-size: 14px;
        }

        /* --- Processing Overlay --- */
        #processing-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.85);
            z-index: 10000;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #4facfe;
            animation: spin 1s ease-in-out infinite;
            margin-bottom: 20px;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .processing-text {
            font-size: 18px;
            font-weight: 600;
            letter-spacing: 1px;
        }
        .processing-subtext {
            font-size: 13px;
            color: #9aa0a6;
            margin-top: 8px;
        }

        /* --- Analysis Panel (Company View) --- */
        .analysis-panel {
            position: absolute;
            top: 250px; /* Below Header */
            left: 20px;
            width: 180px;
            background: rgba(32, 33, 36, 0.90);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 15px;
            border: 1px solid #3c4043;
            z-index: 500; /* Above remote video */
        }
        .analysis-card {
            margin-bottom: 10px;
            text-align: center;
        }
        .analysis-label {
            font-size: 11px;
            color: #9aa0a6;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }
        .analysis-value {
            font-size: 20px;
            font-weight: 700;
            color: #fff;
        }
        .analysis-sub {
            font-size: 11px;
            color: #bdc1c6;
        }
    </style>
    <!-- Mediapipe Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js"></script>
</head>
<body>

    <header>
        <div class="room-info">
            Channel: <span id="room-name">...</span>
            <span class="room-badge">LIVE</span>
        </div>
    </header>

    <!-- Main Remote View -->
    <div id="remote-container">
        <div id="waiting-message" style="color: #555; font-size: 20px;">Waiting for others to join...</div>
    </div>

    <!-- Local View (Floating) -->
    <div id="local-container">
        <!-- Local User Video Here -->
    </div>

    <!-- NEW: Analysis Panel (Initially Hidden) -->
    <div class="analysis-panel" id="analysisPanel" style="display: none;">
        <!-- Emotion Analysis -->
        <div class="analysis-card">
            <div class="analysis-label">Emotion (Face)</div>
            <div class="analysis-value" id="emotion-label">WAITING</div>
            <div class="analysis-sub" id="emotion-conf"></div>
            
            <!-- NEW: Session Distribution -->
            <div class="analysis-sub" style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #3c4043;">
                <div style="text-align: center; margin-bottom: 5px; color: #bdc1c6;">Session Distribution (%)</div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px; text-align: left; font-size: 10px; color: #bdc1c6;">
                    <div id="dist-angry">angry: 0.0%</div>
                    <div id="dist-happy">happy: 0.0%</div>
                    <div id="dist-nervous">nervous: 0.0%</div>
                    <div id="dist-neutral">neutral: 0.0%</div>
                    <div id="dist-thinking">thinking: 0.0%</div>
                </div>
            </div>
        </div>
        <hr style="border: 0; border-top: 1px solid #3c4043; margin: 10px 0;">
        
        <!-- Audio Analysis (Hidden for background processing) -->
        <div class="analysis-card" style="display: none;">
            <div class="analysis-label">Audio Analysis</div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <div style="text-align: left;">
                    <div style="font-size: 10px; color: #9aa0a6;">CONFIDENCE</div>
                    <div class="analysis-value" style="font-size: 16px;" id="audio-conf">-</div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 10px; color: #9aa0a6;">NERVOUSNESS</div>
                    <div class="analysis-value" style="font-size: 16px;" id="audio-nerv">-</div>
                </div>
            </div>
            <div class="analysis-sub" id="audio-status" style="font-size: 9px;">Listening... (Updates ~30s)</div>
        </div>
        <hr style="border: 0; border-top: 1px solid #3c4043; margin: 10px 0; display: none;">

        <!-- Blink Analysis -->
        <div class="analysis-card">
            <div class="analysis-label">Blink Analysis</div>
            <div class="analysis-value">
                <span id="blink-bpm">0</span> <span style="font-size:14px;">BPM</span>
            </div>
            <div class="analysis-sub" id="blink-status">Calculating...</div>
            <div class="analysis-sub" style="margin-top: 5px; font-size: 10px; color: #787a7d;">Total Blinks: <span id="blink-total-count">0</span></div>
            <div id="session-time" style="display:none; font-size:10px; color:#5f6368; margin-top:5px;">00:00</div>
        </div>
    </div>

    <div class="controls-bar">
        <button class="btn btn-active" id="mic-btn" onclick="toggleMic()" title="Toggle Mic"><i class="fa-solid fa-microphone"></i></button>
        <button class="btn btn-active" id="cam-btn" onclick="toggleCam()" title="Toggle Cam"><i class="fa-solid fa-video"></i></button>
        <button class="btn btn-danger" onclick="leaveRoom()" title="Leave Call"><i class="fa-solid fa-phone-slash"></i></button>
    </div>

    <!-- Processing Overlay -->
    <div id="processing-overlay">
        <div class="spinner"></div>
        <div class="processing-text">Processing Interview Data...</div>
        <div class="processing-subtext">Generating AI Summary and Final Report</div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
        import { getDatabase, ref, update, set } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-database.js";

        <?php require_once 'config.php'; echo getFirebaseConfigJS(); ?>

        const app = initializeApp(firebaseConfig);
        const db = getDatabase(app);

        const urlParams = new URLSearchParams(window.location.search);
        const APP_ID = urlParams.get('appId');
        const CHANNEL = urlParams.get('channel');
        const TOKEN = urlParams.get('token');
        const UID = parseInt(urlParams.get('uid'));
        const USER_TYPE = urlParams.get('type');
        const APPLICATION_REF = urlParams.get('applicationRef') || 'UnknownRef'; // ID for Report
        const JOBSEEKER_REF = urlParams.get('jobseekerRef') || 'UnknownSeeker';
        const JOB_REF = urlParams.get('jobRefNo') || 'UnknownJob';

        // Global State for Report
        let emotionTotals = {};
        let multimodalSessionData = []; // Stores 30s chunks
        let audioRecorder = null;
        let audioChunks = [];
        let audioInterval = null;


        // --- NEW: Analysis Logic (Company Only) ---
        let faceMesh = null;
        let analysisActive = false;
        let analysisVideoElement = null;
        
        // Blink Constants
        const EAR_THRESHOLD = 0.20;
        const HYSTERESIS = 0.02;
        let isBlinking = false;
        let totalBlinks = 0;
        let sessionStartTime = 0;
        const LEFT_EYE = [33, 160, 158, 133, 153, 144];
        const RIGHT_EYE = [362, 385, 387, 263, 373, 380];

        // 1. Initialize FaceMesh (if Company)
        if (USER_TYPE === 'company') {
            document.getElementById('analysisPanel').style.display = 'block';
            
            faceMesh = new FaceMesh({
                locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
            });
            faceMesh.setOptions({
                maxNumFaces: 1,
                refineLandmarks: true,
                minDetectionConfidence: 0.5,
                minTrackingConfidence: 0.5
            });
            faceMesh.onResults(onFaceMeshResults);
        }

        // 2. Helpers
        function euclideanDist(p1, p2) {
            return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
        }

        function getEAR(landmarks, indices) {
            const p = indices.map(i => landmarks[i]);
            const v1 = euclideanDist(p[1], p[5]);
            const v2 = euclideanDist(p[2], p[4]);
            const h = euclideanDist(p[0], p[3]);
            if (h === 0) return 0;
            return (v1 + v2) / (2.0 * h);
        }

        // 3. Process Results (Blink Logic)
        function onFaceMeshResults(results) {
            if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
                const landmarks = results.multiFaceLandmarks[0];
                const earLeft = getEAR(landmarks, LEFT_EYE);
                const earRight = getEAR(landmarks, RIGHT_EYE);
                const avgEar = (earLeft + earRight) / 2.0;

                if (avgEar < EAR_THRESHOLD) {
                    if (!isBlinking) {
                        isBlinking = true;
                        totalBlinks++;
                    }
                } else {
                    if (isBlinking && avgEar > (EAR_THRESHOLD + HYSTERESIS)) {
                        isBlinking = false;
                    }
                }
            }

            // Update UI
            if (analysisActive) {
                const now = Date.now();
                const elapsedSec = (now - sessionStartTime) / 1000;
                const elapsedMin = elapsedSec / 60.0;
                
                // Time
                const m = Math.floor(elapsedSec / 60);
                const s = Math.floor(elapsedSec % 60);
                document.getElementById('session-time').textContent = `${m}:${s.toString().padStart(2, '0')}`;
                document.getElementById('blink-total-count').textContent = totalBlinks;

                // BPM
                let bpm = 0;
                if (elapsedMin > 0.05) {
                    bpm = totalBlinks / elapsedMin;
                } else if (elapsedMin > 0) {
                    bpm = totalBlinks * (60 / elapsedSec);
                }
                document.getElementById('blink-bpm').textContent = bpm.toFixed(1);

                // Status
                const statusEl = document.getElementById('blink-status');
                if (elapsedMin > 0.1) {
                    if (bpm >= 25) {
                        statusEl.textContent = "Nervous (High)";
                        statusEl.style.color = "rgb(255, 131, 131)";
                    } else if (bpm < 10) {
                        statusEl.textContent = "Low Blink";
                        statusEl.style.color = "#fbbc04"; 
                    } else {
                        statusEl.textContent = "Normal";
                        statusEl.style.color = "#34a853";
                    }
                }
            }
        }

        // 4. Start Analysis Loop
        function startRemoteAnalysis(videoEl) {
            if (analysisActive) return; 
            console.log("Starting Analysis on Remote Video...");
            analysisVideoElement = videoEl;
            analysisActive = true;
            sessionStartTime = Date.now();

            // Blink Loop
            const blinkLoop = async () => {
                 if (!analysisActive || !analysisVideoElement) return;
                 // Ensure video is playing and visible
                 if (analysisVideoElement.paused || analysisVideoElement.ended) {
                     requestAnimationFrame(blinkLoop);
                     return;
                 }
                 try {
                    await faceMesh.send({ image: analysisVideoElement });
                 } catch(e) { /* Ignore */ }
                 requestAnimationFrame(blinkLoop); 
            };
            blinkLoop();

            // Emotion Loop (1s Interval)
            setInterval(predictRemoteEmotion, 1000);
        }

        // 5. Emotion Prediction (Local Python API)
        async function predictRemoteEmotion() {
             if (!analysisActive || !analysisVideoElement) return;
             
             const canvas = document.createElement('canvas');
             canvas.width = analysisVideoElement.videoWidth || 640;
             canvas.height = analysisVideoElement.videoHeight || 480;
             if (canvas.width === 0) return;

             const ctx = canvas.getContext('2d');
             ctx.drawImage(analysisVideoElement, 0, 0, canvas.width, canvas.height);
             
             try {
                const dataURL = canvas.toDataURL('image/jpeg', 0.5); // Low quality
                const response = await fetch('http://127.0.0.1:5000/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image: dataURL })
                });
                const data = await response.json();

                if (data.success && data.result) {
                    const label = data.result.label;
                    const conf = (data.result.confidence * 100).toFixed(0);
                    
                    const el = document.getElementById('emotion-label');
                    const ec = document.getElementById('emotion-conf');
                    
                    el.textContent = label.toUpperCase();
                    //ec.textContent = `(${conf}%)`;
                    ec.textContent = ""; 

                    // Color Code
                    if (['happy', 'natural'].includes(label.toLowerCase())) {
                        el.style.color = '#34d399'; // Green (Report: #34d399)
                    } else if (label.toLowerCase() === 'neutral') {
                        el.style.color = '#34d399'; // Keep Neutral Greenish/Positive for Live UI (or #94a3b8 if strict)
                    } else if (label.toLowerCase() === 'angry') {
                        el.style.color = '#ff0000ff'; // Deep Red
                    } else if (['nervous', 'fear'].includes(label.toLowerCase())) {
                        el.style.color = 'rgba(255, 104, 104, 1)'; // Light Red
                    } else {
                        el.style.color = '#fbbc04'; // Yellow (Thinking/Surprise)
                    }

                    // Track Totals
                    if (!emotionTotals[label]) emotionTotals[label] = 0;
                    emotionTotals[label]++;

                    // UPDATE: Session Distribution UI
                    const allEmotions = ['angry', 'happy', 'nervous', 'neutral', 'thinking'];
                    let totalFrames = 0;
                    for (let key in emotionTotals) totalFrames += emotionTotals[key];

                    allEmotions.forEach(emo => {
                        const count = emotionTotals[emo] || 0;
                        const pct = totalFrames > 0 ? ((count / totalFrames) * 100).toFixed(1) : "0.0";
                        const distEl = document.getElementById(`dist-${emo}`);
                        if (distEl) {
                            const valColor = count > 0 ? '#fff' : '#bdc1c6';
                            const valWeight = count > 0 ? 'bold' : 'normal';
                            distEl.innerHTML = `${emo}: <span style="color: ${valColor}; font-weight: ${valWeight};">${pct}%</span>`;
                        }
                    });
                }
             } catch (err) { }
        }

        // 6. Audio Analysis Loop (Every 30s)
        function startAudioAnalysis(stream) {
            console.log("Starting Audio Analysis...");
            try {
                audioRecorder = new MediaRecorder(stream);
                audioRecorder.ondataavailable = e => audioChunks.push(e.data);
                
                audioRecorder.start();

                // Loop every 30s
                audioInterval = setInterval(() => {
                    if (audioRecorder.state === 'recording') {
                        audioRecorder.stop(); // Triggers analysis in onstop
                        // Restart immediate
                        setTimeout(() => {
                            audioChunks = [];
                            audioRecorder.start();
                        }, 500); 
                    }
                }, 30000); 

                audioRecorder.onstop = async () => {
                    const blob = new Blob(audioChunks, { type: 'audio/webm' });
                    // Send to API
                    // NEW: Collect History
                    let historyText = multimodalSessionData.map(d => d.transcription).join(" ");
                    
                    const formData = new FormData();
                    formData.append('action', 'analyze_live_audio_chunk');
                    formData.append('audio_data', blob);
                    formData.append('blink_data', document.getElementById('blink-bpm').textContent); 
                    formData.append('emotion_data', JSON.stringify(emotionTotals));
                    formData.append('history_context', historyText); // Send Old Context

                    document.getElementById('audio-status').textContent = "Analyzing chunk...";
                    
                    try {
                        const res = await fetch('api/ai_service.php', { method: 'POST', body: formData });
                        const json = await res.json();
                        if (json.success) {
                            const analysis = json.data.analysis;
                            const transcript = json.data.transcription || ""; // Get Transcript

                            console.log("Audio Analysis Result:", analysis);
                            console.log("Transcription:", transcript);

                            // Update UI
                            document.getElementById('audio-conf').textContent = analysis.confidence_score + "/10";
                            document.getElementById('audio-nerv').textContent = analysis.nervousness_score + "/10";
                            document.getElementById('audio-status').textContent = "Listening... (Updates ~30s)";
                            
                            // Store Data (Accumulate)
                            multimodalSessionData.push({
                                timestamp: Date.now(),
                                audio: analysis,
                                transcription: transcript, // Save for next loop
                                blinkBpm: document.getElementById('blink-bpm').textContent,
                                emotionSnapshot: { ...emotionTotals }
                            });
                        }
                    } catch (e) {
                         console.error(e);
                         document.getElementById('audio-status').textContent = "Error analysing chunk";
                    }
                };

            } catch (e) {
                console.error("Audio Analysis Start Failed", e);
            }
        }

        // 7. Generate Report
        async function generateReport() {
            if (USER_TYPE !== 'company') return;

            // Show Processing UI
            document.getElementById('processing-overlay').style.display = 'flex';
            
            // Compile Final Data
            // We use the last known values as averages if simple
            // But let's build a session object compatible with report.php
            
            // Calculate Average Audio Scores
            let totalConf = 0, totalNerv = 0, count = 0;
            let fullTranscript = "";
            multimodalSessionData.forEach(d => {
                totalConf += parseFloat(d.audio.confidence_score || 0);
                totalNerv += parseFloat(d.audio.nervousness_score || 0);
                if (d.transcription) fullTranscript += d.transcription + " "; // Accumulate
                count++;
            });
            const avgConf = count ? (totalConf / count).toFixed(1) : 0;
            const avgNerv = count ? (totalNerv / count).toFixed(1) : 0;

            // Optimized: Only save the LATEST snapshot (User request to 'overwrite')
            // Since Blink BPM and Emotion Totals are cumulative, the last one represents the whole session.
            const lastItem = multimodalSessionData[multimodalSessionData.length - 1];
            
             // NEW: Generate AI Overall Summary
            let aiSummary = "Summary not available.";
            let aiScore = 0;
            let aiState = "Neutral";
            let aiReason = "";

            console.log("Generating AI Summary...");

            // Calculate Blink Stats for AI
            const currentBpm = document.getElementById('blink-bpm').textContent;
            const currentTotalBlinks = document.getElementById('blink-total-count').textContent;
            
            try {
                 const formData = new FormData();
                 formData.append('action', 'generate_hr_summary'); 
                 formData.append('session_data', JSON.stringify(multimodalSessionData));
                 // NEW: Send explicit summary stats to AI to avoid chunking errors
                 formData.append('summary_stats', JSON.stringify({
                     avgBpm: currentBpm,
                     totalBlinks: currentTotalBlinks,
                     durationSecs: (Date.now() - sessionStartTime) / 1000
                 }));
                 formData.append('jobRole', 'Candidate'); 
                 
                 const summaryRes = await fetch('api/ai_service.php', {
                     method: 'POST',
                     body: formData
                 });
                 const summaryData = await summaryRes.json();
                 
                 if (summaryData.success) {
                     aiSummary = summaryData.summary;
                     aiScore = summaryData.hiring_score || 0;
                     aiState = summaryData.dominant_state || "Neutral";
                     aiReason = summaryData.state_reason || "";
                 }
            } catch (e) {
                console.error("Summary generation failed", e);
            }

            const finalData = {
                interview: {
                    overallScore: aiScore > 0 ? aiScore : (avgConf * 10), 
                    aiState: aiState,
                    aiReason: aiReason,
                    aiSummary: aiSummary,
                    answers: [{
                        question: "Session Transcript", // Specific Label
                        answer: fullTranscript.trim(), // FIX: No fallback text. Empty if no speech.
                        evaluation: {
                            confidence: parseFloat(avgConf),
                            nervousness: parseFloat(avgNerv)
                        }
                    }],
                    multimodal: lastItem ? [{
                        // questionIndex removed as requested
                        question: "Final Session Analysis",
                        audioAnalysis: lastItem.audio,
                        // Save CUMULATIVE stats from the live session
                        blinkData: { 
                            bpm: document.getElementById('blink-bpm').textContent, 
                            total: parseInt(document.getElementById('blink-total-count').textContent) || 0,
                            durationSecs: (Date.now() - sessionStartTime) / 1000,
                            status: "Recorded" 
                        },
                        emotionData: lastItem.emotionSnapshot
                    }] : [],
                    completedAt: Date.now()
                }
            };

            // Save to interview_candidates
            // Structure: interview_candidates/JobRef/AppRef
            await set(ref(db, `interview_candidates/${JOB_REF}/${APPLICATION_REF}`), finalData);
            
            // Redirect
            window.location.href = `interview_report.php?job_id=${JOB_REF}&application_id=${APPLICATION_REF}`;
        }

        document.getElementById('room-name').textContent = CHANNEL;

        if (!APP_ID || !TOKEN) {
            alert("Missing configuration. Redirecting...");
            window.location.href = 'login/login.php';
        }

        const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
        let localTracks = { videoTrack: null, audioTrack: null };
        let isMicOn = true;
        let isCamOn = true;

        async function init() {
            try {
                // Join
                await client.join(APP_ID, CHANNEL, TOKEN, UID);

                // Create Tracks
                localTracks.audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
                localTracks.videoTrack = await AgoraRTC.createCameraVideoTrack();

                // Play Local (In Floating Container)
                const localPlayerDiv = document.createElement("div");
                localPlayerDiv.id = `local-player`;
                localPlayerDiv.style.width = "100%";
                localPlayerDiv.style.height = "100%";
                document.getElementById("local-container").append(localPlayerDiv);
                
                localTracks.videoTrack.play(localPlayerDiv);

                // Publish
                await client.publish(Object.values(localTracks));

            } catch (err) {
                console.error(err);
                if (err.name === "NotReadableError" || err.name === "NotAllowedError") {
                   alert("Camera Error: " + err.message);
                } else {
                   alert("Error joining: " + err.message);
                }
            }
        }

        function createPlayer(uid, name) {
            const div = document.createElement("div");
            div.id = `player-wrapper-${uid}`; // Wrapper for styling
            // Note: Reuse simple structure for local, but for remote we want name tag
             if (name === "Me (Local)") {
                 div.id = `player-${uid}`;
                 div.className = "player";
                 div.innerHTML = `<div class="player-name">${name}</div>`;
                 return div;
             }
             return div; // Return wrapper for remote
        }

        // --- Handle Remote Users ---
        client.on("user-published", async (user, mediaType) => {
            await client.subscribe(user, mediaType);

            // 1. Remove Waiting Message
            const waitingMsg = document.getElementById("waiting-message");
            if (waitingMsg) waitingMsg.remove();

            // 2. Ensure Player Wrapper Exists
            const remoteContainer = document.getElementById("remote-container");
            let playerMsg = document.getElementById(`player-wrapper-${user.uid}`);
            
            if (!playerMsg) {
                playerMsg = document.createElement("div");
                playerMsg.id = `player-wrapper-${user.uid}`;
                playerMsg.style.width = "100%";
                playerMsg.style.height = "100%";
                playerMsg.style.position = "relative";
                
                // Name Tag
                const nameTag = document.createElement("div");
                nameTag.className = "player-name";
                nameTag.innerText = `User ${user.uid}`;
                playerMsg.appendChild(nameTag);

                // Video Div
                const videoDiv = document.createElement("div");
                videoDiv.id = `player-${user.uid}`;
                playerMsg.appendChild(videoDiv);

                remoteContainer.append(playerMsg);
            }

            // 3. Play Track
            if (mediaType === "video") {
                const videoDiv = document.getElementById(`player-${user.uid}`);
                user.videoTrack.play(videoDiv);

                // NEW: Start Analysis if Company
                if (USER_TYPE === 'company' && !analysisActive) {
                    console.log("Remote video arrived. Attempting to attach analysis...");
                    setTimeout(() => {
                        const videoEl = videoDiv.querySelector('video');
                        if (videoEl) {
                            videoEl.crossOrigin = "anonymous"; 
                            startRemoteAnalysis(videoEl);
                        }
                    }, 1500);
                }
            }
            if (mediaType === "audio") {
                user.audioTrack.play();
                // NEW: Start Audio Analysis if Company
                if (USER_TYPE === 'company' && !audioRecorder) {
                   // We need the MediaStreamTrack to create a Stream for Recorder
                   // user.audioTrack.getMediaStreamTrack() returns the track
                   const stream = new MediaStream([user.audioTrack.getMediaStreamTrack()]);
                   startAudioAnalysis(stream);
                }
            }
        });

        client.on("user-unpublished", (user, mediaType) => {
            if (mediaType === "video") {
                const p = document.getElementById(`player-wrapper-${user.uid}`);
                if (p) p.remove();
                
                // Check if empty
                if(document.getElementById("remote-container").childElementCount === 0) {
                     document.getElementById("remote-container").innerHTML = '<div style="color: #555; font-size: 20px;">Waiting for others to join...</div>';
                }
            }
        });

        client.on("user-left", (user) => {
            const p = document.getElementById(`player-wrapper-${user.uid}`);
            if (p) p.remove();
            
            if(document.getElementById("remote-container").childElementCount === 0) {
                 document.getElementById("remote-container").innerHTML = '<div style="color: #555; font-size: 20px;">Waiting for others to join...</div>';
            }
        });

        // Toggle Functions
        window.toggleMic = function() { // Expose to global for button onclick
            if (!localTracks.audioTrack) return;
            isMicOn = !isMicOn;
            localTracks.audioTrack.setMuted(!isMicOn);

            const btn = document.getElementById("mic-btn");
            const icon = btn.querySelector("i");

        btn.classList.toggle("btn-active", isMicOn);

        icon.className = isMicOn
            ? "fa-solid fa-microphone"
            : "fa-solid fa-microphone-slash";
        };

        window.toggleCam = function() {
            if (!localTracks.videoTrack) return;
            isCamOn = !isCamOn;
            localTracks.videoTrack.setMuted(!isCamOn);

             const btn = document.getElementById("cam-btn");
        const icon = btn.querySelector("i");

        btn.classList.toggle("btn-active", isCamOn);

        icon.className = isCamOn
            ? "fa-solid fa-video"
            : "fa-solid fa-video-slash";
        };

        window.leaveRoom = async function() {
            if(confirm("Exit call?")) {
                if (USER_TYPE === 'company') {
                    await generateReport(); // Save and Redirect
                } 
                
                // Cleanup
                localTracks.videoTrack && localTracks.videoTrack.close();
                localTracks.audioTrack && localTracks.audioTrack.close();
                client.leave();

                if (USER_TYPE !== 'company') {
                     window.close(); 
                     window.location.href = 'video_call.php'; 
                }
            }
        };

        init();
    </script>
</body>
</html>
