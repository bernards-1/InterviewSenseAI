<?php
// function.php
include("agora_lib/RtcTokenBuilder.php");

if (isset($_POST['Join'])) {
    
    // 1. Get Inputs
    $channelName = $_POST['channel'];
    // Generate a random UID if you don't have a user system
    $uid = mt_rand(10000, 99999); 

    // 2. Agora Configuration
    $appID = "3d7dfea869394667a3b19f67b1556290";
    $appCertificate = "d9f7bad9c65f4ec7b91cf3648409abf1";

    $role = RtcTokenBuilder::RolePublisher;
    $expireTimeInSeconds = 3600;
    $currentTimestamp = (new DateTime("now", new DateTimeZone('UTC')))->getTimestamp();
    $privilegeExpiredTs = $currentTimestamp + $expireTimeInSeconds;

    // 3. Generate Token
    try {
        $token = RtcTokenBuilder::buildTokenWithUid($appID, $appCertificate, $channelName, $uid, $role, $privilegeExpiredTs);
        
        // 4. Redirect to Room Page with Data
        // We pass the data via URL parameters so room.php can read it
        $redirectUrl = "room.php?channel=" . urlencode($channelName) . 
                       "&token=" . urlencode($token) . 
                       "&uid=" . $uid . 
                       "&appId=" . $appID;
                       
        header("Location: " . $redirectUrl);
        exit();

    } catch(Exception $e) {
        die("Error generating token: " . $e->getMessage());
    }
} else {
    // If someone tries to open this file directly without clicking Join
    header("Location: login/login.php");
    exit();
}
?>
