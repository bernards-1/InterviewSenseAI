<?php
$title = "Job Edit";

include("../includes/company_layout.php");

// Example URL function
function url($file, $params = []) {
    return $file . '?' . http_build_query($params);
}
?>

<link rel="stylesheet" href="/css/job_edit.css" />
<link rel="stylesheet" href="/css/edit_job.css" />

<style>
.text-danger {
    color: red;
    font-size: 0.9rem;
    margin-top: 4px;
    display: block;
}
</style>

<div class="edit-job-container">

    <div class="edit-job-header">
        <div class="header-left">
            <div class="header-text">
                <h1 class="header-title">Edit Job Posting</h1>
                <p class="header-subtitle">Update job details</p>
            </div>
        </div>
    </div>

    <div class="edit-job-card">
        <form method="post" id="editJobForm" action="job_edit.php" class="form">

            <div class="form-section-header">
                <h2 class="section-title">Job Details</h2>
            </div>

            <!-- Job Title -->
            <div class="form-group">
                <label class="form-label">
                    Job Title <span class="required">*</span>
                </label>
                <input type="text" name="JobTitle" class="form-input"
                       value="<?= htmlspecialchars($job['JobTitle']) ?>"
                       placeholder="e.g., Senior Software Engineer" />
                <span class="text-danger"></span>
            </div>

            <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($job['job_ref_no']) ?>" />

            <div class="form-row">
                <!-- Department -->
                <div class="form-group">
                    <label class="form-label">
                        Department <span class="required">*</span>
                    </label>
                    <input type="text" name="Department" class="form-input"
                           value="<?= htmlspecialchars($job['Department']) ?>"
                           placeholder="e.g., Engineering" />
                    <span class="text-danger"></span>
                </div>

                <!-- Job Type -->
                <div class="form-group">
                    <label class="form-label">
                        Job Type <span class="required">*</span>
                    </label>
                    <select name="JobType" class="form-select">
                        <option value="">Select type</option>
                        <option value="Full-time" <?= $job['JobType']=="Full-time"?"selected":"" ?>>Full-time</option>
                        <option value="Part-time" <?= $job['JobType']=="Part-time"?"selected":"" ?>>Part-time</option>
                        <option value="Contract" <?= $job['JobType']=="Contract"?"selected":"" ?>>Contract</option>
                        <option value="Internship" <?= $job['JobType']=="Internship"?"selected":"" ?>>Internship</option>
                    </select>
                    <span class="text-danger"></span>
                </div>
            </div>

            <div class="form-row">
                <!-- Min Salary -->
                <div class="form-group">
                    <label class="form-label">Minimum Salary</label>
                    <input type="text" name="MinSalary" class="form-input"
                           value="<?= htmlspecialchars($job['MinSalary']) ?>"
                           placeholder="e.g., 3000" />
                    <span class="text-danger"></span>
                </div>

                <!-- Max Salary -->
                <div class="form-group">
                    <label class="form-label">Maximum Salary</label>
                    <input type="text" name="MaxSalary" class="form-input"
                           value="<?= htmlspecialchars($job['MaxSalary']) ?>"
                           placeholder="e.g., 5000" />
                    <span class="text-danger"></span>
                </div>
            </div>

            <div class="form-row">
                <!-- State -->
                <div class="form-group">
                    <label class="form-label">State</label>
                    <input type="text" name="state" class="form-input"
                           value="<?= htmlspecialchars($job['state']) ?>" readonly />
                    <span class="text-danger"></span>
                </div>

                <!-- City -->
                <div class="form-group">
                    <label class="form-label">City</label>
                    <input type="text" name="city" class="form-input"
                           value="<?= htmlspecialchars($job['city']) ?>" readonly />
                    <span class="text-danger"></span>
                </div>
            </div>

            <!-- Location -->
            <div class="form-group">
                <label class="form-label">
                    Location <span class="required">*</span>
                </label>
                <textarea name="Location" class="form-textarea" readonly><?= htmlspecialchars($job['Location']) ?></textarea>
                <span class="text-danger"></span>
            </div>

            <!-- Description -->
            <div class="form-group">
                <label class="form-label">
                    Job Description <span class="required">*</span>
                </label>
                <textarea name="Description" class="form-textarea" rows="4"><?= htmlspecialchars($job['Description']) ?></textarea>
                <span class="text-danger"></span>
            </div>

            <!-- Responsibilities -->
            <div class="form-group">
                <label class="form-label">
                    Key Responsibilities <span class="required">*</span>
                </label>
                <textarea name="Responsibility" class="form-textarea large" rows="6"><?= htmlspecialchars($job['Responsibility']) ?></textarea>
                <span class="text-danger"></span>
                <small class="form-hint">Enter one responsibility per line</small>
            </div>

            <!-- Requirements -->
            <div class="form-group">
                <label class="form-label">
                    Requirements <span class="required">*</span>
                </label>
                <textarea name="Requirement" class="form-textarea large" rows="6"><?= htmlspecialchars($job['Requirement']) ?></textarea>
                <span class="text-danger"></span>
                <small class="form-hint">Enter one requirement per line</small>
            </div>

            <div class="form-actions">
                <div class="actions-right">
                    <button type="button" class="btn-cancel" onclick="location.href='/dashboard.php'">
                        Cancel
                    </button>

                    <button type="submit" class="btn-save">
                        Save Changes
                    </button>
                </div>
            </div>
        </form>

        <script>
            document.getElementById('editJobForm').addEventListener('submit', function(e) {
                if (!confirm("Are you sure you want to continue?")) {
                    e.preventDefault();
                }
            });
        </script>

    </div>
</div>
