<?php
include("../includes/company_layout.php");


/*
  Example data (replace with real DB data)
  Normally you will fetch this from MySQL.
*/
$model = [
    'Company' => [
        'name' => $company['name'] ?? '',
        'email' => $company['email'] ?? '',
        'state' => $company['state'] ?? '',
        'city' => $company['city'] ?? '',
        'address' => $company['address'] ?? ''
    ],
    'CompanyInfo' => [
        'total_employees' => $companyInfo['total_employees'] ?? '',
        'aboutUs' => $companyInfo['aboutUs'] ?? ''
    ]
];

// Malaysia states
$states = ["Johor", "Kedah", "Kelantan", "Kuala Lumpur", "Labuan", "Melaka",
    "Negeri Sembilan", "Pahang", "Penang", "Perak", "Perlis",
    "Putrajaya", "Sabah", "Sarawak", "Selangor", "Terengganu"];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Company Profile</title>
    <link href="../css/EditComapnyProfile.css" rel="stylesheet" />
</head>
<body>

<div class="update-profile-container">

    <!-- Header -->
    <div class="update-profile-header">
        <a href="profile.php" class="btn-back">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
        </a>
        <h1 class="update-profile-title">Update Company Profile</h1>
    </div>

    <div class="update-profile-card">
        <form action="edit_profile.php" method="post">

            <h2 class="form-section-title">Company Information</h2>

            <div class="form-row">
                <!-- Company Name -->
                <div class="form-group">
                    <label class="form-label">Company Name</label>
                    <input type="text"
                           name="companyName"
                           class="form-input"
                           value="<?= htmlspecialchars($model['Company']['name']) ?>"
                           required>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label class="form-label">Contact Email</label>
                    <input type="email"
                           name="Email"
                           class="form-input"
                           value="<?= htmlspecialchars($model['Company']['email']) ?>"
                           required>
                </div>
            </div>

            <div class="form-row">
                <!-- State -->
                <div class="form-group">
                    <label class="form-label">State</label>
                    <select id="state" name="state" class="form-select">
                        <option value="">Select State</option>
                        <?php foreach ($states as $state): ?>
                            <option value="<?= $state ?>"
                                <?= ($model['Company']['state'] === $state) ? 'selected' : '' ?>>
                                <?= $state ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- City -->
                <div class="form-group">
                    <label class="form-label">City</label>
                    <select id="city" name="city" class="form-select">
                        <option value="<?= htmlspecialchars($model['Company']['city']) ?>" selected>
                            <?= htmlspecialchars($model['Company']['city']) ?>
                        </option>
                    </select>
                </div>
            </div>

            <script>
                const citiesByState = {
                    "Johor": ["Johor Bahru", "Batu Pahat", "Muar", "Segamat", "Kluang", "Kota Tinggi", "Pontian", "Mersing", "Kulai", "Tangkak"],
                    "Kedah": ["Alor Setar", "Sungai Petani", "Kulim", "Langkawi", "Jitra", "Baling", "Yan", "Sik", "Kuala Nerang", "Pendang"],
                    "Kelantan": ["Kota Bharu", "Pasir Mas", "Tumpat", "Bachok", "Pasir Puteh", "Tanah Merah", "Kuala Krai", "Machang", "Gua Musang", "Jeli"],
                    "Kuala Lumpur": ["Kuala Lumpur"],
                    "Labuan": ["Labuan"],
                    "Melaka": ["Melaka City", "Alor Gajah", "Jasin"],
                    "Negeri Sembilan": ["Seremban", "Port Dickson", "Nilai", "Bahau", "Kuala Pilah", "Rembau", "Jempol", "Tampin"],
                    "Pahang": ["Kuantan", "Temerloh", "Bentong", "Mentakab", "Raub", "Jerantut", "Pekan", "Rompin", "Maran", "Bera", "Cameron Highlands"],
                    "Penang": ["Batu Kawan", "Bukit Minyak","Perai","George Town", "Butterworth", "Bukit Mertajam", "Bayan Lepas", "Nibong Tebal", "Kepala Batas", "Tasek Gelugor"],
                    "Perak": ["Ipoh", "Taiping", "Teluk Intan", "Sitiawan", "Kampar", "Batu Gajah", "Kuala Kangsar", "Tapah", "Gerik", "Lumut", "Parit Buntar"],
                    "Perlis": ["Kangar", "Arau"],
                    "Putrajaya": ["Putrajaya"],
                    "Sabah": ["Kota Kinabalu", "Sandakan", "Tawau", "Lahad Datu", "Keningau", "Semporna", "Kudat", "Ranau", "Beaufort", "Kota Belud"],
                    "Sarawak": ["Kuching", "Miri", "Sibu", "Bintulu", "Limbang", "Sarikei", "Sri Aman", "Kapit", "Mukah", "Betong"],
                    "Selangor": ["Shah Alam", "Petaling Jaya", "Klang", "Subang Jaya", "Ampang", "Selayang", "Kajang", "Semenyih", "Rawang", "Sepang", "Kuala Selangor"],
                    "Terengganu": ["Kuala Terengganu", "Kemaman", "Dungun", "Marang", "Hulu Terengganu", "Besut", "Setiu"]
                };

                document.getElementById("state").addEventListener("change", function() {
                    const state = this.value;
                    const citySelect = document.getElementById("city");
                    citySelect.innerHTML = '<option value="">Select City</option>';

                    if(state && citiesByState[state]){
                        citiesByState[state].forEach(city => {
                            const option = document.createElement("option");
                            option.value = city;
                            option.text = city;
                            citySelect.add(option);
                        });
                    }
                });
            </script>

            <div class="form-row">
                <!-- Company Employee -->
                <div class="form-group">
                    <label class="form-label">Company Employee</label>
                    <input type="text"
                           name="CompanyEmployee"
                           class="form-input"
                           value="<?= htmlspecialchars($model['CompanyInfo']['total_employees']) ?>"
                           required>
                </div>
            </div>

            <!-- Location -->
            <div class="form-group form-group-full">
                <label class="form-label">Location</label>
                <input type="text"
                       name="location"
                       class="form-input"
                       value="<?= htmlspecialchars($model['Company']['address']) ?>"
                       required>
            </div>

            <!-- Description -->
            <div class="form-group form-group-full">
                <label class="form-label">Company Description</label>
                <textarea name="CompanyDescription"
                          class="form-textarea"
                          rows="4"
                          required><?= htmlspecialchars($model['CompanyInfo']['aboutUs']) ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-save" onclick="return confirm('Are you sure you want to save changes?');">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M12.6667 2H3.33333C2.59695 2 2 2.59695 2 3.33333V12.6667C2 13.403 2.59695 14 3.33333 14H12.6667C13.403 14 14 13.403 14 12.6667V3.33333C14 2.59695 13.403 2 12.6667 2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M11.3333 2V5.33333H4.66667V2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M4.66667 14V9.33333H11.3333V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    Save Changes
                </button>

                <a href="profile.php" class="btn-cancel">Cancel</a>
            </div>

        </form>
    </div>
</div>

</body>
</html>
