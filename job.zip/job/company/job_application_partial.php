<?php


require_once '../includes/firebase_helper.php';

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

$company_ref_no = $_SESSION["company_ref_no"] ?? null;

// 1. Fetch all necessary data
$allJobs = $fb->get("tbl_jobs") ?? [];
$allApplications = $fb->get("tbl_job_applications") ?? [];
$allSeekers = $fb->get("tbl_jobseeker") ?? [];

// 2. Identify Jobs belonging to this company
$myJobRefs = [];
foreach ($allJobs as $j) {
    if (($j['company_ref_no'] ?? '') === $company_ref_no) {
        $myJobRefs[] = $j['job_ref_no'];
    }
}

// 3. Filter & Join Applications
$applications = [];

if ($company_ref_no && !empty($myJobRefs)) {
    foreach ($allApplications as $appKey => $app) {
        
        $appJobRef = $app['job_ref_no'] ?? '';
        
        // Only show if the job belongs to this company
        if (in_array($appJobRef, $myJobRefs)) {
            
            // Enrich with Job Title
            $jobTitle = "Unknown Job";
            foreach ($allJobs as $j) {
                if (($j['job_ref_no'] ?? '') === $appJobRef) {
                    $jobTitle = $j['job_title'] ?? 'Unknown Job';
                    break;
                }
            }

            // Enrich with Job Seeker Info
            $seekerName = "Unknown";
            $seekerEmail = "";
            $seekerPhone = "";
            $seekerRef = $app['jobseeker_ref_no'] ?? ''; // DB uses jobseeker_ref_no (USR...)
            $realSeekerRef = $seekerRef; // Fallback

            foreach ($allSeekers as $s) {
                // Check both ref_no (USR) and seeker_ref_no (SKR) just in case
                if (($s['ref_no'] ?? '') === $seekerRef || ($s['seeker_ref_no'] ?? '') === $seekerRef) {
                    $seekerName = $s['name'] ?? 'Unknown';
                    $seekerEmail = $s['email'] ?? '';
                    $seekerPhone = $s['phone'] ?? '';
                    $realSeekerRef = $s['seeker_ref_no'] ?? $seekerRef;
                    break;
                }
            }

            // Status Normalization
            // DB has "Pending", UI expects 0,1,2 OR we just handle string
            $rawStatus = $app['status'] ?? 'Pending';
            $statusInt = 0; // Default New
            if ($rawStatus === 'Pending') $statusInt = 0; // New
            elseif ($rawStatus === 'Reviewed') $statusInt = 1;
            elseif ($rawStatus === 'Shortlisted') $statusInt = 2;
            elseif ($rawStatus === 'Rejected') $statusInt = 3;
            elseif ($rawStatus === 'Technical Test') $statusInt = 4;
            elseif ($rawStatus === 'Interview') $statusInt = 5;
            elseif ($rawStatus === 'Success') $statusInt = 6;
            elseif (is_numeric($rawStatus)) $statusInt = (int)$rawStatus;

            // Construct array
            $applications[] = [
                "application_ref_no" => $app['application_ref_no'] ?? $appKey, // Use key if ref missing
                "job_ref_no" => $appJobRef,
                "JobTitle" => $jobTitle,
                "status" => $statusInt, 
                "apply_date" => isset($app['createdAt']) ? strtotime($app['createdAt']) : time(),
                "experience" => $app['experience'] ?? 'N/A', 
                "qualifications" => $app['qualifications'] ?? 'N/A',
                "resume_path" => $app['resume_path'] ?? '',
                "JobSeeker" => [
                    "name" => $seekerName,
                    "email" => $seekerEmail,
                    "phone" => $seekerPhone,
                    "seeker_ref_no" => $realSeekerRef
                ]
            ];
        }
    }
}

// Sort by date desc
usort($applications, function($a, $b) {
    return $b['apply_date'] - $a['apply_date'];
});


/* =============================
   Pagination
   ============================= */
$perPage = 5; // Increased to 5
$totalApps = count($applications);
$totalPages = ceil($totalApps / $perPage);
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage < 1) $currentPage = 1;
if ($currentPage > $totalPages && $totalPages > 0) $currentPage = $totalPages;

$start = ($currentPage - 1) * $perPage;
$appsPage = array_slice($applications, $start, $perPage);

/* =============================
   Helper functions
   ============================= */
function appliedTimeAgo($timestamp) {
    if (!$timestamp) return 'N/A';
    $diff = time() - $timestamp;
    if ($diff < 60) return "just now";
    if ($diff < 3600) return floor($diff/60) . " minutes ago";
    if ($diff < 86400) return floor($diff/3600) . " hours ago";
    if ($diff < 172800) return "yesterday";
    if ($diff < 604800) return floor($diff/86400) . " days ago";
    return floor($diff/604800) . " weeks ago";
}

function getStatusBadge($status) {
    // 0:New/Pending, 1:Reviewed, 2:Shortlisted, 3:Rejected
    switch ($status) {
        case 0: return ["New (Pending)","blue"];
        case 1: return ["Reviewed","#c58000"];
        case 2: return ["Shortlisted","green"];
        case 3: return ["Rejected","red"];
        case 4: return ["Technical Test", "#6f42c1"]; // Purple
        case 5: return ["Interview","#17a2b8"]; // Teal
        case 6: return ["Success","#00ff48ff"]; // Teal
        default: return ["Unknown","gray"];
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Job Applications</title>
    <style>
        .applications-list { width: 100%; margin:auto; }
        .application-card { border:1px solid #ddd; padding:15px; margin-bottom:15px; background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .card-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 10px;}
        
        .applicant-info h3 { font-size: 1.2rem; margin: 0 0 5px 0; color: #333; }
        .applicant-position { color: #666; font-size: 0.95rem; margin: 0; }
        
        .application-meta { text-align: right; }
        .status-badge { color:white; padding:4px 10px; border-radius:15px; font-size: 0.85rem; display: inline-block; margin-bottom: 5px;}
        .applied-date { display: block; color: #999; font-size: 0.85rem; }

        .card-body { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 15px; }
        .contact-info, .experience-tags { flex: 1; min-width: 200px; }
        
        .contact-item { margin-top:5px; color: #555; }
        .experience-tags .tag { display: inline-block; margin: 5px 5px 0 0; padding:4px 8px; background:#f0f2f5; border-radius:4px; font-size: 0.9rem; color: #444; border: 1px solid #e1e4e8;}

        .card-actions { border-top: 1px solid #eee; padding-top: 10px; text-align: right; }
        .btn-action { margin-left:5px; padding:6px 12px; cursor:pointer; border:none; border-radius:4px; font-size: 0.9rem; transition: all 0.2s; }
        .btn-action:hover { opacity: 0.9; }
        
        .btn-success { background:#28a745; color:white; }
        .btn-danger { background:#dc3545; color:white; }
        .btn-secondary { background:#eee; color:black; }
            .btn-secondary:hover { background: #6c757d; color:white; } 

        /* Modal */
        .modal { display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; overflow:auto; background:rgba(0,0,0,0.5);}
        .modal-content { position:relative; margin:50px auto; width:80%; max-width: 900px; height:80%; background:white; padding:0; border-radius: 8px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .close { position:absolute; right:15px; top:10px; font-size:28px; cursor:pointer; color: #aaa; z-index: 10;}
        .close:hover { color: #333; }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 24px;
            flex-wrap: wrap;
        }

        .pagination a {
            display: block;
            padding: 5px 9px;
            border-radius: 8px;
            border: 1px solid #d2d2d7;
            background-color: white;
            color: #1d1d1f;
            text-decoration: none;
            margin: 4px;
            font-weight: 500;
            transition: all 0.2s;
        }

        .pagination a:hover {
            background-color: #c0c0c1;
            border-color: #86868b;
        }

        .pagination a.active {
            background-color: #1976d2;
            color: white;
            border-color: #1976d2;
        }
    </style>
</head>
<body>

<div class="applications-list">
    
    <?php if(empty($appsPage)): ?>
        <div style="text-align:center; padding: 40px; color: #777;">
            <p>No applications found matching your criteria.</p>
        </div>
    <?php else: ?>

    <?php foreach ($appsPage as $app): 
        list($statusText, $statusColor) = getStatusBadge($app["status"]);
    ?>
    <div class="application-card">
        <div class="card-header">
            <div class="applicant-info">
                <h3 class="applicant-name"><?= htmlspecialchars($app["JobSeeker"]["name"]) ?></h3>
                <p class="applicant-position"><?= htmlspecialchars($app["JobTitle"]) ?></p>
            </div>
            <div class="application-meta">
                <span class="status-badge" style="background-color:<?= $statusColor ?>"><?= $statusText ?></span>
                <span class="applied-date"><?= appliedTimeAgo($app["apply_date"]) ?></span>
            </div>
        </div>

        <div class="card-body">
            <div class="contact-info">
                <div class="contact-item">✉️ <?= htmlspecialchars($app["JobSeeker"]["email"]) ?></div>
                <div class="contact-item">📞 (+60) <?= htmlspecialchars($app["JobSeeker"]["phone"]) ?></div>
            </div>
            <div class="experience-tags">
                <span class="tag"><?= htmlspecialchars($app["experience"]) ?></span>
                <span class="tag"><?= htmlspecialchars($app["qualifications"]) ?></span>
            </div>
        </div>

        <div class="card-actions">
            <?php if($app["status"] != 3): // Hide if Rejected (3) ?>
                <?php if (!empty($app["resume_path"])): ?>
                    <a href="../<?= htmlspecialchars($app["resume_path"]) ?>" 
                       target="_blank" 
                       class="btn-action btn-secondary" 
                       style="text-decoration:none; display:inline-block;"
                       onclick="markAsReviewed('<?= $app["application_ref_no"] ?>', <?= $app['status'] ?>)">
                       📄 View Resume
                    </a>
                <?php else: ?>
                    <span class="btn-action btn-secondary" style="opacity:0.6; cursor:not-allowed;">No Resume</span>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($app["status"] == 1): // Show only for Reviewed(1) ?>
                <button class="btn-action btn-success" onclick="openShortlistModal('<?= $app["job_ref_no"] ?>','<?= $app["JobSeeker"]["seeker_ref_no"] ?>', '<?= $app["application_ref_no"] ?>')">Shortlist</button>
                <button class="btn-action btn-danger" onclick="rejectApplication('<?= $app["application_ref_no"] ?>')">Reject</button>
            <?php endif; ?>

            <?php if($app["status"] == 5): // Show only for Interview(5) ?>
                <button class="btn-action btn-success" onclick="acceptApplication('<?= $app["application_ref_no"] ?>')">Accept</button>
                <button class="btn-action btn-danger" onclick="rejectApplication('<?= $app["application_ref_no"] ?>')">Reject</button>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>
    <?php endif; ?>


</div>

<!-- Shortlist Action Modal -->
<div id="shortlistModal" class="modal">
    <div class="modal-content" style="background-color: #fff !important; opacity: 1 !important; margin: 10% auto; padding: 20px; border: 1px solid #888; width: 90%; max-width: 400px; border-radius: 8px; text-align: center; position: relative; z-index: 10001; height: auto !important; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);">
        <span class="close" onclick="closeShortlistModal()" style="position: absolute; right: 15px; top: 10px; font-size: 28px; font-weight: bold; cursor: pointer; color: #aaa;">&times;</span>
        <h2 style="margin-top:10px; color: #333;">Next Step</h2>
        <p style="color: #666;">Choose an action for this candidate:</p>

        <input type="hidden" id="modalJobRef" value="">
        <input type="hidden" id="modalSeekerRef" value="">
        <input type="hidden" id="modalAppRef" value="">

        <!-- Step 1: Action Buttons -->
        <div id="actionButtons" style="margin-top: 25px;">
            <a href="javascript:void(0)" onclick="showInterviewForm()" style="display: block; width: 100%; padding: 12px; margin-bottom: 10px; font-size: 16px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px; cursor: pointer;">📅 Invite to Interview</a>
          <!--   <a href="javascript:void(0)" onclick="goToQuestion()" style="display: block; width: 100%; padding: 12px; font-size: 16px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px; cursor: pointer;">❓ Ask Technical Question</a> --> 
        </div>

        <!-- Step 2: Interview Form -->
        <div id="interviewForm" style="display: none; margin-top: 20px; text-align: left;">
            <h3 style="font-size: 1.1rem; margin-bottom: 10px; color: #333;">Schedule Interview</h3>
            
            <label style="display:block; margin-bottom:5px; color:#555;">HR Role / Title:</label>
            <select id="hrRole" style="width: 100%; padding: 8px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">
                <option value="HR Manager">HR Manager</option>
                <option value="HR Executive">HR Executive</option>
                <option value="Recruiter">Recruiter</option>
                <option value="Technical Lead">Technical Lead</option>
                <option value="Other">Other</option>
            </select>
            
            <label style="display:block; margin-bottom:5px; color:#555;">Interviewer Name:</label>
            <input type="text" id="hrName" placeholder="e.g. Seik" style="width: 100%; padding: 8px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">

            <label style="display:block; margin-bottom:5px; color:#555;">Date:</label>
            <input type="date" id="interviewDate" style="width: 100%; padding: 8px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">

            <label style="display:block; margin-bottom:5px; color:#555;">Time:</label>
            <input type="time" id="interviewTime" style="width: 100%; padding: 8px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">

            <div style="display: flex; gap: 10px; margin-top: 10px;">
                <button onclick="submitInterview()" style="flex: 1; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">Send Invitation</button>
                <button onclick="hideInterviewForm()" style="flex: 1; padding: 10px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;">Back</button>
            </div>
        </div>
    </div>
</div>

<!-- Pagination -->
<div class="pagination" style="text-align:center; margin-top:20px;">
<?php if($currentPage > 1): ?>
    <a href="?page=1">First</a>
    <a href="?page=<?= $currentPage-1 ?>">Previous</a>
<?php endif; ?>

<?php for($p=1; $p <= $totalPages; $p++): ?>
    <a href="?page=<?= $p ?>" style="<?= $p==$currentPage ? 'font-weight:bold;' : '' ?>"><?= $p ?></a>
<?php endfor; ?>

<?php if($currentPage < $totalPages): ?>
    <a href="?page=<?= $currentPage+1 ?>">Next</a>
    <a href="?page=<?= $totalPages ?>">Last</a>
<?php endif; ?>
</div>

<script>
function openShortlistModal(jobRef, seekerRef, appRef) {
    document.getElementById("modalJobRef").value = jobRef;
    document.getElementById("modalSeekerRef").value = seekerRef;
    document.getElementById("modalAppRef").value = appRef;
    // Debugging alert to confirm appRef is passed
    // alert("App Ref: " + appRef); 
    document.getElementById("shortlistModal").style.display = "block";
    if(typeof hideInterviewForm === "function") hideInterviewForm();
}

function closeShortlistModal() {
    document.getElementById("shortlistModal").style.display = "none";
}

function showInterviewForm() {
    document.getElementById("actionButtons").style.display = "none";
    document.getElementById("interviewForm").style.display = "block";
}

function hideInterviewForm() {
    document.getElementById("interviewForm").style.display = "none";
    document.getElementById("actionButtons").style.display = "block";
}

function submitInterview() {
    let job = document.getElementById("modalJobRef").value;
    let seeker = document.getElementById("modalSeekerRef").value;
    let appRef = document.getElementById("modalAppRef").value;
    let date = document.getElementById("interviewDate").value;
    let time = document.getElementById("interviewTime").value;
    let hrRoleElem = document.getElementById("hrRole");
    let hrRole = hrRoleElem ? hrRoleElem.value : "";
    let hrName = document.getElementById("hrName").value;
    // Message field removed

    if(!date || !time) {
        alert("Please select both date and time.");
        return;
    }
    
    if(!hrName.trim()) {
        alert("Please enter the HR Name.");
        return;
    }

    if(!confirm("Confirm sending invitation?")) return;

    fetch('../function/company.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            interviewSchedule: true,
            application_ref_no: appRef,
            job_ref_no: job, 
            jobseeker_ref_no: seeker,
            date: date,
            time: time,
            hr_role: hrRole,
            hr_name: hrName,
            message: "Interview Scheduled" // Default message
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert("Invitation sent successfully!");
            location.reload();
        } else {
            alert("Failed: " + data.message);
        }
    })
    .catch(error => console.error("Error:", error));
}

function goToQuestion() {
    let job = document.getElementById("modalJobRef").value;
    let seeker = document.getElementById("modalSeekerRef").value;
    window.location.href = `/Company/technical_question.php?job_ref_no=${job}&jobseeker_ref_no=${seeker}`;
}

// Click outside to close
window.onclick = function(event) {
    let modal = document.getElementById("shortlistModal");
    if (event.target == modal) closeShortlistModal();
}

function postAction(jobRefNo, seekerRefNo, action) {
    if(confirm(`Are you sure you want to ${action} this applicant?`)) {
        window.location.href = `/Company/apply_${action}.php?job_ref_no=${jobRefNo}&jobseeker_ref_no=${seekerRefNo}`;
    }
}

function rejectApplication(appRefNo) {
    if(!confirm("Are you sure you want to reject this applicant?")) return;

    fetch('../function/company.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ application_ref_no: appRefNo, status: 3 })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert("Application rejected.");
            location.reload();
        } else {
            alert("Failed: " + data.message);
        }
    })
    .catch(error => console.error("Error:", error));
}

function acceptApplication(appRefNo) {
    if(!confirm("Are you sure you want to accept (hire) this applicant?")) return;

    fetch('../function/company.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ application_ref_no: appRefNo, status: 6 })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert("Application accepted!");
            location.reload();
        } else {
            alert("Failed: " + data.message);
        }
    })
    .catch(error => console.error("Error:", error));
}

function markAsReviewed(appRefNo, currentStatus) {
    // Only update if status is 'New' (0)
    // If it's reviewed(1), shortlisted(2), or rejected(3), do nothing.
    if (currentStatus != 0) return;
    
    fetch('../function/company.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ application_ref_no: appRefNo, status: 1 })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            console.log("Status updated to Reviewed");
            setTimeout(() => location.reload(), 500);
        } else {
            console.error("Failed to update status", data.message);
        }
    })
    .catch(error => console.error("Error:", error));
}
</script>

</body>
</html>
