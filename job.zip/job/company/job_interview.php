<?php
require_once '../includes/firebase_helper.php';
include '../includes/company_layout.php';
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =============================
// CHECK LOGIN
// =============================
$company_ref_no = $_SESSION["company_ref_no"] ?? null;
if (!$company_ref_no) {
    header("Location: ../login/login.php");
    exit;
}

// =============================
// GET JOBS FROM FIREBASE
// =============================
$allJobs = $fb->get("tbl_jobs") ?? [];

// 只取当前公司的 jobs
$jobs = [];
foreach ($allJobs as $job) {
    if (($job['company_ref_no'] ?? '') === $company_ref_no) {
        $jobs[] = $job;
    }
}

// =============================
// GET APPLICATIONS (optional)
// =============================
$allApplications = $fb->get("tbl_job_applications") ?? []; // 假设你有这个节点
$applications = [];
foreach ($allApplications as $app) {
    if (($app['job_ref_no'] ?? '') && ($app['company_ref_no'] ?? '') === $company_ref_no) {
        $applications[] = $app;
    }
}

// =============================
// Pagination
// =============================
$perPage = 5;
$totalJobs = count($jobs);
$totalPages = ceil($totalJobs / $perPage);
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($currentPage - 1) * $perPage;
$jobsPage = array_slice($jobs, $start, $perPage);

// =============================
// Helper functions
// =============================
function getPostedAgo($createdAt) {
    $diff = time() - strtotime($createdAt);
    if ($diff < 60) return "just now";
    if ($diff < 3600) return floor($diff/60) . " minutes ago";
    if ($diff < 86400) return floor($diff/3600) . " hours ago";
    if ($diff < 172800) return "yesterday";
    if ($diff < 604800) return floor($diff/86400) . " days ago";
    return floor($diff/604800) . " weeks ago";
}

function getStatusBadge($status) {
    switch ($status) {
        case 1: return ["Active","#28a745"];
        case 2: return ["Closed","#dc3545"];
        case 3: return ["Reject","#950000"];
        default: return ["Pending","#FFA500"];
    }
}

function getApplyCount($job_ref_no, $applications) {
    $count = 0;
    foreach ($applications as $a) {
        if ($a['job_ref_no'] == $job_ref_no) $count++;
    }
    return $count;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Jobs</title>
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/job_interview.css">
</head>
<body>


<?php if(empty($jobs)): ?>
    <p>No jobs posted yet. <a href="posting_job.php">Post a job</a></p>
<?php else: ?>

<?php foreach ($jobsPage as $job): 
    list($statusText, $statusColor) = getStatusBadge($job["status"] ?? 0);
    $applyCount = getApplyCount($job["job_ref_no"], $applications);
?>

<div class="job-card">
    <div class="job-info">
        <div class="job-title"><?= htmlspecialchars($job["job_title"] ?? '') ?></div>
        <div class="job-meta">
            <?= htmlspecialchars($job["job_type"] ?? '') ?> • 
            <?= htmlspecialchars($job["city"] ?? '') ?> , <?= htmlspecialchars($job["state"] ?? '') ?>
        </div>
        <div class="job-stats"><?= $applyCount ?> applications • Created <?= getPostedAgo($job["createdAt"] ?? date("c")) ?></div>
        
    </div>

    <div class="job-actions">
        <span class="status-badge" style="background-color:<?= $statusColor ?>"><?= $statusText ?></span>

        <button class="btn-view-details" onclick="window.location.href='job_interview_report.php?job_ref_no=<?= $job["job_ref_no"] ?>'">View Comparisions</button>

        <button class="btn-view-details" onclick="window.location.href='interview_list.php?job_ref_no=<?= $job["job_ref_no"] ?>'">View Lists</button>
    </div>

    
</div>
<?php endforeach; ?>

<!-- Pagination -->
<div class="pagination">
<?php if($currentPage > 1): ?>
    <a href="?page=1">First</a>
    <a href="?page=<?= $currentPage-1 ?>">Previous</a>
<?php endif; ?>

<?php for($p=1; $p <= $totalPages; $p++): ?>
    <a href="?page=<?= $p ?>" class="<?= $p==$currentPage ? 'current' : '' ?>"><?= $p ?></a>
<?php endfor; ?>

<?php if($currentPage < $totalPages): ?>
    <a href="?page=<?= $currentPage+1 ?>">Next</a>
    <a href="?page=<?= $totalPages ?>">Last</a>
<?php endif; ?>
</div>

<?php endif; ?>
</body>
</html>

