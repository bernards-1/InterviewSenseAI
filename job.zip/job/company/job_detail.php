<?php
require_once '../includes/firebase_helper.php';
include("../includes/company_layout.php");

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =============================
// 获取 job_ref_no
// =============================
$job_ref_no = $_GET['job_ref_no'] ?? null;
if (!$job_ref_no) {
    echo "Job reference number missing.";
    exit;
}

// =============================
// 取 job 基本信息
// =============================
$job = $fb->get("tbl_jobs/$job_ref_no");
if (!$job) {
    echo "Job not found.";
    exit;
}

// =============================
// 取 job detail
// =============================
$jobDetail = $fb->get("tbl_job_details/$job_ref_no") ?? [
    "description" => "",
    "responsibility" => "",
    "requirement" => ""
];

// =============================
// Job status
// =============================
$jobstatus = $job['status'] ?? 0;

// =============================
// 统计申请人数
// =============================
$applicationsAll = $fb->get("tbl_job_applications") ?? [];
$applications = array_filter($applicationsAll, function($a) use($job_ref_no){
    return ($a['job_ref_no'] ?? '') === $job_ref_no;
});

$model = [
    "TotalApply" => count($applications),
    "NewCount" => count(array_filter($applications, fn($a) => ($a['status'] ?? '') === 'new')),
    "ReviewedCount" => count(array_filter($applications, fn($a) => ($a['status'] ?? '') === 'reviewed')),
    "ShortlistedCount" => count(array_filter($applications, fn($a) => ($a['status'] ?? '') === 'shortlisted')),
];

// =============================
// Helper function: posted time ago
// =============================
function getPostedAgo($createdAt) {
    $createdAt = new DateTime($createdAt);
    $now = new DateTime();
    $diff = $now->getTimestamp() - $createdAt->getTimestamp();

    if ($diff < 60) return "just now";
    if ($diff < 3600) return floor($diff / 60) . " minutes ago";
    if ($diff < 86400) return floor($diff / 3600) . " hours ago";
    if ($diff < 172800) return "yesterday";
    if ($diff < 604800) return floor($diff / 86400) . " days ago";

    return floor($diff / 604800) . " weeks ago";
}

// URL helper
function url($path, $params = []) {
    return $path . '?' . http_build_query($params);
}
?>

<link rel="stylesheet" href="../css/job_detail.css" />

<div class="job-details-container">
    <div class="job-details-header">
        <div class="header-title">
            <h1><?= htmlspecialchars($job['job_title'] ?? '') ?></h1>
            <p class="department-name"><?= htmlspecialchars($job['department'] ?? '') ?> Department</p>
        </div>

        <div class="header-actions">

            <?php if ($jobstatus == 3): ?>
                <button type="button" class="btn-edit"
                        onclick="location.href='<?= url("job_edit.php", ["job_ref_no" => $job["job_ref_no"]]) ?>'">
                    ✏️ Edit Job
                </button>
            <?php endif; ?>

            <?php if ($jobstatus == 1): ?>
                <button class="btn-close"
                        onclick="location.href='<?= url("close_job.php", ["job_ref_no" => $job["job_ref_no"]]) ?>'">
                    🗑️ Close Job
                </button>
            <?php endif; ?>

            <?php if ($jobstatus == 2): ?>
                <button class="btn-reopen"
                        onclick="location.href='<?= url("reopen_job.php", ["job_ref_no" => $job["job_ref_no"]]) ?>'">
                    🔄 Reopen Job
                </button>
            <?php endif; ?>

        </div>
    </div>

    <div class="content-grid">
        <div class="main-content">
            <div class="job-info-card">

                <div class="status-badges">
                    <?php
                    $statusColor = $job['status'] == 1 ? "#28a745" :
                                   ($job['status'] == 2 ? "#dc3545" :
                                   ($job['status'] == 3 ? "#950000" : "#FFA500"));

                    $statusText = $job['status'] == 1 ? "Active" :
                                  ($job['status'] == 2 ? "Closed" :
                                  ($job['status'] == 3 ? "Reject" : "Pending"));
                    ?>
                    <span class="badge" style="background-color: <?= $statusColor ?>; color:white;">
                        <?= $statusText ?>
                    </span>
                    <span class="badge badge-secondary">
                        <?= htmlspecialchars($job['job_type'] ?? '') ?>
                    </span>
                </div>

                <div class="job-meta-grid">
                    <div class="meta-item">📍 <?= htmlspecialchars($job['location'] ?? '') ?></div>
                    <div class="meta-item">💼 <?= htmlspecialchars($job['job_type'] ?? '') ?></div>
                     <div class="meta-item">
        💰 RM <?= htmlspecialchars($job['salary_min'] ?? '') ?> - <?= htmlspecialchars($job['salary_max'] ?? '') ?>
    </div>
                    <div class="meta-item">📅 <?= getPostedAgo($job['createdAt'] ?? date("c")) ?></div>
                </div>

                <div class="job-section">
                    <h2>Description</h2>
                    <p><?= nl2br(htmlspecialchars($jobDetail['description'] ?? '')) ?></p>
                </div>

                <div class="job-section">
                    <h2>Key Responsibilities</h2>
                    <ul>
                        <?php
                        $lines = preg_split("/\r\n|\n/", $jobDetail['responsibility'] ?? '');
                        foreach ($lines as $line) {
                            $trimmed = trim($line);
                            if (!empty($trimmed)) echo "<li>" . htmlspecialchars($trimmed) . "</li>";
                        }
                        ?>
                    </ul>
                </div>

                <div class="job-section">
                    <h2>Requirements</h2>
                    <ul>
                        <?php
                        $lines = preg_split("/\r\n|\n/", $jobDetail['requirement'] ?? '');
                        foreach ($lines as $line) {
                            $trimmed = trim($line);
                            if (!empty($trimmed)) echo "<li>" . htmlspecialchars($trimmed) . "</li>";
                        }
                        ?>
                    </ul>
                </div>

            </div>
        </div>

        <div class="sidebar">
            <div class="stats-card">
                <h3>Application Stats</h3>
                <p>Total Applications: <?= $model['TotalApply'] ?></p>
                <p>New: <?= $model['NewCount'] ?></p>
                <p>Reviewed: <?= $model['ReviewedCount'] ?></p>
                <p>Shortlisted: <?= $model['ShortlistedCount'] ?></p>

                <button onclick="location.href='<?= url("job_application.php", ["job_ref_no" => $job["job_ref_no"]]) ?>'">
                    View All Applications
                </button>
            </div>
        </div>
    </div>
</div>
