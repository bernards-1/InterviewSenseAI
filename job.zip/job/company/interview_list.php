<?php
require_once "../includes/firebase_helper.php";
include("../includes/company_layout.php");

/* ===============================
   Firebase Setup
================================ */
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

/* ===============================
   Get job_ref_no from URL
================================ */
$selectedJobRef = $_GET['job_ref_no'] ?? null;

/* ===============================
   Fetch Firebase Data
================================ */
$allInterviews  = $fb->get("tbl_interviews") ?? [];
$allJobs        = $fb->get("tbl_jobs") ?? [];
$allJobseekers  = $fb->get("tbl_jobseeker") ?? [];

/* ===============================
   Prepare Interview List
================================ */
$interviews = [];

foreach ($allInterviews as $iv) {

    // 🔒 Filter by job_ref_no from URL
    if ($selectedJobRef && $iv['job_ref_no'] !== $selectedJobRef) {
        continue;
    }

    /* ---------- Get Job Title ---------- */
    $jobTitle = "Job Not Found";
    foreach ($allJobs as $job) {
        if (($job['job_ref_no'] ?? '') === $iv['job_ref_no']) {
            $jobTitle = $job['job_title'] ?? "Job Not Found";
            break;
        }
    }

    /* ---------- Get Candidate Name ---------- */
    $candidateName = "-";
    foreach ($allJobseekers as $js) {
        if (($js['ref_no'] ?? '') === $iv['jobseeker_ref_no']) {
            $candidateName = $js['name'] ?? "-";
            break;
        }
    }

    /* ---------- Push to List ---------- */
    $interviews[] = [
        'interview_ref_no'        => $iv['interview_ref_no'],
        'job_title'               => $jobTitle,
        'candidate_name'          => $candidateName,
        'interview_date'          => $iv['interview_date'],
        'interview_time'          => $iv['interview_time'],
        'status'                  => $iv['status'],
        'hr_name'                 => $iv['hr_name'] ?? 'Unknown HR',
        'interview_link_company'  => $iv['interview_link_company'] ?? ''
    ];
}
// ===============================
// Calendar Setup
// ===============================
$month = isset($_GET['Month']) ? (int)$_GET['Month'] : (int)date('n');
$year = isset($_GET['Year']) ? (int)$_GET['Year'] : (int)date('Y');

if ($month < 1 || $month > 12) $month = (int)date('n');
if ($year < 2000 || $year > 2100) $year = (int)date('Y');

$heading = date('F Y', mktime(0, 0, 0, $month, 1, $year));
$dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

$firstDayOfMonth = mktime(0, 0, 0, $month, 1, $year);
$numDaysInMonth = date('t', $firstDayOfMonth);
$dayOfWeekFirst = date('N', $firstDayOfMonth);

// Group interviews by date
$eventsByDate = [];
foreach ($interviews as $iv) {
    if (!empty($iv['interview_date'])) {
        $dateKey = date('Y-m-d', strtotime($iv['interview_date']));
        $eventsByDate[$dateKey][] = $iv;
    }
}

// Generate calendar cells (Grid is always complete 7-day rows)
$calendarCells = [];
$prevMonth = $month - 1;
$prevYear = $year;
if ($prevMonth == 0) {
    $prevMonth = 12;
    $prevYear--;
}
$daysInPrevMonth = date('t', mktime(0, 0, 0, $prevMonth, 1, $prevYear));

$startBlankDays = $dayOfWeekFirst - 1;
for ($i = $startBlankDays - 1; $i >= 0; $i--) {
    $day = $daysInPrevMonth - $i;
    $calendarCells[] = [
        'day' => $day,
        'date' => sprintf('%04d-%02d-%02d', $prevYear, $prevMonth, $day),
        'isCurrentMonth' => false,
        'isToday' => false
    ];
}

$todayDate = date('Y-m-d');
for ($day = 1; $day <= $numDaysInMonth; $day++) {
    $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $day);
    $calendarCells[] = [
        'day' => $day,
        'date' => $dateStr,
        'isCurrentMonth' => true,
        'isToday' => ($dateStr === $todayDate)
    ];
}

$remainingCells = 7 - (count($calendarCells) % 7);
if ($remainingCells < 7) {
    $nextMonth = $month + 1;
    $nextYear = $year;
    if ($nextMonth == 13) {
        $nextMonth = 1;
        $nextYear++;
    }
    for ($day = 1; $day <= $remainingCells; $day++) {
        $calendarCells[] = [
            'day' => $day,
            'date' => sprintf('%04d-%02d-%02d', $nextYear, $nextMonth, $day),
            'isCurrentMonth' => false,
            'isToday' => false
        ];
    }
}

// Dropdowns setup
$monthsList = [];
for ($m = 1; $m <= 12; $m++) {
    $monthsList[$m] = date('F', mktime(0, 0, 0, $m, 1, 2000));
}
$yearsList = [];
$startYear = (int)date('Y') - 2;
$endYear = (int)date('Y') + 3;
for ($y = $startYear; $y <= $endYear; $y++) {
    $yearsList[$y] = $y;
}

?>

<style>
.interview-container {
    min-height: calc(100vh - 80px);
    padding: 40px 60px;
    background: linear-gradient(135deg, #175b9e 0%, #64b5f6 100%);
    color: white;
}

.interview-title {
    font-size: 32px;
    font-weight: 600;
    margin-bottom: 20px;
    text-align: center;
}

/* Calendar Styles */
.calendar-wrapper {
    background: white;
    border-radius: 12px;
    padding: 24px;
    color: #333;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.calendar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.calendar-header h2 {
    margin: 0;
    font-size: 24px;
    font-weight: 600;
    color: #1d1d1f;
}

.filter-form select {
    padding: 8px 12px;
    font-size: 16px;
    border-radius: 6px;
    border: 1px solid #ccc;
    margin-left: 10px;
    background: #f8f9fa;
    color: #333;
    cursor: pointer;
}

.cal {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
}

.cal > h3 {
    margin: 0;
    padding: 12px 5px;
    text-align: center;
    background: #f8f9fa;
    font-size: 15px;
    font-weight: 600;
    border-bottom: 1px solid #e0e0e0;
    border-right: 1px solid #e0e0e0;
}
.cal > h3:last-child {
    border-right: none;
}

.cal > div.day-cell {
    border-bottom: 1px solid #e0e0e0;
    border-right: 1px solid #e0e0e0;
    padding: 8px;
    min-height: 120px;
    background: #ffffff;
    display: flex;
    flex-direction: column;
}
.cal > div.day-cell:nth-child(7n) {
    border-right: none;
}

.cal > div.other-month {
    background-color: #f8f9fa;
    color: #9aa0a6;
}

.cal > div.today {
    background-color: #f0f7ff;
}

.cal > div .calender-date {
    font-weight: 500;
    margin-bottom: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 50%;
}

.cal > div.today .calender-date {
    background-color: #1976d2;
    color: #fff;
}

.cal > div .event {
    color: #fff;
    padding: 8px 10px;
    margin-bottom: 8px;
    border-radius: 6px;
    font-size: 13px;
    line-height: 1.4;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0,0,0,0.08);
    display: flex;
    flex-direction: column;
    gap: 6px;
    transition: transform 0.2s, box-shadow 0.2s;
}

.cal > div .event:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.event-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.event-header strong {
    font-size: 13px;
    opacity: 0.95;
    background: rgba(0,0,0,0.15);
    padding: 3px 8px;
    border-radius: 4px;
}

.event-body {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 6px;
}

.event-name {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: 500;
    flex: 1;
}

.event.scheduled {
    background: linear-gradient(135deg, #1976d2 0%, #42a5f5 100%);
}
.event.done {
    background: linear-gradient(135deg, #2e7d32 0%, #66bb6a 100%);
}
.event.cancelled {
    background: linear-gradient(135deg, #c62828 0%, #ef5350 100%);
}

.event-link {
    color: #1d1d1f;
    background-color: #9bfffb;
    text-decoration: none;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 11px;
    flex-shrink: 0;
    transition: background-color 0.2s, color 0.2s;
    display: inline-flex;
    align-items: center;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.event-link:hover {
    background-color: #fff;
    color: #1976d2;
}

.edit-btn {
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    margin-left: 8px;
    background: rgba(255,255,255,0.25);
    padding: 3px 8px;
    border-radius: 4px;
    transition: background-color 0.2s, color 0.2s;
}
.edit-btn:hover {
    background-color: #fff;
    color: #1976d2;
}
</style>

<div class="interview-container">
    <div class="calendar-wrapper">
        <div class="calendar-header">
            <h2><?= htmlspecialchars($heading) ?></h2>
            <form class="filter-form" method="GET">
                <?php if ($selectedJobRef): ?>
                    <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($selectedJobRef) ?>">
                <?php endif; ?>
                <select name="Month" onchange="this.form.submit()">
                    <?php foreach ($monthsList as $mNum => $mName): ?>
                        <option value="<?= $mNum ?>" <?= $mNum == $month ? 'selected' : '' ?>><?= htmlspecialchars($mName) ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="Year" onchange="this.form.submit()">
                    <?php foreach ($yearsList as $yNum): ?>
                        <option value="<?= $yNum ?>" <?= $yNum == $year ? 'selected' : '' ?>><?= $yNum ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>

        <div class="cal">
            <?php foreach ($dayNames as $dayName): ?>
                <h3><?= htmlspecialchars($dayName) ?></h3>
            <?php endforeach; ?>

            <?php foreach ($calendarCells as $cell): 
                $c = "day-cell";
                if (!$cell['isCurrentMonth']) $c .= " other-month";
                if ($cell['isToday']) $c .= " today";
                
                $events = $eventsByDate[$cell['date']] ?? [];
            ?>
                <div class="<?= trim($c) ?>">
                    <div class="calender-date"><?= $cell['day'] ?></div>
                    <?php foreach ($events as $ev): 
                        $statusClass = strtolower($ev['status']);
                        // default to scheduled if status is unknown in classes
                        if (!in_array($statusClass, ['scheduled', 'done', 'cancelled'])) {
                            $statusClass = 'scheduled';
                        }
                    ?>
                        <div class="event <?= htmlspecialchars($statusClass) ?>" title="<?= htmlspecialchars($ev['job_title'] . ' - ' . $ev['candidate_name'] . ' (' . $ev['status'] . ')') ?>">
                            <div class="event-header">
                                <strong>Time: <?= htmlspecialchars($ev['interview_time']) ?></strong>
                                <span class="edit-btn" onclick="openEditModal('<?= $ev['interview_ref_no'] ?>', '<?= $ev['interview_date'] ?>', '<?= $ev['interview_time'] ?>')" title="Edit Schedule">Edit</span>
                            </div>
                            <div class="event-body">
                                <span class="event-name">Candidate : <?= htmlspecialchars($ev['candidate_name']) ?></span>
                            </div>
                            <div class="event-body" style="margin-top: 4px; font-size: 11px; opacity: 0.9;">
                                <span class="event-name">Handle By : <?= htmlspecialchars($ev['hr_name']) ?></span>
                                <?php if (!empty($ev['interview_link_company'])): ?>
                                    <a href="<?= htmlspecialchars($ev['interview_link_company']) ?>" target="_blank" class="event-link">Join</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Edit Interview Modal -->
<div id="editInterviewModal" style="display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; overflow:auto; background:rgba(0,0,0,0.5);">
    <div style="background-color: #fff; margin: 10% auto; padding: 20px; border: 1px solid #888; width: 90%; max-width: 400px; border-radius: 8px; text-align: left; position: relative;">
        <span onclick="closeEditModal()" style="position: absolute; right: 15px; top: 10px; font-size: 28px; cursor: pointer; color: #aaa; line-height: 1;">&times;</span>
        <h3 style="margin-top:5px; margin-bottom: 20px; color: #333; font-size: 1.25rem;">Edit Schedule</h3>
        
        <input type="hidden" id="editInterviewRef" value="">

        <label style="display:block; margin-bottom:5px; color:#555;">New Date:</label>
        <input type="date" id="editInterviewDate" style="width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">

        <label style="display:block; margin-bottom:5px; color:#555;">New Time:</label>
        <input type="time" id="editInterviewTime" style="width: 100%; padding: 8px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 4px;">

        <div style="display: flex; gap: 10px;">
            <button onclick="submitEditInterview()" style="flex: 1; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; transition: opacity 0.2s;">Save Changes</button>
            <button onclick="closeEditModal()" style="flex: 1; padding: 10px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; transition: opacity 0.2s;">Cancel</button>
        </div>
    </div>
</div>

<script>
function openEditModal(refNo, date, time) {
    document.getElementById('editInterviewRef').value = refNo;
    document.getElementById('editInterviewDate').value = date;
    document.getElementById('editInterviewTime').value = time;
    document.getElementById('editInterviewModal').style.display = 'block';
}

function closeEditModal() {
    document.getElementById('editInterviewModal').style.display = 'none';
}

function submitEditInterview() {
    let refNo = document.getElementById('editInterviewRef').value;
    let date = document.getElementById('editInterviewDate').value;
    let time = document.getElementById('editInterviewTime').value;

    if(!date || !time) {
        alert('Please select both date and time.');
        return;
    }

    if(!confirm("Are you sure you want to update the schedule?")) return;

    fetch('../function/company.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'editInterviewSchedule',
            interview_ref_no: refNo,
            date: date,
            time: time
        })
    })
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            alert('Schedule updated successfully!');
            location.reload();
        } else {
            alert('Failed: ' + data.message);
        }
    })
    .catch(err => {
        console.error(err);
        alert('An error occurred while updating.');
    });
}

window.addEventListener('click', function(event) {
    let modal = document.getElementById("editInterviewModal");
    if (event.target == modal) {
        closeEditModal();
    }
});
</script>
