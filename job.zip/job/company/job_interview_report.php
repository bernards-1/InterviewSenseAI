<?php

include '../includes/company_layout.php';

require_once '../includes/firebase_helper.php';

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =============================
// CHECK LOGIN
// =============================
$company_ref_no = $_SESSION["company_ref_no"] ?? null;
if (!$company_ref_no) {
    header("Location: ../login/login.php");
    exit;
}

// =============================
// GET JOB REF FROM URL
// =============================
$jobRefNo = $_GET['job_ref_no'] ?? null;
if (!$jobRefNo) {
    echo "Job Reference Number is missing.";
    exit;
}

// =============================
// FETCH DATA
// =============================
// 1. Get Job Details to verify ownership
$job = $fb->get("tbl_jobs/$jobRefNo");
if (!$job || ($job['company_ref_no'] ?? '') !== $company_ref_no) {
    echo "Job not found or access denied.";
    exit;
}

// 2. Get Interview Reports (interview_candidates/$jobRefNo)
$reports = $fb->get("interview_candidates/$jobRefNo") ?? [];

// 3. Get Applications (Map AppRef -> SeekerRef -> Name)
// Optimization: Fetch all applications for this job (assuming index exists)
// Or fetch ALL applications and filter in PHP if index is tricky (simple for now)
$allApplications = $fb->get("tbl_job_applications") ?? [];
$appMap = []; // appRef -> mapped data

foreach ($allApplications as $appRef => $appData) {
    if (($appData['job_ref_no'] ?? '') === $jobRefNo) {
        $appMap[$appRef] = $appData;
    }
}

// 4. Get JobSeekers (Map SeekerRef -> Name)
// Optimization: Fetch all seekers (assuming small dataset for demo)
$allSeekers = $fb->get("tbl_jobseeker") ?? [];
$seekerMap = [];
foreach ($allSeekers as $sRef => $sData) {
    // $sData key is usually ref_no or key itself
    // Check structure. Usually key is ref_no.
    $ref = $sData['ref_no'] ?? $sRef; 
    $seekerMap[$ref] = $sData;
}

// =============================
// PREPARE TABLE DATA
// =============================
$rows = [];

foreach ($reports as $appRef => $reportData) {
    // If reports are nested by JobSeekerRef inside AppRef?
    // Wait, structure was: `interview_candidates/${JOB_REF}/${APPLICATION_REF}`
    // So $reports is [ AppRef => { ... interview: {...} ... } ] 
    // Wait, the structure in room.php was: `interview_candidates/${JOB_REF}/${APPLICATION_REF}`
    // AND the data saved was `finalData` object.
    
    // Check if $reportData has interview object
    if (!isset($reportData['interview'])) continue;

    $interview = $reportData['interview'];
    
    // Get Candidate Info
    $appName = "Unknown Candidate";
    $seekerRef = "Unknown";
    
    if (isset($appMap[$appRef])) {
        $seekerRef = $appMap[$appRef]['jobseeker_ref_no'] ?? '';
        if (isset($seekerMap[$seekerRef])) {
            $appName = $seekerMap[$seekerRef]['name'] ?? "Unknown Name";
        }
    }

    $overallScore = $interview['overallScore'] ?? 0;
    
    // Extract Confidence & Nervousness from answers
    $avgConf = 0;
    $avgNerv = 0;
    
    // Based on room.php logic, answers[0] holds session data usually, or average of all
    if (!empty($interview['answers']) && isset($interview['answers'][0]['evaluation'])) {
        $eval = $interview['answers'][0]['evaluation'];
        $avgConf = $eval['confidence'] ?? 0;
        $avgNerv = $eval['nervousness'] ?? 0;
    }

    $rows[] = [
        'app_ref' => $appRef,
        'seeker_ref' => $seekerRef,
        'name' => $appName,
        'date' => date("d M Y H:i", ($interview['completedAt'] ?? time()) / 1000),
        'score' => $overallScore,
        'confidence' => $avgConf,
        'nervousness' => $avgNerv,
        'link' => "../interview_report.php?job_id=$jobRefNo&application_id=$appRef"
    ];
}

// Optimization: Sort by Score (Desc) and Take Top 5
usort($rows, function($a, $b) {
    return $b['score'] <=> $a['score'];
});
$rows = array_slice($rows, 0, 5);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comparison Report - <?= htmlspecialchars($job['job_title']) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #175b9e 0%, #64b5f6 100%);
            color: white;
            min-height: 100vh;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
        }

        .header h1 {
            font-size: 40px;
            font-weight: 600;
            color: white;
            margin-top: 55px;
            margin-bottom: 10px;
        }

        .header p {
            color: rgba(255,255,255,0.85);
            font-size: 25px;
        }

        .card {
            width: 90%;
            max-width: 100%;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            overflow: hidden;
            padding: 0;
            margin-left: 75px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 18px 24px;
            text-align: left;
        }

        th {
            background: #f3f4f6;
            color: #6b7280;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        td {
            border-top: 1px solid #e5e7eb;
            font-size: 14px;
            color: #374151;
        }

        tr:hover {
            background-color: #f9fafb;
        }

        /* Score badge */
        .score-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 13px;
        }

        .score-high {
            background: #dcfce7;
            color: #166534;
        }

        .score-med {
            background: #fef3c7;
            color: #92400e;
        }

        .score-low {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Button */
        .btn-view {
            display: inline-block;
            padding: 8px 14px;
            background: #2563eb;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .btn-view:hover {
            background: #1d4ed8;
            transform: translateY(-1px);
        }

        /* Page spacing */
        .page-wrapper {
            padding: 40px 0;
        }
    </style>
</head>
<body>
    <div class="container">
      
        
        <div class="header">
            <h1>Top 5 Interview Comparison Report</h1>
            <p>Job: <strong><?= htmlspecialchars($job['job_title']) ?></strong> (<?= $jobRefNo ?>)</p>
        </div>

        <div class="card">
            <?php if (empty($rows)): ?>
                <div style="padding: 40px; text-align: center; color: #718096;">
                    No interview reports available for this job yet.
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Candidate</th>
                            <th>Date</th>
                            <!--<th>Overall Score</th> -->
                            <th>Confidence</th>
                            <th>Nervousness</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): 
                            $s = $row['score'];
                            $sClass = $s >= 80 ? 'score-high' : ($s >= 60 ? 'score-med' : 'score-low');
                        ?>
                        <tr>
                            <td>
                                <div style="font-weight: 600; color: #2d3748;"><?= htmlspecialchars($row['name']) ?></div>
                                <div style="font-size: 12px; color: #718096;">App: <?= $row['app_ref'] ?></div>
                            </td>
                            <td style="color: #4a5568;"><?= $row['date'] ?></td>
                            <!-- <td>
                                <span class="score-badge <?//= $sClass ?>"><?//= number_format($row['score'], 1) ?>%</span>
                            </td> -->
                            <td>
                                <div style="font-weight: 500;"><?= number_format($row['confidence'], 1) ?>/10</div>
                                <div style="height: 4px; background: #e2e8f0; border-radius: 2px; width: 60px; margin-top: 4px;">
                                    <div style="height: 100%; background: #48bb78; border-radius: 2px; width: <?= ($row['confidence']*10) ?>%;"></div>
                                </div>
                            </td>
                            <td>
                                <div style="font-weight: 500;"><?= number_format($row['nervousness'], 1) ?>/10</div>
                                <div style="height: 4px; background: #e2e8f0; border-radius: 2px; width: 60px; margin-top: 4px;">
                                    <div style="height: 100%; background: #f56565; border-radius: 2px; width: <?= ($row['nervousness']*10) ?>%;"></div>
                                </div>
                            </td>
                            <td>
                                <a href="<?= $row['link'] ?>" class="btn-view" target="_blank">View Report</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
