<?php
require_once '../includes/firebase_helper.php';
include("../includes/company_layout.php");

// =====================
// SESSION CHECK
// =====================
$role = $_SESSION['role'] ?? null;
$company_ref_no = $_SESSION['company_ref_no'] ?? null;

if (!$role || $role !== "2" || !$company_ref_no) {
    header("Location: ../login/login.php");
    exit();
}

// =====================
// INIT FIREBASE
// =====================
$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

$company = null;
$companyPhotos = [];
$companyInfo = ["total_employees" => 0];

// =====================
// FETCH COMPANY DATA
// =====================
try {
    $allCompanies = $fb->get("tbl_company") ?? [];

    foreach ($allCompanies as $comp) {
        if ($comp["company_ref_no"] === $company_ref_no) {
            $company = $comp;
            break;
        }
    }

    if (!$company) {
        die("Company profile not found.");
    }

    // Optional: total employees
    if (isset($company["total_employees"])) {
        $companyInfo["total_employees"] = $company["total_employees"];
    }

    // Fetch company gallery photos
    $allPhotos = $fb->get("tbl_company_photos") ?? [];
    foreach ($allPhotos as $photo) {
        if ($photo["company_ref_no"] === $company_ref_no) {
            $companyPhotos[] = $photo;
        }
    }

} catch (Exception $ex) {
    die("Firebase error: " . $ex->getMessage());
}

// =====================
// FLASH MESSAGES
// =====================
$UpdateImg = $_SESSION["UpdateImg"] ?? null;
$SuccessMessage = $_SESSION["SuccessMessage"] ?? null;
$DeleteSuccessMessage = $_SESSION["DeleteSuccessMessage"] ?? null;
$UploadPhotoSuccessMessage = $_SESSION["UploadPhotoSuccessMessage"] ?? null;

unset($_SESSION["UpdateImg"], $_SESSION["SuccessMessage"], $_SESSION["DeleteSuccessMessage"], $_SESSION["UploadPhotoSuccessMessage"]);

// =====================
// LOGO HANDLING
// =====================
$logoURL = $company["logo_path"] ?? "uploads/company_logo/default.png";
if (!file_exists("../" . $logoURL)) {
    $logoURL = "uploads/company_logo/default.png"; // fallback default
}
?>

<!DOCTYPE html>
<html>

<head>
<title>Company Profile</title>
<link href="../css/CompanyProfile.css" rel="stylesheet">
<style>
.alert-success {
    margin-left: 30%;
    width: 30%;
    color: #443b3b;
    background-color: #90ff90;
    border-color: #70e470;
    position: relative;
}
.alert-success-delete {
    margin-left: 30%;
    width: 30%;
    color: #443b3b;
    background-color: #FF7A7A;
    border-color: #FF7A7A;
    position: relative;
}
.alert {
    padding: 15px 40px 15px 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}
</style>

<script>
    window.setTimeout(function () {
        document.querySelectorAll(".alert").forEach(el => {
            el.style.opacity = 0;
            setTimeout(() => el.remove(), 500);
        });
    }, 3000);
</script>
</head>

<body>

<!-- Alerts -->
<?php if ($UpdateImg): ?>
<div class="alert alert-success"><strong>Success!</strong> <?= $UpdateImg ?></div>
<?php endif; ?>

<?php if ($SuccessMessage): ?>
<div class="alert alert-success"><strong>Success!</strong> <?= $SuccessMessage ?></div>
<?php endif; ?>

<?php if ($DeleteSuccessMessage): ?>
<div class="alert alert-success-delete"><strong>Success!</strong> <?= $DeleteSuccessMessage ?></div>
<?php endif; ?>

<?php if ($UploadPhotoSuccessMessage): ?>
<div class="alert alert-success"><strong>Success!</strong> <?= $UploadPhotoSuccessMessage ?></div>
<?php endif; ?>


<!-- Company Profile -->
<div class="company-profile-container">
    
        <!-- Profile Section -->
        <div class="company-profile-section">
            <div class="profile-header">
                <h1 class="profile-title">Company Profile</h1>
                <button class="btn-edit-profile" onclick="location.href='./edit_profile.php'">
                    Edit Profile
                </button>
            </div>

            <div class="profile-content">
                    <div class="company-header">
                            
                        <!-- Logo Upload -->
                        <div class="company-logo">
                            <img src="../<?= htmlspecialchars($logoURL) ?>" width="48" height="48" style="border-radius: 8px;">
                        </div>

                            <!-- Basic Company Info -->
                            <div class="company-basic-info">
                                <h2 class="company-name"><?= htmlspecialchars($company["company_name"] ?? "") ?></h2>
                                    <div class="company-meta">
                                        <span class="meta-label">
                                            <?= htmlspecialchars($company["city"] ?? "") ?> • <?= htmlspecialchars($company["state"] ?? "") ?>
                                        </span>
                                    </div>
                            </div>
                    </div>

                <!-- About Section -->
                <div class="about-section">
                    <h3 class="section-title">About</h3>
                    <p><?= htmlspecialchars($company["about"] ?? "No description available.") ?></p>
                </div>

                <!-- Company Details -->
                <div class="details-grid">
                    <div class="detail-item"><?= htmlspecialchars($company["address"] ?? "") ?></div>
                    <div class="detail-item"><?= htmlspecialchars($company["email"] ?? "") ?></div>
                    <div class="detail-item"><?= intval($companyInfo["total_employees"] ?? 0) ?> employees</div>
                </div>
            </div>
        </div>

        <!-- Gallery Section -->
        <div class="company-gallery-section">
                    <div class="gallery-header">
                        <h2>Company Gallery</h2>
                        <button class="btn-upload-photos" onclick="document.getElementById('photoUpload').click()">Upload Photos</button>
                        <input type="file" id="photoUpload" accept="image/*" multiple style="display:none;" onchange="handlePhotoUpload(event)">
                    </div>

                    <div class="gallery-grid" id="galleryGrid">

                        <?php
                        $index = 0;
                        $total = count($companyPhotos);
                        $extraCount = $total > 3 ? $total - 2 : 0;

                        foreach ($companyPhotos as $photo):
                            $index++;
                        ?>

                        <?php if ($index <= 2): ?>
                            <div class="gallery-item">
                                <img src="/images/CompanyGallery/<?= $photo["company_ref_no"] ?>/<?= $photo["PhotoPath"] ?>">
                                <button onclick="deletePhoto(<?= $photo["Id"] ?>)">Delete</button>
                            </div>

                        <?php elseif ($index == 3): ?>
                            <div class="gallery-item gallery-item-more" id="showMoreItem">
                                <img src="/images/CompanyGallery/<?= $photo["company_ref_no"] ?>/<?= $photo["PhotoPath"] ?>">
                                <div class="overlay">
                                    <span>+<?= $extraCount ?></span>
                                    <span>View More</span>
                                </div>
                            </div>

                            <div class="gallery-item gallery-hidden">
                                <img src="/images/CompanyGallery/<?= $photo["company_ref_no"] ?>/<?= $photo["PhotoPath"] ?>">
                                <button onclick="deletePhoto(<?= $photo["Id"] ?>)">Delete</button>
                            </div>

                        <?php else: ?>
                            <div class="gallery-item gallery-hidden">
                                <img src="/images/CompanyGallery/<?= $photo["company_ref_no"] ?>/<?= $photo["PhotoPath"] ?>">
                                <button onclick="deletePhoto(<?= $photo["Id"] ?>)">Delete</button>
                            </div>
                        <?php endif; ?>

                        <?php endforeach; ?>

                        <?php if ($total == 0): ?>
                        <p>No photos available.</p>
                        <?php endif; ?>

                    </div>
            <button id="toggleGalleryBtn" style="display:none;">Show Less</button>
        </div>
</div>


<script>
function handlePhotoUpload(event) {
    const files = event.target.files;
    const formData = new FormData();
    const company_ref_no = "<?= $company["company_ref_no"] ?>";

    for (let i = 0; i < files.length; i++) {
        formData.append("Photos[]", files[i]);
    }
    formData.append("company_ref_no", company_ref_no);

    fetch("upload_photos.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(() => location.reload());
}

function deletePhoto(photoId) {
    if (!confirm("Are you sure you want to delete this photo?")) return;

    const formData = new FormData();
    formData.append("photoId", photoId);

    fetch("delete_photo.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) location.reload();
        else alert("Delete failed");
    });
}

document.addEventListener("DOMContentLoaded", function() {
    const showMoreItem = document.getElementById("showMoreItem");

    if (showMoreItem) {
        showMoreItem.addEventListener("click", function() {
            document.querySelectorAll(".gallery-hidden").forEach(el => el.style.display = "block");
            showMoreItem.style.display = "none";
        });
    }
});
</script>

</body>
</html>
