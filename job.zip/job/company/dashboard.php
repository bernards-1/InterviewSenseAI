<?php
include("../includes/company_layout.php");
require_once '../includes/firebase_helper.php';

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

$company_ref_no = $_SESSION["company_ref_no"] ?? $_SESSION["ref_no"] ?? null;

$allJobs = $fb->get("tbl_jobs") ?? [];
$companyJobs = [];

foreach ($allJobs as $job) {
    if (($job['company_ref_no'] ?? '') === $company_ref_no) {
        $companyJobs[] = $job;
    }
}

// Get daily applications for the chart
$allApplications = $fb->get("tbl_job_applications") ?? [];
$dailyApps = [];
foreach ($allApplications as $app) {
    $jobRef = $app['job_ref_no'] ?? '';
    $isCompanyJob = false;
    foreach ($companyJobs as $cj) {
        if ($cj['job_ref_no'] == $jobRef) {
            $isCompanyJob = true; break;
        }
    }
    if ($isCompanyJob) {
        $date = substr($app['createdAt'] ?? '', 0, 10);
        if ($date) {
            if (!isset($dailyApps[$date])) $dailyApps[$date] = 0;
            $dailyApps[$date]++;
        }
    }
}

// Ensure the last 7 days exist
$chartDates = [];
$chartCounts = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartDates[] = date('M d', strtotime($d));
    $chartCounts[] = $dailyApps[$d] ?? 0;
}

// Sorting
$sortOrder = $_GET['sortOrder'] ?? 'desc';

// Status filter
$currentStatus = isset($_GET['status']) ? (int)$_GET['status'] : 4;

// Search
$name = $_GET['name'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



</head>

<style>
.alert-success {
    margin-left: 30%;
    width: 50%;
    color: #443b3b;
    background-color: #90ff90;
    border-color: #70e470;
    position: relative;
}
.alert {
    padding: 15px 40px 15px 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}
.alert .close {
    position: absolute;
    top: 12px;
    right: 15px;
    font-size: 22px;
    font-weight: bold;
    color: #333;
    opacity: 0.4;
    cursor: pointer;
    transition: 0.2s;
}
.alert .close:hover {
    opacity: 1;
}
</style>

<script>
window.setTimeout(function () {
    $(".alert").fadeTo(500, 0).slideUp(500, function () {
        $(this).remove();
    });
}, 3000);
</script>

<body>

<?php if (!empty($_SESSION['Error'])): ?>
<div class="alert alert-success">
    <strong>Success! </strong> <?= $_SESSION['Error']; ?>
</div>
<?php unset($_SESSION['Error']); endif; ?>

<div class="dashboard-container">

    <div class="dashboard-header">
        <div class="dashboard-title-section">
            <h1>Dashboard</h1>
            <p>Welcome back! Here's your recruitment overview</p>
        </div>
        <button class="btn-post-job" onclick="location.href='posting_job.php'">
            <span>+</span> Post New Job
        </button>
    </div>



<?php
$chartDatesJson = json_encode($chartDates);
$chartCountsJson = json_encode($chartCounts);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<div style="background:#fff; padding:20px; border-radius:10px; margin: 20px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
    <h3 style="margin-top:0; color:#333;">Daily Applications (Last 7 Days)</h3>
    <canvas id="dailyAppsChart" height="80"></canvas>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('dailyAppsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= $chartDatesJson ?>,
            datasets: [{
                label: 'Applications Received',
                data: <?= $chartCountsJson ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#4e73df',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { 
                    beginAtZero: true, 
                    ticks: { 
                        stepSize: 1,
                        precision: 0
                    } 
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
});
</script>

    <div class="filters-section">
        <h3 class="filters-title">Filters</h3>
        <div class="filters-grid">

            <!-- Search -->
            <form method="get">
                <div class="filter-item">
                    <input type="text" name="name" id="name" value="<?= htmlspecialchars($name); ?>" 
                           placeholder="Search by Job" class="filter-input">
                </div>
            </form>

            <!-- Sort -->
            <form method="get">
                <div class="filter-item">
                    <select name="sortOrder" class="filter-select" onchange="this.form.submit()">
                        <option value="desc" <?= $sortOrder == 'desc' ? 'selected' : ''; ?>>Newest First</option>
                        <option value="asc" <?= $sortOrder == 'asc' ? 'selected' : ''; ?>>Oldest First</option>
                    </select>
                </div>
            </form>

            <!-- Status -->
            <form method="get">
                <div class="filter-item">
                    <select name="status" class="filter-select" onchange="this.form.submit()">
                        <option value="4" <?= $currentStatus == 4 ? 'selected' : ''; ?>>All Statuses</option>
                        <option value="0" <?= $currentStatus == 0 ? 'selected' : ''; ?>>Pending</option>
                        <option value="1" <?= $currentStatus == 1 ? 'selected' : ''; ?>>Active</option>
                        <option value="2" <?= $currentStatus == 2 ? 'selected' : ''; ?>>Closed</option>
                        <option value="3" <?= $currentStatus == 3 ? 'selected' : ''; ?>>Reject</option>
                    </select>
                </div>
            </form>

        </div>
    </div>

<?php if (!empty($_SESSION['SuccessMessage'])): ?>
<div class="alert alert-success">
    <strong>Success! </strong> <?= $_SESSION['SuccessMessage']; ?>
</div>
<?php unset($_SESSION['SuccessMessage']); endif; ?>

<script>
(function(){
    let timer = null;
    $('#name').on('input', function(e){
        clearTimeout(timer);
        timer = setTimeout(function(){
            $(e.target.form).submit();
        }, 700);
    });
})();
</script>

<div class="jobs-section">
    <h2 class="jobs-section-header">Recent Job Postings</h2>
    <div id="target">
        <?php include "dashboard_partial.php"; ?>
    </div>
</div>

</div>

</body>
</html>
