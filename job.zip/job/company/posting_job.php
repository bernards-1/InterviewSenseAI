<?php
require_once '../includes/firebase_helper.php';
include("../includes/company_layout.php");

$dbUrl = "https://testinterview-9eb8b-default-rtdb.asia-southeast1.firebasedatabase.app/";
$fb = new FirebaseHelper($dbUrl);

// =====================
// SESSION CHECK
// =====================
$role = $_SESSION['role'] ?? null;
$company_ref_no = $_SESSION['company_ref_no'] ?? null;

if (!$role || $role !== "2" || !$company_ref_no) {
    header("Location: ../login/login.php");
    exit();
}

// =====================
// GET COMPANY INFO
// =====================
$allCompanies = $fb->get('tbl_company') ?? [];
$company = null;
foreach ($allCompanies as $comp) {
    if (($comp['company_ref_no'] ?? '') === $company_ref_no) {
        $company = $comp;
        break;
    }
}
$company = $company ?? [];

// =====================
// DEFAULT FORM VALUES
// =====================
$job = [
    "JobTitle" => "",
    "Department" => "",
    "JobType" => "",
    "MinSalary" => "",
    "MaxSalary" => "",
    "state" => $company["state"] ?? "",
    "city" => $company["city"] ?? "",
    "Location" => $company["address"] ?? "",
    "Description" => "",
    "Responsibility" => "",
    "Requirement" => ""
];

// 如果表单提交失败，保留用户输入
if (!empty($_POST)) {
    $job = array_merge($job, $_POST);
}

// =====================
// HANDLE FORM SUBMISSION
// =====================
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 生成 Job ID
    $jobs = $fb->get("tbl_jobs") ?? [];
    $maxJob = "J000";
    foreach ($jobs as $jobItem) {
        if (isset($jobItem["job_ref_no"]) && $jobItem["job_ref_no"] > $maxJob) {
            $maxJob = $jobItem["job_ref_no"];
        }
    }
    $num = intval(substr($maxJob, 1));
    $job_ref_no = "J" . str_pad($num + 1, 3, "0", STR_PAD_LEFT);

    $jobData = [
        "job_ref_no" => $job_ref_no,
        "job_title" => trim($_POST["JobTitle"] ?? ""),
        "department" => trim($_POST["Department"] ?? ""),
        "job_type" => trim($_POST["JobType"] ?? ""),
        "salary_min" => trim($_POST["MinSalary"] ?? ""),
        "salary_max" => trim($_POST["MaxSalary"] ?? ""),
        "state" => $company["state"] ?? "",
        "city" => $company["city"] ?? "",
        "location" => $company["address"] ?? "",
        "status" => 1,
        "company_ref_no" => $company_ref_no,
        "createdAt" => date("c")
    ];

    // 可选验证：MinSalary < MaxSalary
    if (!empty($jobData['salary_min']) && !empty($jobData['salary_max']) &&
        floatval($jobData['salary_min']) >= floatval($jobData['salary_max'])) {
        $error = "Min Salary cannot be higher than Max Salary.";
    }

    if (!$error) {
        try {
            // ✅ 保存到 Firebase: 这里用 put(path, key, data)
            $fb->put("tbl_jobs", $job_ref_no, $jobData);

            $jobDetail = [
                "job_ref_no" => $job_ref_no,
                "description" => trim($_POST["Description"] ?? ""),
                "responsibility" => trim($_POST["Responsibility"] ?? ""),
                "requirement" => trim($_POST["Requirement"] ?? "")
            ];

            $fb->put("tbl_job_details", $job_ref_no, $jobDetail);

            $success = "Job posted successfully!";
            $job = []; // 重置表单
        } catch (Exception $e) {
            $error = "Error posting job: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Post Job</title>
<link rel="stylesheet" href="../css/posting_job.css" />
<style>
.text-danger { color: red; font-size: 0.9rem; margin-top: 4px; display:block; }
.alert-success { color: green; margin-bottom: 15px; }
</style>
</head>

<div class="post-job-container">
    <div class="page-header">
        <h1>Post a New Job</h1>
    </div>
    <p class="page-subtitle">Fill in the details to create a new job posting</p>

    <?php if($success): ?><div class="alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if($error): ?><div class="text-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <form method="post" id="createJobForm" action="" class="form">
        <div class="form-card">
            <h2 class="section-title">Job Details</h2>

            <!-- Job Title -->
            <div class="form-group">
                <label class="form-label">Job Title *</label>
                <input type="text" name="JobTitle" class="form-input" value="<?= htmlspecialchars($job['JobTitle'] ?? '') ?>" placeholder="e.g., Senior Software Engineer"/>
            </div>

            <!-- Department -->
            <div class="form-group">
                <label class="form-label">Department</label>
                <input type="text" name="Department" class="form-input" value="<?= htmlspecialchars($job['Department'] ?? '') ?>" placeholder="e.g., Engineering"/>
            </div>

            <!-- Job Type -->
            <div class="form-group">
                <label class="form-label">Job Type</label>
                <select name="JobType" class="form-select">
                    <option value="">Select type</option>
                    <?php foreach(["Full-time","Part-time","Contract","Internship"] as $type): ?>
                        <option value="<?= $type ?>" <?= ($job['JobType'] ?? '')==$type ? "selected" : "" ?>><?= $type ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Salary -->
            <div class="form-row">
                <div class="form-group">
                    <label>Min Salary</label>
                    <input type="text" name="MinSalary" value="<?= htmlspecialchars($job['MinSalary'] ?? '') ?>" placeholder="3000"/>
                </div>
                <div class="form-group">
                    <label>Max Salary</label>
                    <input type="text" name="MaxSalary" value="<?= htmlspecialchars($job['MaxSalary'] ?? '') ?>" placeholder="5000"/>
                </div>
            </div>

            <!-- State / City / Location -->
            <div class="form-row">
                <div class="form-group">
                    <label>State</label>
                    <input type="text" name="state" value="<?= htmlspecialchars($job['state'] ?? '') ?>" readonly/>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" value="<?= htmlspecialchars($job['city'] ?? '') ?>" readonly/>
                </div>
            </div>
            <div class="form-group">
                <label>Location</label>
                <textarea name="Location" readonly><?= htmlspecialchars($job['Location'] ?? '') ?></textarea>
            </div>

            <!-- Description / Responsibility / Requirement -->
            <div class="form-group">
                <label>Description</label>
                <textarea name="Description"><?= htmlspecialchars($job['Description'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Responsibility</label>
                <textarea name="Responsibility"><?= htmlspecialchars($job['Responsibility'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
                <label>Requirement</label>
                <textarea name="Requirement"><?= htmlspecialchars($job['Requirement'] ?? '') ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">Post Job</button>
                <button type="button" class="btn-secondary" onclick="location.href='../company/dashboard.php'">Cancel</button>
            </div>
        </div>
    </form>
</div>
