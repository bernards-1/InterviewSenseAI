<?php
// Title & layout (if you use template system, include header here)
$title = "Applications";

include("../includes/company_layout.php");

// Get query parameters
$currentJobRefNo = $_GET['job_ref_no'] ?? '';
$name = $_GET['name'] ?? '';
$sortOrder = $_GET['sortOrder'] ?? 'desc';
$status = $_GET['status'] ?? 4;

$info = $_SESSION['Info'] ?? null;
unset($_SESSION['Info']);
?>

<link href="../css/job_application.css" rel="stylesheet" />

<div class="applications-container">
    <div class="page-header">
        <div>
            <h1>Applications</h1>
            <p class="page-subtitle">Manage and review candidate applications</p>
        </div>
    </div>

    <?php if ($info): ?>
        <div class="alert alert-success">
            <strong>Success! </strong> <?= htmlspecialchars($info) ?>
        </div>
    <?php endif; ?>

    <script>
        window.setTimeout(function () {
            $(".alert").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 3000);
    </script>

    <style>
        .alert-success {
            margin-left: 30%;
            width: 50%;
            color: #443b3b;
            background-color: #90ff90;
            border-color: #70e470;
            position: relative;
        }

        .alert {
            padding: 15px 40px 15px 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert .close {
            position: absolute;
            top: 12px;
            right: 15px;
            font-size: 22px;
            font-weight: bold;
            color: #333;
            opacity: 0.4;
            cursor: pointer;
            transition: 0.2s;
        }

        .alert .close:hover {
            opacity: 1;
        }
    </style>

    <div class="filters-section">
        <h3 class="filters-title">Filters</h3>
        <div class="filters-grid">

            <!-- Search Form -->
            <form method="get">
                <?php if (!empty($currentJobRefNo)): ?>
                    <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($currentJobRefNo) ?>" />
                <?php endif; ?>

                <div class="filter-item">
                    <input type="text" id="name" name="name" 
                           value="<?= htmlspecialchars($name) ?>"
                           placeholder="Search by name or Job" 
                           class="filter-input">
                </div>
            </form>

            <!-- Sort Order -->
            <form method="get">
                <?php if (!empty($currentJobRefNo)): ?>
                    <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($currentJobRefNo) ?>" />
                <?php endif; ?>

                <div class="filter-item">
                    <select name="sortOrder" class="filter-select" onchange="this.form.submit()">
                        <option value="desc" <?= $sortOrder == "desc" ? "selected" : "" ?>>Newest First</option>
                        <option value="asc" <?= $sortOrder == "asc" ? "selected" : "" ?>>Oldest First</option>
                    </select>
                </div>
            </form>

            <!-- Status Filter -->
            <form method="get">
                <?php if (!empty($currentJobRefNo)): ?>
                    <input type="hidden" name="job_ref_no" value="<?= htmlspecialchars($currentJobRefNo) ?>" />
                <?php endif; ?>

                <div class="filter-item">
                    <select name="status" class="filter-select" onchange="this.form.submit()">
                        <option value="4" <?= $status == 4 ? "selected" : "" ?>>All Statuses</option>
                        <option value="0" <?= $status == 0 ? "selected" : "" ?>>New</option>
                        <option value="1" <?= $status == 1 ? "selected" : "" ?>>Reviewed</option>
                        <option value="2" <?= $status == 2 ? "selected" : "" ?>>Shortlist</option>
                        <option value="3" <?= $status == 3 ? "selected" : "" ?>>Reject</option>
                    </select>
                </div>
            </form>

        </div>
    </div>

    <div id="target">
        <?php include "./job_application_partial.php"; ?>
    </div>

    <script>
        (function(){
            let timer = null;
            $('#name').on('input', function(e){
                clearTimeout(timer);
                timer = setTimeout(function(){
                    $(e.target.form).submit();
                }, 700);
            });
        })();
    </script>

</div>
