<?php
session_start();

include("../includes/company_layout.php");

// Example model data (replace with DB data)
$model = [
    'CompanyRefNo' => $_SESSION['CompanyRefNo'] ?? '',
    'RegisteredCompanyNumber' => $_POST['RegisteredCompanyNumber'] ?? '',
    'TotalEmployees' => $_POST['TotalEmployees'] ?? '',
    'IndustrySector' => $_POST['IndustrySector'] ?? '',
    'AboutUs' => $_POST['AboutUs'] ?? ''
];

// Example validation errors
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (empty($model['RegisteredCompanyNumber'])) {
        $errors[] = "Registration Number is required.";
    }

    if (empty($model['TotalEmployees'])) {
        $errors[] = "Total Employees is required.";
    }

    if (empty($model['IndustrySector'])) {
        $errors[] = "Industry Sector is required.";
    }

    if (empty($model['AboutUs'])) {
        $errors[] = "About Company is required.";
    }

    // Example: if no errors, save to DB
    if (empty($errors)) {
        $_SESSION['success'] = "Company verification submitted successfully!";
        // TODO: insert into database
        // header("Location: dashboard.php");
        // exit;
    }
}

$title = "Complete Company Verification";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
        }

        .verification-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
        }

        .verification-card {
            background: #ffffff;
            width: 100%;
            max-width: 550px;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }

        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-header h2 {
            color: #2c3e50;
            font-weight: 700;
            font-size: 26px;
            margin: 0 0 10px 0;
        }

        .form-header p {
            color: #7f8c8d;
            font-size: 14px;
            margin: 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #34495e;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #dfe6e9;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s ease;
            box-sizing: border-box;
            background-color: #fcfcfc;
        }

        .form-control:focus {
            border-color: #3498db;
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.15);
            outline: none;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
            font-family: inherit;
        }

        .field-validation-error {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
            display: block;
        }

        .validation-summary-errors {
            color: #c0392b;
            background-color: #fadbd8;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
            list-style: none;
        }

        .validation-summary-errors ul {
            margin: 0;
            padding-left: 20px;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.1s, background-color 0.2s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn:active {
            transform: scale(0.98);
        }

        .btn-submit {
            background-color: #3498db;
            color: white;
        }

        .btn-submit:hover {
            background-color: #2980b9;
        }

        .btn-reset {
            background-color: #ecf0f1;
            color: #7f8c8d;
        }

        .btn-reset:hover {
            background-color: #dfe6e9;
            color: #2c3e50;
        }
    </style>
</head>
<body>

<div class="verification-container">
    <div class="verification-card">

        <div class="form-header">
            <h2>Verify Your Company</h2>
            <p>Please provide company details to activate your account</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="validation-summary-errors">
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post">

            <input type="hidden" name="CompanyRefNo" value="<?= htmlspecialchars($model['CompanyRefNo']) ?>">

            <div class="form-group">
                <label class="form-label">Registration Number</label>
                <input name="RegisteredCompanyNumber"
                       value="<?= htmlspecialchars($model['RegisteredCompanyNumber']) ?>"
                       class="form-control"
                       placeholder="e.g. 202401005678"
                       autofocus>
            </div>

            <div class="form-group">
                <label class="form-label">Total Employees</label>
                <input name="TotalEmployees"
                       type="number"
                       value="<?= htmlspecialchars($model['TotalEmployees']) ?>"
                       class="form-control"
                       placeholder="Enter total employees">
            </div>

            <div class="form-group">
                <label class="form-label">Industry Sector</label>
                <input name="IndustrySector"
                       type="text"
                       value="<?= htmlspecialchars($model['IndustrySector']) ?>"
                       class="form-control"
                       placeholder="Enter Industry Sector">
            </div>

            <div class="form-group">
                <label class="form-label">About Company</label>
                <textarea name="AboutUs"
                          class="form-control"
                          placeholder="Tell us briefly about your company..."><?= htmlspecialchars($model['AboutUs']) ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-submit">Submit Verification</button>
                <button type="reset" class="btn btn-reset">Reset</button>
            </div>

        </form>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</body>
</html>
