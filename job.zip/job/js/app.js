﻿// Initiate GET request (AJAX-supported)
$(document).on('click', '[data-get]', e => {
    e.preventDefault();
    const url = e.target.dataset.get;
    location = url || location;
});

// Initiate POST request (AJAX-supported)
$(document).on('click', '[data-post]', e => {
    e.preventDefault();
    if (!confirm("Are you sure you want to continue?")) {
        return;
    }
    const url = e.target.dataset.post;
    const f = $('<form>').appendTo(document.body)[0];
    f.method = 'post';
    f.action = url || location;
    f.submit();
});

$(document).on('click', '[data-check]', e => {
    e.preventDefault();
    const name = e.target.dataset.check;
    $(`input[type="checkbox"][name="${name}"]`).prop('checked', true);
});

// Uncheck All - 取消全选所有 checkbox
$(document).on('click', '[data-uncheck]', e => {
    e.preventDefault();
    const name = e.target.dataset.uncheck;
    $(`input[type="checkbox"][name="${name}"]`).prop('checked', false);
});

// Checkable - 点击行切换 checkbox 状态
$(document).on('click', '[data-checkable]', e => {
    // 如果点击的是 input 控件或链接,跳过
    if ($(e.target).is('input, button, a')) {
        return;
    }

    // 找到该行内的 checkbox 并切换其状态
    const checkbox = $(e.currentTarget).find('input[type="checkbox"]');
    checkbox.prop('checked', !checkbox.prop('checked'));
});
