Installation & Setup Guide:
1. Prerequisties
-install python 3.12.12 version
-install xampp

2. Verify Python Installation
-after install open command Prompt
-Verify Python Installation
-enter: python --version 
(If it returns "Python 3.12.12", the installation was successful.)

3. Setup the Project Folder
-Move the entire job folder into your XAMPP directory: C:\xampp\htdocs\ 
(The final path should be exactly: C:\xampp\htdocs\job)
-Open XAMPP Control Panel and START both Apache and MySQL

4. Install Python Dependencies
-Navigate to the project folder in C:\xampp\htdocs\job
-Right-click inside the folder and select "Open in Terminal" 
(or open Command Prompt and type -: cd C:\xampp\htdocs\job)
Install the required libraries 
- enter: pip install -r scripts/requirements.txt

5. Start the AI Background Service
-now the directory is C:\xampp\htdocs\job
-enter cd scripts
-enter python app.py

6.Accessing the Platform
Open Google Chrome and go to: http://localhost/job/login/login.php
Test Accounts:
Jobseeker Account: weeee@g.com (Password: 123456)
Company Account: intel@gmail.com (Password: 123456)