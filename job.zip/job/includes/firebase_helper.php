<?php

class FirebaseHelper
{
    private $databaseURL;

    public function __construct($databaseURL)
    {
        $this->databaseURL = rtrim($databaseURL, '/');
    }

    public function post($path, $data)
    {
        $url = $this->databaseURL . "/" . $path . ".json";
        return $this->makeRequest($url, "POST", $data);
    }

    public function put($path, $key, $data)
    {
        $url = $this->databaseURL . "/" . $path . "/" . $key . ".json";
        return $this->makeRequest($url, "PUT", $data);
    }

public function get($path, $query = [])
{
    $url = $this->databaseURL . "/" . $path . ".json";

    if (!empty($query)) {
        // Firebase 要求 orderBy 和 equalTo 的值要带双引号
        $queryString = http_build_query(array_map(function($v) {
            if (is_string($v) && $v[0] != '"') {
                return '"' . $v . '"';
            }
            return $v;
        }, $query));

        $url .= "?" . $queryString;
    }

    return $this->makeRequest($url, "GET");
}


    private function makeRequest($url, $method, $data = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For local dev

        if ($method == "POST") {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method == "PUT") {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("Curl Error: " . $error);
        }

        return json_decode($response, true);
    }
}
?>