﻿<?php
session_start();

/* =====================
   BASIC VARIABLES
===================== */
$title = $title ?? 'JobFinder';
$ref_no = $_SESSION['ref_no'] ?? null;

$themeColor = $_COOKIE['UserTheme'] ?? '#007bff';
$bgColor    = $_COOKIE['UserBgColor'] ?? '#f5f7fa';

$currentPage = basename($_SERVER['PHP_SELF']); // e.g. job_list.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= htmlspecialchars($title) ?> - JobFinder</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/Jobseeker.css">

    <!-- Google Analytics / Firebase Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-65VQT8JBP5"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-65VQT8JBP5');
    </script>

    <style>
        :root {
            --theme-color: <?= $themeColor ?>;
            --bg-color: <?= $bgColor ?>;
            --theme-hover: color-mix(in srgb, var(--theme-color) 85%, black);
            --theme-light: color-mix(in srgb, var(--theme-color) 15%, white);
            --theme-lighter: color-mix(in srgb, var(--theme-color) 5%, white);
            --theme-shadow: color-mix(in srgb, var(--theme-color) 30%, transparent);
        }
        body {
            background-colour: var(--bg-color);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }
        /* 🔹 ALL YOUR CSS IS KEPT AS-IS */
        <?= file_exists(__DIR__.'/layout-style.css') ? file_get_contents(__DIR__.'/layout-style.css') : '' ?>
    </style>
</head>

<body>

<nav class="top-navbar">
    <a href="../jobseeker/joblist.php" class="navbar-brand">
        <div class="brand-icon"></div>
        <img src="../images/AI_Logo.png" style="height:50px; width:auto;">
    </a>

    <ul class="navbar-menu">
        <li class="nav-item">
            <a href="../jobseeker/joblist.php"
               class="nav-link <?= $currentPage === 'joblist.php' ? 'active' : '' ?>">
                <span class="nav-icon">💼</span>
                <span>Jobs</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="../jobseeker/apply_history.php"
               class="nav-link <?= $currentPage === 'apply_history.php' ? 'active' : '' ?>">
                <span class="nav-icon">📄</span>
                <span>Applications</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="../jobseeker/profile.php"
               class="nav-link <?= in_array($currentPage, ['profile.php','edit_profile.php']) ? 'active' : '' ?>">
                <span class="nav-icon">👤</span>
                <span>Profile</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="../practical/index.php" class="nav-link" >
                <span class="nav-icon"></span>
                <span>AI Practice</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="../login/logout.php" class="nav-link text-danger">🚪 Logout</a>
        </li>
    </ul>
</nav>

<main class="main-content">
    <div class="container">
        <?= $content ?? '' ?>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/js/jquery.min.js"></script>

<?= $scripts ?? '' ?>

</body>
</html>
