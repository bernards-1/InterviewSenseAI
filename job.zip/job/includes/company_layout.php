<?php
session_start();

/* =====================
   BASIC VARIABLES
===================== */
$title = $title ?? 'RecruiterPro';
$ref_no = $_SESSION['ref_no'] ?? null;
// Default path prefix to "../" for existing company files if not set
$path_prefix = $path_prefix ?? '../';

/*
  Use current file to detect active menu
  Example filenames:
  dashboard.php
  job_application.php
  posting_job.php
  profile.php
*/
$currentPage = basename($_SERVER['PHP_SELF']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> - RecruiterPro</title>
    <link rel="stylesheet" href="<?= $path_prefix ?>css/layout.css"/>
    <?= $extra_head ?? '' ?>
</head>
<body>

<nav class="top-navbar">
    <a href="<?= $path_prefix ?>company/dashboard.php" class="navbar-brand">
        <img src="<?= $path_prefix ?>images/AI_Logo.png" style="height:50px; width:auto;">
    </a>

    <ul class="navbar-menu">

        <li class="nav-item">
            <a href="<?= $path_prefix ?>company/dashboard.php"
               class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                <span class="nav-icon">📊</span>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?= $path_prefix ?>company/job_application.php"
               class="nav-link <?= $currentPage === 'job_application.php' ? 'active' : '' ?>">
                <span class="nav-icon">📄</span>
                <span>Applications</span>
            </a>
        </li>


        <li class="nav-item">
            <a href="<?= $path_prefix ?>company/job_interview.php"
               class="nav-link <?= $currentPage === 'job_interview.php' ? 'active' : '' ?>">
                <span class="nav-icon">📄</span>
                <span>Interview</span>
            </a>
        </li>

        
        <li class="nav-item">
            <a href="<?= $path_prefix ?>company/posting_job.php"
               class="nav-link <?= $currentPage === 'posting_job.php' ? 'active' : '' ?>">
                <span class="nav-icon">📋</span>
                <span>Post Job</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?= $path_prefix ?>company/profile.php"
               class="nav-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>">
                <span class="nav-icon">👤</span>
                <span>Profile</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?= $path_prefix ?>login/logout.php" class="nav-link text-danger">🚪 Logout</a>
        </li>
    </ul>
</nav>

<?php if (isset($content)): ?>
<main class="main-content">
    <div class="container">
        <?= $content ?>
    </div>
</main>
<?php endif; ?>

<script src="<?= $path_prefix ?>js/jquery.min.js"></script>
<script src="<?= $path_prefix ?>js/jquery.unobtrusive-ajax.min.js"></script>
<script src="<?= $path_prefix ?>js/jquery.validate.min.js"></script>
<script src="<?= $path_prefix ?>js/jquery.validate.unobtrusive.min.js"></script>
<script src="<?= $path_prefix ?>js/app.js"></script>

<?= $scripts ?? '' ?>
<?= $foot ?? '' ?>

</body>
</html>
