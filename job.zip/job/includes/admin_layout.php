<?php
session_start();

/* =====================
   BASIC VARIABLES
===================== */
$title = $title ?? 'RecruiterPro';
$ref_no = $_SESSION['ref_no'] ?? null;

/*
  Use current file to detect active menu
  Example filenames:
  dashboard.php
  companies_maintenance.php
  jobs_maintenance.php
  profile.php
*/
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> - RecruiterPro</title>

    <link rel="stylesheet" href="/css/layout.css"/>
</head>
<body>

<nav class="top-navbar">
    <a href="/admin/dashboard.php" class="navbar-brand">
        <span>Job Recruitment System</span>
    </a>

    <ul class="navbar-menu">
        <li class="nav-item">
            <a href="/admin/dashboard.php"
               class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
                <span class="nav-icon">📊</span>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="/admin/companies_maintenance.php"
               class="nav-link <?= $currentPage === 'companies_maintenance.php' ? 'active' : '' ?>">
                <span class="nav-icon">📄</span>
                <span>Companies Maintenance</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="/admin/jobs_maintenance.php"
               class="nav-link <?= $currentPage === 'jobs_maintenance.php' ? 'active' : '' ?>">
                <span class="nav-icon">📋</span>
                <span>Jobs Maintenance</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="/admin/profile.php"
               class="nav-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>">
                <span class="nav-icon">👤</span>
                <span>Profile</span>
            </a>
        </li>

        <li class="nav-item">
            <a href="/logout.php" class="nav-link text-danger">
                🚪 Logout
            </a>
        </li>
    </ul>
</nav>

<main class="main-content">
    <?= $content ?? '' ?>
</main>

<script src="/js/jquery.min.js"></script>
<script src="/js/jquery.unobtrusive-ajax.min.js"></script>
<script src="/js/jquery.validate.min.js"></script>
<script src="/js/jquery.validate.unobtrusive.min.js"></script>
<script src="/js/app.js"></script>

<?= $scripts ?? '' ?>
<?= $foot ?? '' ?>

</body>
</html>
