<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audio Analysis Test</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #202124; color: #fff; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: #3c4043; padding: 20px; border-radius: 12px; margin-bottom: 20px; }
        h2 { margin-bottom: 15px; color: #8ab4f8; }
        button { padding: 10px 20px; border-radius: 8px; border: none; font-weight: 600; cursor: pointer; }
        button.record { background: #ea4335; color: white; }
        button.stop { background: #3c4043; border: 1px solid #5f6368; color: white; }
        .output-box { background: #202124; padding: 15px; border-radius: 8px; min-height: 50px; margin-top: 10px; font-family: monospace; }
        img.spectrogram { max-width: 100%; border-radius: 8px; margin-top: 10px; display: none; }
        .metrics-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 10px; }
        .metric-card { background: #202124; padding: 10px; border-radius: 8px; }
        .metric-label { font-size: 12px; color: #9aa0a6; }
        .metric-value { font-size: 18px; font-weight: 600; color: #81c995; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Audio Analysis Test</h1>
        
        <!-- Stream 1: Lexical (Text) -->
        <div class="card">
            <h2>1. Lexical Analysis (What you said)</h2>
            <p style="color: #9aa0a6; font-size: 14px;">Using Web Speech API</p>
            <div id="lexicalResult" class="output-box">...</div>
        </div>

        <!-- Stream 2: Prosodic (How you said it) -->
        <div class="card">
            <h2>2. Prosodic Analysis (How you said it)</h2>
            <div style="display: flex; gap: 10px;">
                <button id="recordBtn" class="record">Start Recording</button>
            </div>
            
            <div class="metrics-grid" id="metricsPanel" style="display: none;">
                <div class="metric-card">
                    <div class="metric-label">Pitch (F0)</div>
                    <div class="metric-value" id="pitchVal">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Speaking Rate</div>
                    <div class="metric-value" id="rateVal">-</div>
                </div>
                <div class="metric-card" style="background: #2d3748; border: 1px solid #4a5568;">
                    <div class="metric-label">😎 Confidence</div>
                    <div class="metric-value" id="confVal" style="color: #48bb78;">-</div>
                </div>
                <div class="metric-card" style="background: #2d3748; border: 1px solid #4a5568;">
                    <div class="metric-label">😰 Nervousness</div>
                    <div class="metric-value" id="nervVal" style="color: #f56565;">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Tone Score</div>
                    <div class="metric-value" id="toneVal">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Volume Consistency</div>
                    <div class="metric-value" id="volVal">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Significant Pauses</div>
                    <div class="metric-value" id="pauseVal">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-label">Speech Ratio</div>
                    <div class="metric-value" id="ratioVal">-</div>
                </div>
            </div>

            <img id="spectrogramImg" class="spectrogram" src="" alt="Spectrogram" />
            <div id="status" style="margin-top: 10px; color: #bdc1c6;">Ready</div>
        </div>
    </div>

    <script>
        let mediaRecorder;
        let audioChunks = [];
        let recognition;
        let isRecording = false;

        // Initialize Web Speech API (Lexical)
        if ('webkitSpeechRecognition' in window) {
            recognition = new webkitSpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.onresult = (event) => {
                let finalTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    }
                }
                if (finalTranscript) {
                    document.getElementById('lexicalResult').innerText = finalTranscript;
                }
            };
        } else {
            alert('Web Speech API not supported in this browser.');
        }

        const recordBtn = document.getElementById('recordBtn');
        const statusEl = document.getElementById('status');
        const spectrogramImg = document.getElementById('spectrogramImg');
        const metricsPanel = document.getElementById('metricsPanel');

        recordBtn.onclick = toggleRecording;

        async function toggleRecording() {
            if (!isRecording) {
                // Start
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaRecorder = new MediaRecorder(stream);
                    audioChunks = [];

                    mediaRecorder.ondataavailable = event => {
                        audioChunks.push(event.data);
                    };

                    mediaRecorder.onstop = uploadAudio;

                    mediaRecorder.start();
                    if (recognition) recognition.start(); // Start text recognition

                    isRecording = true;
                    recordBtn.textContent = 'Stop & Analyze';
                    recordBtn.classList.remove('record');
                    recordBtn.classList.add('stop');
                    statusEl.textContent = 'Recording...';
                    spectrogramImg.style.display = 'none';
                    metricsPanel.style.display = 'none';

                } catch (err) {
                    console.error('Error accessing mic:', err);
                    alert('Could not access microphone');
                }
            } else {
                // Stop
                mediaRecorder.stop();
                if (recognition) recognition.stop();

                isRecording = false;
                recordBtn.textContent = 'Start Recording';
                recordBtn.classList.add('record');
                recordBtn.classList.remove('stop');
                statusEl.textContent = 'Processing...';
            }
        }

        async function uploadAudio() {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            const formData = new FormData();
            formData.append('action', 'analyze_uploaded_audio'); // NEW ACTION
            formData.append('audio_data', audioBlob, 'recording.webm');

            statusEl.textContent = 'Uploading to Gemini... (This takes a few seconds)';
            
            try {
                // Change URL to ai_service.php
                const response = await fetch('api/ai_service.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                console.log(result);

                if (result.success) {
                    // Log which key was used
                    console.log("✅ Success! Used API Key #" + result.debug_key_index);
                    statusEl.textContent = 'Analysis Complete (Gemini) - Used Key #' + result.debug_key_index;
                    
                    // Display Gemini Transcription
                    const geminiText = result.data.transcription || "No text found";
                    const webSpeechText = document.getElementById('lexicalResult').innerText;

                    document.getElementById('lexicalResult').innerHTML = `
                        <strong>Web Speech (Real-time):</strong><br>${webSpeechText}<br><br>
                        <strong>Gemini (Verbatim):</strong><br>${geminiText}
                    `;

                    // Display Analysis from Gemini
                    const analysis = result.data.analysis || {};
                    
                    // We map Gemini fields to existing UI cards where possible
                    document.getElementById('pitchVal').textContent = "AI Analysis"; // Pitch is raw DSP, AI gives qualitative
                    document.getElementById('rateVal').textContent = analysis.speaking_rate_comment || 'N/A';
                    document.getElementById('confVal').textContent = analysis.confidence_score ? analysis.confidence_score + '%' : 'N/A';
                    document.getElementById('nervVal').textContent = analysis.tone || 'N/A';
                    document.getElementById('toneVal').textContent = "See Tone";
                    
                    // Hide Raw DSP metrics that aren't calculated anymore
                    document.getElementById('spectrogramImg').style.display = 'none'; // No spectrogram from Gemini
                    
                    metricsPanel.style.display = 'grid';
                } else {
                    statusEl.textContent = 'Error: ' + result.message;
                }

            } catch (error) {
                console.error('Upload failed:', error);
                statusEl.textContent = 'Upload failed: ' + error.message;
            }
        }
    </script>
</body>
</html>
