<?php
header('Content-Type: application/json');

// 1. Files setup
$uploadDir = '../uploads/audio/';
$generatedDir = '../generated_audio/';
$scriptPath = '../scripts/analyze_audio.py';

if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
if (!file_exists($generatedDir)) mkdir($generatedDir, 0777, true);

$response = ['success' => false, 'message' => '', 'data' => []];

// 2. Handle Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['audio_data'])) {
    
    $file = $_FILES['audio_data'];
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    if (!$ext) $ext = 'webm'; // Default to webm if missing
    
    $filename = 'audio_' . time() . '.' . $ext;
    $uploadPath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        
        // 3. Prepare Python Command
        // Usage: python analyze_audio.py <input_path> <output_spectrogram_path>
        $spectrogramFilename = 'spec_' . time() . '.png';
        $spectrogramPath = $generatedDir . $spectrogramFilename;
        
        // Escape paths
        $cmdInput = escapeshellarg(realpath($uploadPath));
        $cmdOutput = escapeshellarg(realpath($generatedDir) . DIRECTORY_SEPARATOR . $spectrogramFilename);
        $cmdScript = escapeshellarg(realpath('../scripts') . DIRECTORY_SEPARATOR . 'analyze_audio.py');

        // Check availability of Python
        // Try 'python' or 'python3'
        $pythonCmd = 'python'; 
        
        $fullCmd = "$pythonCmd $cmdScript $cmdInput $cmdOutput 2>&1";
        
        // 4. Execute
        $output = [];
        $returnCode = 0;
        exec($fullCmd, $output, $returnCode);
        
        // 5. Parse Output
        // The script should print a JSON string as the last line
        $jsonOutput = implode("\n", $output);
        
        if ($returnCode === 0) {
            // Find JSON in output
            // We expect the script to print regular JSON
            // We might need to filter out warnings if any
            $jsonStart = strpos($jsonOutput, '{');
            $jsonEnd = strrpos($jsonOutput, '}');
            
            if ($jsonStart !== false && $jsonEnd !== false) {
                $jsonStr = substr($jsonOutput, $jsonStart, $jsonEnd - $jsonStart + 1);
                $analysisData = json_decode($jsonStr, true);
                
                if ($analysisData) {
                    $response['success'] = true;
                    $response['data'] = array_merge($analysisData, [
                        'spectrogram_url' => 'generated_audio/' . $spectrogramFilename
                    ]);
                } else {
                    $response['message'] = 'Failed to decode Python JSON output';
                    $response['debug'] = $output;
                }
            } else {
                 // Fallback Mock Data if Python script didn't output JSON (e.g. library missing)
                $response['message'] = 'Python script did not return JSON. Using Mock Data for display.';
                $response['debug'] = $output;
                
                // MOCK DATA FOR DEMO if python fails
                $response['success'] = true;
                $response['data'] = [
                    'pitch_avg' => 120.5,
                    'tempo' => 110.0,
                    'tone_score' => 85,
                    'volume_consistency' => 0.9,
                    'spectrogram_url' => 'generated_audio/sample_spectrogram.png' // You might want a default image
                ];
            }
        } else {
            $response['message'] = 'Python script execution failed';
            $response['debug'] = $output;
        }

    } else {
        $response['message'] = 'Failed to move uploaded file';
    }
    
} else {
    $response['message'] = 'No audio data received';
}

echo json_encode($response);
?>
