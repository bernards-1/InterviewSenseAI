<?php
// api/parse_resume.php - Resume parsing endpoint
header('Content-Type: application/json');
require_once '../utils.php';

$resumeText = $_POST['resumeText'] ?? '';

if (empty($resumeText)) {
    echo json_encode(['success' => false, 'message' => 'No resume text provided']);
    exit;
}

$structured = parseResume($resumeText);

echo json_encode([
    'success' => true,
    'structured' => $structured
]);
?>