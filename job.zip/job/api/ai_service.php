<?php
// api/ai_service.php - AI Service Integration
// Exclusively using Google Gemini API

header('Content-Type: application/json');
require_once '../config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'generate_questions':
        generateQuestions();
        break;

    case 'evaluate_answer':
        evaluateAnswer();
        break;

    case 'analyze_resume':
        analyzeResume();
        break;

    case 'analyze_uploaded_audio':
        analyzeUploadedAudio();
        break;

    case 'analyze_live_audio_chunk': // NEW for Live Interview
        analyzeLiveAudioChunk();
        break;

    case 'generate_multimodal_summary':
        generateMultimodalSummary();
        break;

    case 'generate_hr_summary': // NEW for HR Interview
        generateHRSummary();
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

// ... (Existing functions) ...

function generateHRSummary() {
    $sessionData = json_decode($_POST['session_data'] ?? '[]', true);
    $jobRole = $_POST['jobRole'] ?? 'Candidate';

    if (empty($sessionData)) {
        echo json_encode(['success' => false, 'message' => 'No session data provided']);
        return;
    }

    $fullTranscript = "";
    $behavioralSummary = "";

    foreach ($sessionData as $item) {
        $transcription = $item['transcription'] ?? '';
        if (!empty($transcription)) {
            $fullTranscript .= $transcription . " ";
        }

        $blinkBpm = $item['blinkData']['bpm'] ?? '0';
        
        // Determine dominant emotion
        $emotions = $item['emotionData'] ?? [];
        $domEmotion = 'Neutral';
        $maxVal = -1;
        foreach ($emotions as $emo => $count) {
            if ($count > $maxVal) {
                $maxVal = $count;
                $domEmotion = $emo;
            }
        }
        
        $behavioralSummary .= "- Chunk: Emotion=$domEmotion, BlinkRate={$blinkBpm}bpm\n";
    }
    
    // Fallback if transcript is empty
    if (empty(trim($fullTranscript))) {
        $fullTranscript = "[No speech detected in this session]";
    }

    // NEW: Use Explicit Summary Stats if available
    $summaryStats = json_decode($_POST['summary_stats'] ?? '[]', true);
    $finalBpm = $summaryStats['avgBpm'] ?? 'Unknown';
    $totalBlinks = $summaryStats['totalBlinks'] ?? 'Unknown';
    $duration = isset($summaryStats['durationSecs']) ? number_format($summaryStats['durationSecs'] / 60, 1) . " mins" : "Unknown";

    $prompt = "You are an expert HR Recruiter analyzing a job interview for a '$jobRole' position.
    
    **Session Transcript (Continuous Audio):**
    \"$fullTranscript\"
    
    **Overall Session Stats:**
    - Duration: $duration
    - Average Blink Rate: $finalBpm bpm (Normal is 10-20 bpm)
    - Total Blinks: $totalBlinks
    
    **Behavioral Signals (Every ~30s):**
    $behavioralSummary
    
    Task: Write a concise and punchy hiring assessment (approx 50-80 words max) AND calculate a Hiring Score (0-100).
    - **Executive Summary**: Very brief, punchy overview of the candidate's profile and communication style. Focus only on the most critical points.
    - **Strengths**: Key competencies and soft skills demonstrated (bullet points format if possible).
    - **Red Flags / Concerns**: Any critical hesitation or nervousness signals. (Avoid mentioning blink rate or facial expressions unless they are extreme outliers).
    - **Hiring Score**: A holistic score from 0-100 based on the above factors.
    - **Dominant State**: One word describing their overall demeanor (e.g., \"Confident\", \"Nervous\", \"Neutral\", \"Hesitant\", \"Energetic\").
    - **State Reasoning**: One short sentence explaining WHY (e.g., \"Frequent fillers and high blink rate indicate anxiety.\").
    
    Return purely the assessment text in JSON format:
    {
        \"summary\": \"The candidate showed strong technical skills but lacked communication clarity...\",
        \"hiring_score\": 85,
        \"dominant_state\": \"Confident\",
        \"state_reason\": \"Maintained steady eye contact and spoke clearly without fillers.\"
    }";

    $resultData = callGeminiAPIWithAudio($prompt);
    
    if ($resultData['success']) {
        $text = $resultData['text'];
        
        // Clean JSON
        if (preg_match('/(\{[\s\S]*\}|\[[\s\S]*\])/', $text, $matches)) {
            $text = $matches[0];
        } else {
            $text = preg_replace('/^```json\s*/', '', $text);
            $text = preg_replace('/^```\s*/', '', $text);
            $text = preg_replace('/\s*```$/', '', $text);
            $text = trim($text);
        }

        $data = json_decode($text, true);
        echo json_encode([
            'success' => true, 
            'summary' => $data['summary'] ?? $text,
            'debug_key_index' => $resultData['used_key_index'] ?? 'unknown'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to generate HR summary: ' . ($resultData['error'] ?? 'Unknown')]);
    }
}

function analyzeUploadedAudio() {
    // ... (Keep existing function as is) ...
    if (!isset($_FILES['audio_data'])) {
        echo json_encode(['success' => false, 'message' => 'No audio file received']);
        return;
    }

    $file = $_FILES['audio_data'];
    $fileData = file_get_contents($file['tmp_name']);
    $base64Audio = base64_encode($fileData);
    $mimeType = $file['type'] ?: 'audio/webm'; // Fallback

    // Capture Context Data
    $blinkData = $_POST['blink_data'] ?? 'Not provided';
    $emotionData = $_POST['emotion_data'] ?? 'Not provided';
    $questionText = $_POST['question'] ?? 'Unknown Question';
    $jobRole = $_POST['jobRole'] ?? 'Unknown Role';

    $contextPrompt = "
    [Context Data]
    - Interview Question: $questionText
    - Target Job Role: $jobRole
    - User Blink Stats: $blinkData
    - User Emotion Distribution: $emotionData
    
    Please listen to the attached audio answer and review the [Context Data].
    1. Transcribe it exactly (verbatim) including filler words like 'um', 'ah', 'hrm'.
    2. Analyze the speaker's tone, confidence level, and speaking rate.
    3. Calculate two weighted scores strictly based on this formula:
    
       **Formula Context:**
       - **Audio Stability (50%)**: \"Erm\", \"ah\", \"hmm\", hesitation, shaky voice.
       - **Blink Rate (30%)**: Normal (10-20bpm) is good. Low (<10) or High (>30) is bad.
       - **Facial Expression (15%)**: Confident/Happy is good. Nervous/Fear is bad.
       - **Length/Substance (5%)**: >10 words is good.
       
       **A) Weighted Confidence Score (0-10) - High is Good**:
       - Audio: 10/10 (No fillers) -> 2/10 (Many fillers). (Weight: 50%)
       - Blink: 10/10 (Normal) -> 5/10 (Abnormal). (Weight: 30%)
       - Face: 10/10 (Positive) -> 4/10 (Negative). (Weight: 15%)
       - Length: 10/10 (Good) -> 2/10 (Short). (Weight: 5%)
       
       **B) Weighted Nervousness Score (0-10) - High is Bad (High = Very Nervous)**:
       - **Audio (50%)**: 
         - Many fillers (\"erm\", \"ah\") = 10/10 Nervousness.
         - Clear speech = 0/10 Nervousness.
       - **Blink (30%)**: 
         - Abnormal rate (<10 or >30) = 8/10 Nervousness.
         - Normal rate = 0/10 Nervousness.
       - **Face (15%)**: 
         - Fear/Nervous = 10/10 Nervousness.
         - Neutral/Happy = 0/10 Nervousness.
       - **Length (5%)**: 
         - Very short/Abrupt = 8/10 Nervousness.
         - Good length = 0/10 Nervousness.

    Return JSON:
    {
        \"transcription\": \"The exact text...\",
        \"analysis\": {
            \"tone\": \"...\",
            \"confidence_score\": 8,
            \"nervousness_score\": 2, 
            \"weighted_breakdown\": \"Conf: 8.0 / Nerv: 2.0 (Audio: Low Fillers)\",
            \"speaking_rate_comment\": \"...\",
            \"multimodal_feedback\": \"Concise feedback...\",
            \"answer_guidance\": \"1. Focus strictly on what the candidate did WRONG or missed in their answer. Identify specific pitfalls.\\n\\n2. Provide 2-3 actionable bullets on HOW to best answer this specific type of question (e.g. 'Use the STAR method').\\n\\nFormat this field as a numbered list with clear line breaks (\\n\\n) between points. Do NOT provide a model answer here.\",
            \"suggested_answer\": \"CRITICAL: Base this heavily on the candidate's actual transcription if they provided an answer (even a short or informal one like 'I listen to music' or 'I play games'). Elevate their exact idea into a professional, well-structured STAR response tailored to the [Target Job Role]. Example: if they say 'I listen to music', the suggested answer should be 'I manage stress by taking short breaks to listen to music, which helps me reset my focus...'.  ONLY IF their answer is literally 'I don't know', completely empty, or entirely off-topic, should you invent a completely new, realistic technical STAR example related to the [Interview Question]. DO NOT use generic filler like 'I would research extensively'. Max 60 words.\"
        }
    }";
    
    // Call Gemini with Audio + Context Prompt
    $result = callGeminiAPIWithAudio($contextPrompt, $base64Audio, $mimeType);
    
    if ($result['success']) {
        // Clean JSON
        $text = $result['text'];
        if (preg_match('/(\{[\s\S]*\}|\[[\s\S]*\])/', $text, $matches)) {
            $text = $matches[0];
        }
        
        $data = json_decode($text, true);
        echo json_encode([
            'success' => true, 
            'data' => $data,
            'debug_key_index' => $result['used_key_index'] ?? 'unknown'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gemini API failed: ' . ($result['error'] ?? 'Unknown error')]);
    }
}

function analyzeLiveAudioChunk() {
    if (!isset($_FILES['audio_data'])) {
        echo json_encode(['success' => false, 'message' => 'No audio file received']);
        return;
    }

    $file = $_FILES['audio_data'];
    $fileData = file_get_contents($file['tmp_name']);
    $base64Audio = base64_encode($fileData);
    $mimeType = $file['type'] ?: 'audio/webm';

    // Context Data
    $blinkData = $_POST['blink_data'] ?? 'Not provided';
    $emotionData = $_POST['emotion_data'] ?? 'Not provided';
    $historyContext = $_POST['history_context'] ?? ''; // NEW: Old Transcriptions

    $contextPrompt = "
    [Context Data - Live Interview Session]
    - User Blink Stats: $blinkData
    - User Emotion Distribution: $emotionData
    - **Previous Conversation History**: \"$historyContext\"
    
    Please listen to the ATTACHED audio chunk (newest 30s) and analyze it in the context of the **Previous Conversation History**.
    
    1. Transcribe the new chunk strictly verbatim (include 'um', 'ah','hmm','erm','uh','er').
    2. Analyze speaker's *cumulative* state (Confidence/Nervousness), considering how they have performed throughout the session so far (History + New Chunk).
    
    **Scoring Formula (Cumulative):**
    - **Audio Stability (50%)**: fillers, hesitation (in both history and new audio).
    - **Blink Rate (30%)**: Current rate (Ideal: 10-30 bpm).
    - **Facial Expression (20%)**: Current distribution (Confidence/Happy is good).

    Return JSON (No 'answer_guidance' needed):
    {
        \"transcription\": \"... (Text of NEW chunk only) ...\",
        \"analysis\": {
            \"tone\": \"...\",
            \"confidence_score\": 7,
            \"nervousness_score\": 3, 
            \"weighted_breakdown\": \"...\",
            \"speaking_rate_comment\": \"...\",
            \"multimodal_feedback\": \"Cumulative feedback based on session so far...\"
        }
    }";
    
    $result = callGeminiAPIWithAudio($contextPrompt, $base64Audio, $mimeType);
    
    if ($result['success']) {
        $text = $result['text'];
        if (preg_match('/(\{[\s\S]*\}|\[[\s\S]*\])/', $text, $matches)) {
            $text = $matches[0];
        }
        
        $data = json_decode($text, true);
        echo json_encode([
            'success' => true, 
            'data' => $data,
            'debug_key_index' => $result['used_key_index'] ?? 'unknown'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gemini API failed: ' . ($result['error'] ?? 'Unknown error')]);
    }
}



function generateQuestions()
{
    $resume = json_decode($_POST['resume'] ?? '{}', true);
    $resumeText = is_array($resume) ? json_encode($resume) : $resume;
    $jobRole = $_POST['jobRole'] ?? 'Software Developer';

    // 1. Manual Common Questions Pool 
    $manualPool = [
        "What are your greatest strengths?",
        "What do you consider your biggest weakness?",
        "Where do you see yourself in 5 years?",
        "Why do you want to leave your current role?",
        "Describe a time you handled a conflict at work.",
        "How do you handle stress and pressure?",
        "Why should we hire you?",
        "What motivates you?",
        "Describe your ideal work environment."
    ];

    // Shuffle and pick 1 unique question from the pool
    shuffle($manualPool);
    $selectedRandom = array_slice($manualPool, 0, 1);
    
    // Construct the final manual list: "Tell me about yourself" + 1 Random = 2 Common Questions
    $finalManual = array_merge(["Tell me about yourself."], $selectedRandom);
    
    $questions = [];
    foreach ($finalManual as $qText) {
        $questions[] = [
            'id' => uniqid('mq_'),
            'type' => 'behavioral',
            'question' => $qText
        ];
    }

    // 2. Generate 1 Technical Question via AI
    $prompt = "You are an expert technical interviewer.
    Generate exactly 1 technical interview question for a candidate applying for the role of '{$jobRole}'.
    
    Candidate Resume/Context: {$resumeText}
    
    CRITICAL CONSTRAINT: The question must be SHORT and CONCISE (max 20 words). 
    Do not explain the answer. Just ask the direct question.

    Please provide the output strictly as a JSON array of objects.
    Each object must have:
    - 'id' (unique string)
    - 'type' (must be 'technical')
    - 'question' (technical question content)
    
    Do not include markdown formatting, just the raw JSON.";

    $jsonResponse = callGeminiAPI($prompt);
    $techQuestions = [];

    if ($jsonResponse) {
        $decoded = json_decode($jsonResponse, true);
        if (is_array($decoded)) {
            $techQuestions = $decoded;
        }
    }

    // Fallback for technical questions if API fails
    if (empty($techQuestions)) {
        $techQuestions = [
            ['id' => uniqid('tq_'), 'type' => 'technical', 'question' => "What technical skills make you a good fit for this $jobRole role?"],
            ['id' => uniqid('tq_'), 'type' => 'technical', 'question' => "Describe a challenging technical problem you solved recently."]
        ];
    }

    // Limit to exactly 2 technical questions just in case
    $techQuestions = array_slice($techQuestions, 0, 2);

    // Merge: 5 Manual + 2 Technical
    $questions = array_merge($questions, $techQuestions);

    echo json_encode([
        'success' => true,
        'questions' => $questions
    ]);
}

function evaluateAnswer()
{
    $question = $_POST['question'] ?? '';
    $answer = $_POST['answer'] ?? '';
    $jobRole = $_POST['jobRole'] ?? '';

    $prompt = "You are a strict technical interviewer evaluating a candidate for the role of '{$jobRole}'.
    
    Current Interview Question: \"{$question}\"
    Candidate's Spoken Input: \"{$answer}\"
    
    Task: Evaluate the response strictly based on the User's input.
    
    RULES:
    1. **INTERACTION Check**: If the candidate asks to repeat the question, clarify, says \"I didn't hear\", \"Can you say that again?\", etc.:
       RETURN JSON:
       {
           \"type\": \"interaction\",
           \"message\": \"Sure, I will repeat the question. {$question}\"
       }
    
    2. **LENGTH Check**: If the answer is too short (less than 10 words) or gives zero substance (e.g., \"I don't know\", \"Maybe\", \"Yes\"):
       RETURN JSON:
       {
           \"type\": \"evaluation\",
           \"confidence\": 2,
           \"nervousness\": 8,
           \"feedback\": \"Your answer is too short and lacks detail. Please elaborate more.\",
           \"suggestions\": [\"Provide specific examples\", \"Explain your reasoning\"]
       }
       
    3. **RELEVANCE Check**: If the answer is completely off-topic or does not address the specific question asked:
       RETURN JSON:
       {
           \"type\": \"evaluation\",
           \"confidence\": 5,
           \"nervousness\": 5,
           \"feedback\": \"You did not answer the question directly. Please focus on what was asked.\",
           \"suggestions\": [\"Listen carefully to the question\", \"Stay on topic\"]
       }

    4. **STANDARD Evaluation**: If the answer is a valid attempt:
       - Confidence: 0-10 (High is better)
       - Nervousness: 0-10 (High means very nervous, Low means calm)
       RETURN JSON:
       {
           \"type\": \"evaluation\",
           \"confidence\": (0-10),
           \"nervousness\": (0-10),
           \"feedback\": \"Specific feedback on their answer.\",
           \"suggestions\": [\"Improvement point 1\", \"Improvement point 2\"]
       }
    
    Output strictly raw JSON only. No markdown.";

    $jsonResponse = callGeminiAPI($prompt);
    $evaluation = null;

    if ($jsonResponse) {
        $decoded = json_decode($jsonResponse, true);
        if (is_array($decoded)) {
            $evaluation = $decoded;
        }
    }

    // Fallback if API fails
    if (!$evaluation) {
        $evaluation = [
            'type' => 'evaluation',
            'relevance' => 5, 'clarity' => 5, 'confidence' => 5, 'accuracy' => 5,
            'feedback' => "Unable to process AI evaluation at the moment.",
            'suggestions' => ["Please try answering again."]
        ];
    }

    echo json_encode([
        'success' => true,
        'evaluation' => $evaluation
    ]);
}

function analyzeResume()
{
    // Resume analysis uses local utility for matching score
    // Can be upgraded to Gemini if needed, but keeping existing logic for now
    $resume = json_decode($_POST['resume'] ?? '{}', true);
    $jobRole = $_POST['jobRole'] ?? '';

    require_once '../utils.php';

    $matchScore = calculateResumeMatchScore($resume, $jobRole);
    $explanation = generateMatchExplanation($resume, $jobRole, $matchScore);

    echo json_encode([
        'success' => true,
        'matchScore' => $matchScore,
        'explanation' => $explanation
    ]);
}

function generateMatchExplanation($resume, $jobRole, $score)
{
    $explanation = "Resume Match Analysis for $jobRole position:\n\n";
    if ($score >= 80) $explanation .= "Excellent match! ";
    elseif ($score >= 60) $explanation .= "Good match! ";
    else $explanation .= "Moderate match. ";
    return $explanation;
}

// ========== HELPER FUNCTION ==========

/* 
 * Replaced with unified function below 
 */
 
// The functions above generatedQuestions/evaluateAnswer still call callGeminiAPI
// So we update it here:

function callGeminiAPI($prompt) {
    $result = callGeminiAPIWithAudio($prompt, null, null);
    return $result['success'] ? $result['text'] : null;
}

function callGeminiAPIWithAudio($prompt, $base64Audio = null, $mimeType = null) {
    if (defined('GEMINI_API_KEYS')) {
        $apiKeys = GEMINI_API_KEYS;
    } elseif (defined('GEMINI_API_KEY')) {
        $apiKeys = [GEMINI_API_KEY];
    }

    if (empty($apiKeys)) {
        error_log("No Gemini API Keys configured.");
        return null;
    }
    
    $parts = [
        ["text" => $prompt]
    ];

    if ($base64Audio) {
        $parts[] = [
            "inline_data" => [
                "mime_type" => $mimeType,
                "data" => $base64Audio
            ]
        ];
    }

    // Try each key until one works
    foreach ($apiKeys as $index => $apiKey) {
        if (empty($apiKey) || $apiKey === 'YOUR_SECOND_API_KEY_HERE') continue; 

        // USE GEMINI 1.5 FLASH for Audio Support!
        //Gemini 2.5 Flash Lite
        //Gemini 2.5 Flash 
        // USE GEMINI 1.5 FLASH for Audio Support!
        $model = "gemini-2.5-flash"; 
        
        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";

        $data = [
            "contents" => [
                [
                    "parts" => $parts
                ]
            ],
            "generationConfig" => [
                "responseMimeType" => "application/json"
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        
        curl_close($ch);
        
        if ($httpCode === 200 && !$curlError) {
             $decoded = json_decode($response, true);
            $text = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? null;

             if ($text) {
                if (preg_match('/(\{[\s\S]*\}|\[[\s\S]*\])/', $text, $matches)) {
                    $text = $matches[0];
                } else {
                    $text = preg_replace('/^```json\s*/', '', $text);
                    $text = preg_replace('/^```\s*/', '', $text);
                    $text = preg_replace('/\s*```$/', '', $text);
                    $text = trim($text);
                }
                return ['success' => true, 'text' => $text, 'used_key_index' => $index + 1];
            }
        } else {
            $lastError = "Key usage failed. HTTP: $httpCode. Error: $curlError. Response: $response";
            error_log("Gemini API Key #$index failed: $lastError");
        }
    }

    return ['success' => false, 'error' => $lastError ?? "All keys exhausted or invalid config."];
}

function generateMultimodalSummary() {
    $sessionData = json_decode($_POST['session_data'] ?? '[]', true);
    $jobRole = $_POST['jobRole'] ?? 'Candidate';

    if (empty($sessionData)) {
        echo json_encode(['success' => false, 'message' => 'No session data provided']);
        return;
    }

    $dataPrompt = "";
    foreach ($sessionData as $item) {
        $q = $item['question'] ?? 'Unknown Question';
        $ans = $item['transcription'] ?? '';
        $tone = $item['audioAnalysis']['tone'] ?? 'N/A';
        $conf = $item['audioAnalysis']['confidence_score'] ?? 'N/A';
        
        $blinkBpm = $item['blinkData']['bpm'] ?? '0';
        $blinkStatus = $item['blinkData']['status'] ?? 'Normal';
        
        // Determine dominant emotion
        $emotions = $item['emotionData'] ?? [];
        $domEmotion = 'Neutral';
        $maxVal = -1;
        foreach ($emotions as $emo => $count) {
            if ($count > $maxVal) {
                $maxVal = $count;
                $domEmotion = $emo;
            }
        }

        $dataPrompt .= "- Q: \"$q\"\n";
        $dataPrompt .= "  - Tone: $tone (Conf: $conf%)\n";
        $dataPrompt .= "  - Face: $domEmotion (Blinks: $blinkBpm bpm - $blinkStatus)\n";
        $dataPrompt .= "  - Answer Content: \"$ans\"\n\n";
    }

    $prompt = "You are an expert interview coach analyzing a video interview for a '$jobRole' position.
    
    Here is the multimodal data from the session (Voice + Facial Expressions + Blink Rate):
    $dataPrompt
    
    Task: Write a comprehensive professional summary (approx 100 words) of the candidate's performance. 
    - Assess their **Communication Style** (clarity, tone).
    - Assess their **Confidence & Stress Management** (referencing blink rate and facial stability).
    - Assess their **Overall Suitability** based on the content of their answers.
    - Be constructive but honest. Mention specific strengths and one area for improvement.
    
    Return purely the summary text in the JSON format:
    {
        \"summary\": \"The candidate demonstrated...\"
    }";

    // Use the same robust function we use for audio, but with text prompt only
    // This ensures we use the configured API keys and newer models
    $resultData = callGeminiAPIWithAudio($prompt);
    
    if ($resultData['success']) {
        $text = $resultData['text'];
        
        // Clean JSON
        if (preg_match('/(\{[\s\S]*\}|\[[\s\S]*\])/', $text, $matches)) {
            $text = $matches[0];
        } else {
            // Fallback cleanup if regex fails but JSON is there
            $text = preg_replace('/^```json\s*/', '', $text);
            $text = preg_replace('/^```\s*/', '', $text);
            $text = preg_replace('/\s*```$/', '', $text);
            $text = trim($text);
        }

        $data = json_decode($text, true);
        echo json_encode([
            'success' => true, 
            'summary' => $data['summary'] ?? $text,
            'debug_key_index' => $resultData['used_key_index'] ?? 'unknown'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to generate summary: ' . ($resultData['error'] ?? 'Unknown')]);
    }
}