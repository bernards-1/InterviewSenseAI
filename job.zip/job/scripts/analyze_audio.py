import sys
import json
import numpy as np
import matplotlib.pyplot as plt

# Try to import librosa, handle missing library gracefully
try:
    import librosa
    import librosa.display
    HAS_LIBROSA = True
except ImportError:
    HAS_LIBROSA = False

def analyze_audio(input_path, output_image_path):
    result = {
        "pitch_avg": 0,
        "tempo": 0,
        "tone_score": 0,
        "volume_consistency": 0,
        "error": None
    }

    if not HAS_LIBROSA:
        import sys
        result["error"] = f"librosa not found. Python: {sys.executable}. Please run: pip install librosa matplotlib numpy"
        # Create a dummy image if possible or just exit
        create_dummy_spectrogram(output_image_path)
        print(json.dumps(result))
        return

    try:
        # 1. Load Audio
        y, sr = librosa.load(input_path)

        # 2. Extract Pitch (F0)
        # piptrack returns magnitudes and pitches
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
        # Select pitches with high magnitude
        pitches_filtered = pitches[magnitudes > np.median(magnitudes)]
        pitch_avg = float(np.mean(pitches_filtered)) if len(pitches_filtered) > 0 else 0

        # 3. Extract Tempo (BPM)
        tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
        tempo = float(tempo)

        # 4. Volume Consistency (RMSE)
        rmse = librosa.feature.rms(y=y)
        volume_consistency = float(np.std(rmse) / np.mean(rmse)) if np.mean(rmse) > 0 else 0
        # Lower std deviation means more consistent volume. 
        # let's invert it for a "consistency score": 1 / (1 + vol_std)
        vol_score = 1.0 / (1.0 + volume_consistency)

        # 5. Advanced Confidence vs Nervousness Analysis
        
        nervous_score = 0
        confidence_score = 0
        
        # C. Fluency First (Compute ratio early to condition other metrics)
        non_silent_intervals = librosa.effects.split(y, top_db=25, frame_length=2048, hop_length=512)
        total_duration = librosa.get_duration(y=y, sr=sr)
        if total_duration == 0: total_duration = 0.1

        speech_duration = sum([ (end - start) / sr for start, end in non_silent_intervals ])
        speech_ratio = speech_duration / total_duration
        
        pause_count = 0
        if len(non_silent_intervals) > 1:
            for i in range(len(non_silent_intervals) - 1):
                gap = (non_silent_intervals[i+1][0] - non_silent_intervals[i][1]) / sr
                if gap > 0.4:
                    pause_count += 1

        # A. Tempo Check
        # FIX: Don't reward "Good Pace" if they barely spoke (e.g. just "Hmm")
        if speech_ratio > 0.5: 
            if tempo > 190: nervous_score += 20 
            elif tempo < 70: nervous_score += 15 
            else: confidence_score += 20 
        else:
             # If mostly silent, tempo is unreliable. Neutral or slight penalty.
             nervous_score += 5

        # B. Pitch - Drone Detection (Hmmmm)
        pitch_std = np.std(pitches_filtered) if len(pitches_filtered) > 0 else 0
        
        is_monotone = False
        # Raised threshold to 25 to catch "Hmm" better
        if pitch_std < 25: 
            is_monotone = True
            nervous_score += 30 # Monotone/Drone
        elif pitch_std > 35: 
            confidence_score += 25 
        else:
            confidence_score += 10 

        # Pause/Ratio Penalties
        # FIX: Allow 1-2 "thoughtful pauses" without heavy penalty.
        if pause_count > 1: 
            nervous_score += 10 * (pause_count - 1) 
        
        # D. Speech Ratio Logic
        if speech_ratio > 0.7:
            if is_monotone:
                nervous_score += 40 # Continuous drone
                confidence_score -= 20
            elif pause_count <= 1:
                confidence_score += 30 # Fluent (allow 1 pause)
        
        elif speech_ratio < 0.4: 
            nervous_score += 30 # Too much silence (<40% speech)

        # E. Volume
        rmse = librosa.feature.rms(y=y)
        avg_vol = np.mean(rmse)
        if avg_vol > 0.05: confidence_score += 10 
        elif avg_vol < 0.02: nervous_score += 10

        # Normalize
        total_points = confidence_score + nervous_score + 1
        conf_ratio = confidence_score / total_points
        
        confidence_final = int(conf_ratio * 100)
        
        # Strict Capping - RELAXED
        # Only Cap if mostly silent (<30%) or clearly droning
        if speech_ratio < 0.3:
             confidence_final = min(35, confidence_final)
        elif is_monotone and speech_ratio > 0.6:
             confidence_final = min(50, confidence_final) # Droning cap raised slightly
        elif pause_count > 3:
             confidence_final = min(60, confidence_final) # Too many pauses cap

        confidence_final = max(5, min(95, confidence_final))
        nervous_final = 100 - confidence_final

        result["pitch_avg"] = round(pitch_avg, 1)
        result["tempo"] = round(tempo, 1)
        result["volume_consistency"] = round(vol_score, 2)
        result["pause_count"] = pause_count
        result["speech_ratio"] = round(speech_ratio * 100, 1)
        result["confidence_percent"] = confidence_final
        result["nervous_percent"] = nervous_final
        
        # Tone Score
        result["tone_score"] = confidence_final

        # 7. Generate Spectrogram
        plt.figure(figsize=(10, 4))
        D = librosa.amplitude_to_db(np.abs(librosa.stft(y)), ref=np.max)
        librosa.display.specshow(D, sr=sr, x_axis='time', y_axis='hz')
        plt.colorbar(format='%+2.0f dB')
        plt.title('Mel-frequency spectrogram')
        plt.tight_layout()
        plt.savefig(output_image_path)
        plt.close()

    except Exception as e:
        result["error"] = str(e)
        create_dummy_spectrogram(output_image_path)

    print(json.dumps(result))

def create_dummy_spectrogram(path):
    # Create a simple noise image if librosa fails, requiring only matplotlib
    try:
        plt.figure(figsize=(10, 4))
        plt.plot(np.random.rand(100))
        plt.title('Mock Spectrogram (Librosa missing)')
        plt.savefig(path)
        plt.close()
    except:
        pass

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: python analyze_audio.py <input> <output_img>"}))
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_img = sys.argv[2]
    
    analyze_audio(input_file, output_img)
