from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import base64
import os
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import time

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

print("Initializing MediaPipe Face Landmarker...")

# --- MediaPipe Setup ---
model_path = 'face_landmarker.task'
if not os.path.exists(model_path):
    print(f"Error: {model_path} not found. Please download it.")
    # Fallback to prevent immediate crash, though predict will fail
    detector = None
else:
    VisionRunningMode = mp.tasks.vision.RunningMode
    base_options = python.BaseOptions(model_asset_path=model_path)
    options = vision.FaceLandmarkerOptions(base_options=base_options,
                                           output_face_blendshapes=True,
                                           num_faces=1)
    detector = vision.FaceLandmarker.create_from_options(options)
    print("MediaPipe Face Landmarker initialized and loaded!")


# Global state for nervous tracking
jaw_open_start = None

@app.route('/')
def index():
    return app.send_static_file('both.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        if not data or 'image' not in data:
            return jsonify({'error': 'No image provided'}), 400

        image_data = data['image']
        
        # Decode base64
        try:
            if ',' in image_data:
                image_data = image_data.split(',')[1]
            img_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        except Exception as img_err:
             print(f"Decode error: {img_err}")
             return jsonify({'error': 'Decode failed'}), 400

        if img is None:
            return jsonify({'error': 'Image is None'}), 400

        if detector is None:
             return jsonify({'error': 'MediaPipe model not loaded'}), 500

        # Convert to RGB (MediaPipe requires RGB) and mp.Image
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=img_rgb)

        # Detect
        detection_result = detector.detect(mp_image)

        if not detection_result.face_blendshapes:
             # No face found
             return jsonify({'success': True, 'result': {'label': 'neutral', 'confidence': 0.0}})

        # Get blendshapes for the first face
        blendshapes = detection_result.face_blendshapes[0]
        
        # Convert to dictionary for easier access: {category_name: score}
        bs_map = {b.category_name: b.score for b in blendshapes}

        # --- Custom Logic Layer (Standard + Thinking) ---

        # TRACKING STATE FOR NERVOUS (Global)
        global jaw_open_start
        current_time = time.time()
        jaw_val = bs_map.get('jawOpen', 0)
        brow_outer_up = max(bs_map.get('browOuterUpLeft', 0), bs_map.get('browOuterUpRight', 0))
        
        # 1. Config - TUNING
        # Lowered to 0.15 so you don't have to gape. 
        # Just "mouth hanging open" is enough.
        JAW_OPEN_THRESHOLD = 0.15 
        REQUIRED_TIME = 5.0
        
        # 2. Update Start Time
        if jaw_val > JAW_OPEN_THRESHOLD:
            if jaw_open_start is None:
                jaw_open_start = current_time
        else:
            # Reset if mouth closes
            jaw_open_start = None
            
        # 3. Calculate Score
        nervous_score = 0.0
        if jaw_open_start is not None:
             duration_open = current_time - jaw_open_start
             # "Soft" score: proportional to time held
             ratio = min(duration_open / REQUIRED_TIME, 1.0)
             
             # 4. Auxiliary Check: Very minimal brow check
             # Just ensures you aren't completely deadpan, but effectively optional now
             if brow_outer_up > 0.05:
                 nervous_score = ratio
             else:
                 # Even without brows, if mouth is open LONG enough (>3s), start counting
                 if duration_open > 3.0:
                     nervous_score = ratio * 0.8 # Slightly less confidence
                 else:
                     nervous_score = 0.0 
        else:
             nervous_score = 0.0

        # DEBUG PRINT
        if jaw_val > 0.1:
            print(f"Jaw: {jaw_val:.2f}, Brows: {brow_outer_up:.2f}, Time: {0 if jaw_open_start is None else current_time - jaw_open_start:.1f}s, Nervous: {nervous_score:.2f}")

        # 1. Angry: Mostly based on eyebrows now. 
        # Squinting is optional bonus.
        # We boost the browDown score by 2.0x (was 1.5) to make it very sensitive.
        brow_down = max(bs_map.get('browDownLeft', 0), bs_map.get('browDownRight', 0))
        angry_score = brow_down * 2.0
        
        # Add a tiny bit of squint if present
        squint = max(bs_map.get('eyeSquintLeft', 0), bs_map.get('eyeSquintRight', 0))
        if squint > 0.3: # Lowered squint threshold
             angry_score += 0.3
        
        # Clamp to 1.0
        if angry_score > 1.0: angry_score = 1.0

        # Threshold: Lowered to 0.3 to be VERY responsive
        if angry_score < 0.3: 
            angry_score = 0.0

        if angry_score > 0.1:
            print(f"ANGRY DEBUG: BrowDown={brow_down:.2f}, Score={angry_score:.2f}")

        # 2. Disgust: noseSneer + mouthUpperUp
        disgust_score = (max(bs_map.get('noseSneerLeft', 0), bs_map.get('noseSneerRight', 0)) +
                         max(bs_map.get('mouthUpperUpLeft', 0), bs_map.get('mouthUpperUpRight', 0))) / 2.0


        # 4. Happy: mouthSmile
        # Boosted by 1.5x to be more sensitive
        raw_happy = (bs_map.get('mouthSmileLeft', 0) + bs_map.get('mouthSmileRight', 0)) / 2.0
        happy_score = raw_happy * 1.5
        if happy_score > 1.0: happy_score = 1.0
        
        # Debug
        if happy_score > 0.1:
            print(f"HAPPY DEBUG: Raw={raw_happy:.2f}, Boosted={happy_score:.2f}")

        # 5. Sad: REMOVED as requested
        # sad_score = ...

        # 6. nervous: Handled above with 5s rule
        # nervous_score = (max(bs_map.get('browOuterUpLeft', 0), bs_map.get('browOuterUpRight', 0)) + 
        #                   bs_map.get('jawOpen', 0)) / 2.0

        # 7. Thinking: browInnerUp + eyeLookIn + eyeLookDown (looking down is also thinking)
        thinking_score = (bs_map.get('browInnerUp', 0) + 
                          max(bs_map.get('eyeLookInLeft', 0), bs_map.get('eyeLookInRight', 0)) + 
                          max(bs_map.get('eyeLookDownLeft', 0), bs_map.get('eyeLookDownRight', 0))) / 2.5

        # 8. Neutral baseline
        # Removed sad_score from max()
        neutral_score = 1.0 - max(angry_score, disgust_score, nervous_score, happy_score, 
                                  thinking_score)
        if neutral_score < 0: neutral_score = 0

        # Determine winner
        scores = {
            'angry': angry_score,
            'nervous': nervous_score,
            'happy': happy_score,
            'neutral': neutral_score,
            'thinking': thinking_score
        }
        
        # Normalize scores to sum to 1.0 (100%)
        total_score = sum(scores.values())
        if total_score > 0:
            for k in scores:
                scores[k] = scores[k] / total_score
        
        dominant_emotion = max(scores, key=scores.get)
        confidence = scores[dominant_emotion]

        print(f"MediaPipe: {dominant_emotion} ({confidence:.2f})")

        return jsonify({
            'success': True,
            'result': {
                'label': dominant_emotion,
                'confidence': confidence,
                'details': scores 
            }
        })

    except Exception as e:
        print(f"MediaPipe Error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
